# QuestPad v0.8.0 RC2

SideQuest release-candidate polish based on the v0.7.7 controller/window fix.

- Permanent public application ID: `com.dearformerself.questpad`
- Quest 3S added to supported devices
- Release manifest excludes the app from Android recents
- Focus Mode toggle hides passthrough and uses a black scene backfill
- Focus Mode defaults OFF on app launch
- Controller mapping remains: both grips + left stick = D-pad; both grips + Menu/three-lines = View
- L3 + R3 remain stick clicks and never trigger View
- Spatial locomotion stays disabled and controller rays stay hidden in Xbox mode
- Native Spatial SDK panel resizing retained
- Developer tester/release tools moved under Advanced
- New QuestPad launcher icon


RC2 navigation/input polish:
- Both hands fully clenched for ~0.65 s hands control back to Touch → Xbox and enables Controller ON.
- Main QuestPad frame has Back and Keyboard buttons. Back uses browser history, then falls back to GeForce NOW home.
- Keyboard can open immediately as a floating panel; Tabletop K/M still anchors it to a desk.
- Keyboard key taps fall back to native WebView key events if Chromium DevTools input is unavailable.
