# QuestPad 0.7.6

QuestPad is a portable, controller-optional cloud-gaming shell for Meta Quest 3. It keeps
GeForce NOW inside the foreground app, preserves login cookies, and routes Touch controllers,
tracked hands, or spatial UI through one release-safe virtual input state.

## Four input modes

| Mode | Current v0.7.6 behavior |
| --- | --- |
| Touch → Xbox | Quest face buttons, triggers, grips, thumb clicks, Menu, and digital thumb directions feed the standard Gamepad API layout. It is the controller-first mode for this build. |
| Hands → Xbox | Left/right thumb-on-index surfaces become the two sticks, with palm displacement as a fallback. A hybrid contact/bend recognizer and native index pinches provide the starter Xbox button layout. |
| Hands → K/M | Hybrid left-finger strokes hold movement keys, hybrid right-finger strokes hold mouse/actions, and the right thumb-on-index surface sends relative mouse movement with right-palm motion as a fallback. |
| Tabletop K/M | Calibrates to a real tabletop, then opens the visible QWERTY/symbol keyboard with a relative trackpad and held L/R mouse buttons. |

The selected mode persists across ordinary app restarts and APK updates installed with `adb
install -r`.

## Touch controller map (v0.7.6)

| Quest 3 Touch input | Virtual Xbox output |
| --- | --- |
| Right A / B | A / B |
| Left X / Y | X / Y |
| Left / right index trigger | LT / RT |
| Left / right grip | LB / RB |
| Left / right thumbstick direction | Left / right stick |
| Left / right thumbstick click | L3 / R3 |
| Left Menu | Menu |
| Both thumbstick clicks | View |
| Hold left grip + move left stick | D-pad |
| Hold both grips + left Menu | Xbox / Guide (web gamepad button 16) |

Meta's Spatial SDK provides controller stick movement to this app as directional button flags—not
continuous axis values—so the two stick outputs are deliberately full-deflection directional states.
The Local tester shows exactly what the embedded browser receives.

This input reaches the browser embedded in Quest Input Lab. A normal sideloaded app cannot inject a
controller into a separate native Quest app such as the standalone Xbox app.

## Windows build

Double-click `BUILD-WINDOWS.bat`, or run it from Command Prompt. It executes the unit tests, Android
lint, and debug APK build, then prints the exact APK path. Install the result with `adb install -r`
so an existing tracking capture and learned profile remain available.

## Organized control center and browser frame

The control panel is divided into four focused sections instead of showing every control at once:

- **Play** keeps the selected mode, browser shortcuts, keyboard, safety release, physical input,
  and final routed output immediately visible.
- **Calibration** contains finger tuning, thumb-stick tuning, recentering, table placement, and the
  guided tracking recorder with its full live prompt.
- **Window** contains movement, depth, size, reset, and grab-lock controls.
- **Diagnostics** holds the dense per-finger and trackpad measurements in a scrollable inspector.

The browser now has a persistent rounded boundary and title bar. Choose **Move window**, grab the
framed panel with a hand or Touch controller, and choose **Finish moving** when it is placed. Drag
any cyan corner handle outward or inward for continuous 16:9 resizing. The title bar also provides
smaller, larger, and reset fallbacks, and the frame changes color while movement is unlocked.

## Guided tracking capture

**Capture tracking** records and learns the numerical hand signals needed to personalize finger
presses, thumb-stick ranges, and thumb release on the actual Quest 3. The guided status line
steps through relaxed open hands, an invisible-controller rest pose, isolated middle/ring/pinky
movement on both hands, full four-direction sweeps of each thumb-on-index surface, and a final pose
with both thumbs lifted. A phase timer pauses whenever its required hand or trackpad contact is not
visible, so tracking loss does not silently contaminate the labeled phase.

Each finger prompt now reserves its first second for a neutral pose, then asks for one deliberate
press-and-hold. When the routine completes, the app automatically builds and persists a personal
profile. **Apply latest capture** can analyze an existing `QuestInputLab-tracking-latest.jsonl`,
including the v0.4.1 diagnostic capture, without making the user repeat the routine.

All emulated keyboard, mouse, and Xbox output is held neutral during capture. The file contains
only numerical tracking, calibration, recognizer, and routed-output state; it does not contain
camera/passthrough images, browser contents, typed text, login data, or streamed game content.
Capture finishes automatically, can be stopped and saved early, and writes a stable latest-file
alias that can be pulled with:

```bash
adb pull /sdcard/Android/data/com.dearformerself.questinputlab/files/QuestInputLab-tracking-latest.jsonl
```

Upload that JSONL when outside analysis is useful. Timestamped captures and the learned profile are
kept until the app is uninstalled; `adb install -r` preserves them.

## Thumb-on-index trackpads

Each thumb and the thumb-facing side of its index finger can form a LITHOS-inspired miniature
trackpad. Each surface uses a coordinate frame built from that hand's index and middle finger
joints, so moving or rotating the whole hand does not move either trackpad cursor.

- In **Hands → K/M**, the right thumb surface becomes relative mouse movement. The left surface is
  disabled so Space and D remain normal left-hand strokes.
- In **Hands → Xbox**, the left thumb surface becomes the left analog stick and the right surface
  becomes the right analog stick.
- Sliding toward the fingertip is up/forward; sliding back is down/back; motion across the side of
  the index controls left/right.
- Lifting the thumb enters a learned per-hand thumb-off pose, stops mouse movement, and returns the
  stick to center even when Quest's bone centers remain inside the broad contact gate.
- The index fingertip is excluded from the trackpad zone so the native pinch remains available.
- Trackpad contact temporarily owns that entire hand. All five finger-button strokes are released
  immediately so the natural curl used to hold the index-side surface cannot press several buttons.

The Local tester includes separate live squares for both hands with contact state, X/Y cursor,
per-frame delta, position along the index, and measured contact distance. This is intentionally
visible for the first headset tuning pass because axis direction and physical contact thresholds
may vary by hand.

**Tune thumb sticks** learns the usable surface range of each hand independently. The guided
capture now learns the same asymmetric ranges automatically. Hold the left
thumb against the index side until its sweep prompt appears, then cover the full comfortable area:
left, right, toward the fingertip, and toward the base. Repeat when prompted for the right hand.
The app discards the outer five percent of samples as tracking spikes, verifies that both axes had
real travel, and maps the learned midpoint to neutral with separate negative and positive halves.
Successful left/right profiles persist across app updates. The uncalibrated first-touch behavior
remains available as a fallback when one hand reports `RETRY`.

## Adjustable browser window

The main browser panel can now be repositioned and resized from the debug panel. **Unlock move**
temporarily enables Meta Spatial SDK grabbing on the browser itself, allowing it to be moved with
a hand or Touch controller. Lock it again before gaming so normal browser clicks cannot move the
screen accidentally. Gameplay gestures are suspended and all held outputs are released whenever
window movement is unlocked.

Precision controls move the screen left, right, up, down, nearer, or farther in fixed increments.
**− Size** and **+ Size** resize it between 0.8 and 2.4 meters wide while preserving the 16:9
aspect ratio. **Reset view** restores the original size and places the screen 1.65 meters in front
of the headset's current yaw, slightly below eye level.

## Complete stroke monitor

The **Local tester** is no longer limited to one Xbox A light and one W key. It now provides a
dedicated row for all ten finger strokes. Every row shows the current mode-specific binding, joint
bend, thumb-tip distance, palm-tip distance, raw curl ratio, active recognizer source, native
index-pinch state, per-finger sensitivity, recognized hold state, and final output confirmation.

Separate output panels visualize all eight currently mapped keyboard keys, both mouse buttons and
motion, every standard Xbox button, and both analog sticks. Keyboard keys distinguish a routed
request from an actual trusted Chromium key event, so a gesture lighting up is no longer mistaken
for successful browser delivery. The typing field remains available for real text-entry checks.

## Starter hand layouts

The debug panel displays these bindings in thumb-to-little-finger order. Each binding lights cyan
while the recognizer considers that finger held.

### Hands → K/M

| Hand | Thumb | Index | Middle | Ring | Little |
| --- | --- | --- | --- | --- | --- |
| Left | Space | D | W | A | S |
| Right | Shift | Left click | Right click | E | R |

This permits combinations such as W+A, W+Space, Shift+W, and moving while clicking. Calibration is
not required: each finger independently listens for thumb contact, joint bend, and a palm-distance
fallback. If the experimental joint buffer is unavailable, the headset-tested left-pinch→W and
right-pinch→left-click fallback remains active.

### Hands → invisible Xbox

| Hand | Thumb | Index | Middle | Ring | Little |
| --- | --- | --- | --- | --- | --- |
| Left | Menu | LT | LB | L3 | View |
| Right | A | RT | RB | B | Y |

Right pinch also maps to A and left pinch maps to X. Index stroke is suppressed during a pinch so a
pinch does not accidentally send both a face button and trigger. Thumb-on-index surfaces are the
primary analog sticks; palm positions remain the fallback after applying a deadzone and clamping.
Recenter establishes new neutral palm positions for that fallback.

These are validation bindings, not the final profile editor. Additional keys, chords, sensitivity,
and per-game profiles are planned after the hybrid measurements and mouse direction are tuned on
the headset.

## Table placement and input calibration

**Place on table** first asks for Quest Spatial Data permission and searches the current Space Setup
for the nearest object labeled `TABLE` or `DESK`. If one is available, the app uses its 3D bounds
and anchor pose to put the keyboard on its top surface and face it toward the headset.

If permission is denied, the room has not been scanned, or no table is labeled, the app immediately
switches to a deliberate two-palm fallback. Rest both palms on the physical table at least 18 cm
apart, then hold both index pinches for about half a second. The measured palm height,
left-to-right direction, and headset position lay the keyboard flat just beyond the hands. **Place
on table** can be used again at any time.

The hybrid recognizer works before calibration. For each non-thumb finger it accepts either close
thumb-to-fingertip contact, a physical joint bend, or a palm-to-tip ratio crossing the conservative
fallback threshold. The thumb uses bend or thumb-to-palm motion and is suppressed while it is
forming a fingertip contact. Measurements are smoothed and must remain stable for three frames;
separate press and release thresholds prevent rapid flicker.

Sensitivity intentionally differs by finger instead of pretending every finger is tracked equally:

| Finger | Profile | Behavior |
| --- | --- | --- |
| Thumb | Standard | Balanced bend and palm-contact recognition. |
| Index | Standard | Baseline contact, bend, ratio, smoothing, and three-frame confirmation. |
| Middle | Deliberate | Slightly eased contact, bend, and ratio thresholds while retaining slower smoothing and four-frame confirmation. |
| Ring | Sensitive | Moderated contact/bend thresholds and a quicker release to reduce accidental presses. |
| Pinky | Sensitive | Moderated thresholds, three-frame confirmation, and source-specific release to prevent sticking. |

After a guided capture, middle/ring/pinky strokes use personal motion measured relative to the
current resting pose. This lets a weak pinky movement register without treating an already-curled
invisible-controller grip as five pressed buttons. If several adjacent fingers begin on the same
tracking frame, the strongest onset owns it and incidental neighbors remain blocked until release.
A second deliberate finger pressed while the first is held is accepted, preserving W+A, W+Space,
and other held chords.

The profile is applied to both calibration-free recognition and personalized calibration. The Local
tester prints `SENS` on every finger row so its behavior is visible during headset tuning.

**Tune fingers** is an optional personalization pass for the palm-distance ratio. Follow the two short prompts: hold
both hands fully open, then close both into comfortable fists. The app collects each visible
finger independently and uses the median of its samples to reject tracking spikes. One weak or
occluded finger can no longer invalidate the other nine: successful fingers receive their own
press/release thresholds. Failed calibration does not disable contact or bend recognition. The
partial profile and its diagnostics persist across app updates.

The debug panel shows bend (`B`), thumb distance (`T`), raw ratio (`R`), and the winning source for
every finger. `THUMB CONTACT`, `PERSONAL MOTION`, `JOINT BEND`, `PERSONAL RATIO`, `FALLBACK RATIO`, and `PALM TAP`
identify the recognizer that activated a stroke. A cyan token is currently held and a muted teal
token has usable live joint data. Old calibration diagnostics remain available when needed.

## Safety behavior

The following all release keyboard keys, mouse buttons, and gamepad state through one shared path:

- mode changes;
- opening or closing the spatial keyboard;
- navigation;
- activity pause, focus loss, and shutdown;
- tracking loss;
- the manual **Release all** button.

The visible keyboard pauses gameplay gestures while open, so pinching its keys cannot also move or
shoot in the streamed game. Tabletop mouse buttons are explicitly released when the panel closes.

## Browser backends

- Keyboard down/up and spatial key taps use Chromium DevTools Protocol `Input.dispatchKeyEvent`.
- Relative mouse movement and buttons use `Input.dispatchMouseEvent` with coalesced motion updates.
- Xbox state uses a standard-layout Gamepad API shim injected into the foreground WebView.
- Android key delivery and the page-level W fallback remain as diagnostics for the local tester.

The app cannot send input into standalone Quest Browser or another foreground application. The
embedded GeForce NOW page must stay inside Quest Input Lab.

## Build locally

Requirements:

- JDK 17
- Android SDK platform 34 and build-tools 35.0.0
- ADB platform tools

Run:

```bash
./gradlew test lintDebug assembleDebug
```

The APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

## Install and launch

Update without erasing the saved NVIDIA session or selected input mode:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
adb shell monkey -p com.dearformerself.questinputlab 1
```

## v0.4.2 headset acceptance test

1. Confirm the existing GeForce NOW login remains cached after `adb install -r`.
2. Confirm the control center opens on **Play** with Calibration, Window, and Diagnostics tabs.
   Verify switching tabs hides unrelated controls and preserves the selected input mode.
3. On the browser frame, choose **Move window**, grab and reposition the framed panel, then choose
   **Finish moving**. Drag every cyan corner inward and outward and confirm the window resizes
   continuously, stays 16:9, and remains between its minimum and maximum size. Test − Size,
   + Size, and Reset view from both the frame and Window tab.
4. In **Touch → Xbox**, press A/B/X/Y, triggers, grips, and thumb directions while watching the
   final output line or a gamepad tester.
5. Select **Unlock move**, grab the browser with a hand and then a Touch controller, and place it
   elsewhere. Lock movement and confirm browser clicks no longer reposition it. Test every
   directional/depth/size control and verify **Reset view** returns a 16:9 screen in front of you.
6. Put controllers down, open **Local tester**, select **Hands → Xbox**, open Calibration, and choose
   **Apply latest capture**. Confirm the status reports `6/6 finger strokes`, `2/2 stick ranges`,
   and `2/2 thumb releases`, then select **Hands → K/M**.
7. Rest the right thumb against the side of the index between its base and upper joint. Confirm the
   trackpad changes from `READY` to `CONTACT` to `ACTIVE`. Slide toward the fingertip, back, and
   across both directions; verify its 2D cursor and final mouse output. Translate and rotate the
   entire hand without moving the thumb relative to the index and confirm the cursor stays still.
8. Select **Hands → Xbox**. The applied capture should already show both trackpads as `CAL`. Optionally
   press **Tune thumb sticks** to compare its shorter dedicated routine. Hold the
   left thumb in contact until `sweep LEFT` appears, cover the full comfortable surface in all four
   directions for four seconds, then repeat for the right hand. Confirm the final status reports
   `LEFT OK` and `RIGHT OK`; rerun if either says `RETRY`.
9. Test both calibrated sticks. Confirm each reaches left, right, up, and down around the center,
   either thumb lift centers its own stick, and the active card says `CAL`. Return to Hands → K/M
   and confirm the left trackpad reports that it is disabled in this mode.
10. Confirm all ten stroke rows are visible and `Joint signals` rises above zero. Move each finger
   and watch its `B`, `T`, `P`, and `RAW` values change.
11. Test thumb-to-middle, thumb-to-ring, and thumb-to-little contacts, then curl those fingers
   without touching the thumb. A recognized row should light cyan and name its winning source;
   keyboard or mouse rows turn green only after the matching trusted browser event arrives.
   Confirm the pinky and ring say `SENSITIVE`, while the middle says `DELIBERATE`. Press and release
   the pinky repeatedly and confirm it no longer stays latched after the original contact ends.
12. Test all ten rows individually. Press left middle, keep it held, then add ring for W+A and thumb
   for W+A+Space. Confirm an incidental simultaneous ring curl says `CONFLICT BLOCKED`, while the
   deliberate second press joins the held chord.
13. With the trackpad disengaged, move the right palm and verify the original mouse fallback.
    Hold right index/middle strokes for L/R click.
14. Select **Hands → Xbox**, keep both thumb trackpads disengaged, hold both hands in a relaxed
   invisible-controller pose, and press **Recenter**. Move one palm at a time to verify the original
   stick fallback, then test the starter finger buttons.
15. Complete Quest **Space Setup**, select **Tabletop K/M**, grant Spatial Data, and verify the
   keyboard automatically appears flat on the nearest labeled table and faces you. Use **Place on
   table** again and also test the stated two-palm fallback in an unscanned room. Then verify typing,
   pinch-dragging the trackpad, and held L/R buttons.
16. Close the keyboard, choose **Capture tracking**, put down the Touch controllers, and follow all
    11 prompts. During each finger phase, relax for the first second and then press and hold only
    the named finger. Verify the prompt pauses if a required hand disappears and that Final Output
    stays idle. Let it complete and confirm the status reports that the personal profile was applied
    and `QuestInputLab-tracking-latest.jsonl` was saved.
17. Pull the file with the command in **Guided tracking capture** and upload it for measurement-based
    finger and stick tuning.
18. Switch modes while holding an input and verify the output immediately returns to neutral.
19. Repeat the useful checks inside a GeForce NOW game.

This headset pass should confirm the ring/middle balance and verify that learned anatomical ranges
give both hands all four stick directions instead of centering at one edge of their usable travel.

## Architecture

```text
Controller components + experimental tracked body/hand joints
                         ↓
                 InputPollingSystem
                         ↓
                    InputRouter
          ┌──────────────┼──────────────┐
          ↓              ↓              ↓
      Xbox state    held keys/mouse   finger feedback
          └──────────────┼──────────────┘
                         ↓
                VirtualInputState
                         ↓
       Chromium keys/mouse + Gamepad API + debug UI
```

## Known limitations

- Automatic placement depends on Quest Space Setup containing a correctly labeled table/desk and
  still needs on-headset validation with different table shapes. The two-palm fallback is
  session-local and must be repeated after moving to another table or restarting the app.
- Hybrid finger strokes use Meta Spatial SDK's experimental body-joint buffer. Contact, bend,
  personal/fallback ratios, smoothing, debounce, and the proven pinch fallback reduce false
  inputs, but thresholds still need on-headset validation before this can be called reliable.
- Quest thumb directions are currently digital because Spatial SDK's `Controller` component
  exposes directional button bits rather than continuous stick axes in this build.
- The invisible stick neutral pose is session-local and must be recentered when the hands move to a
  different resting position.
- Browser position and size adjustments are session-local. The screen resets to its default on an
  app restart, and the new grab behavior still needs on-headset interaction-conflict testing.
- Thumb-stick range profiles persist and compensate for asymmetric travel, but lateral axis
  direction and physical comfort still require this first on-headset calibration pass. The visual
  monitor keeps raw contact, index length, calibration state, and final axes visible.
- The starter hand layouts are fixed; profile editing and chords for Q/F/G/X/Z/C/V, number keys,
  Ctrl, Alt, Tab, and Esc are the next input-layer milestone.
- Gamepad emulation remains a page-level shim; GeForce NOW was the first target and other services
  have not yet been validated.
# Quest Input Lab

## Touch controllers → virtual Xbox

Select **Touch → Xbox**, then open **Local tester** before opening a streaming session. The tester
shows every output the embedded browser receives.

| Quest 3 Touch input | Virtual Xbox output |
| --- | --- |
| Right A / B | A / B |
| Left X / Y | X / Y |
| Left / right index trigger | LT / RT |
| Left / right grip | LB / RB |
| Left / right thumbstick direction | Left / right stick (full-deflection directional state) |
| Left / right thumbstick click | L3 / R3 |
| Left Menu button | Menu |
| Both thumbstick clicks | View |
| Hold left grip + move left stick | D-pad |
| Hold both grips + left Menu | Xbox / Guide (web gamepad button 16) |

The Meta Spatial SDK version used by this project provides controller stick movement as directional
button flags, not continuous stick-axis values. Therefore stick output is intentionally digital and
full deflection; it is not falsely presented as analog.

Input only reaches the browser embedded in Quest Input Lab. A normal sideloaded app cannot inject a
virtual controller into a separate Quest app such as the standalone Xbox app.


## Focus Mode

Use the Focus toggle on the QuestPad window or Play panel to hide passthrough and leave a solid black background behind the cloud-gaming window. Focus Mode defaults off on every fresh app launch.

## Public release identity

The SideQuest release package is `com.dearformerself.questpad` and targets API 34 with Quest 2, Quest Pro, Quest 3, and Quest 3S declared.


RC2 navigation/input polish:
- Both hands fully clenched for ~0.65 s hands control back to Touch → Xbox and enables Controller ON.
- Main QuestPad frame has Back and Keyboard buttons. Back uses browser history, then falls back to GeForce NOW home.
- Keyboard can open immediately as a floating panel; Tabletop K/M still anchors it to a desk.
- Keyboard key taps fall back to native WebView key events if Chromium DevTools input is unavailable.
