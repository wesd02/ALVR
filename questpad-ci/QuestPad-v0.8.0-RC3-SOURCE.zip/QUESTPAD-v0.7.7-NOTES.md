# QuestPad v0.7.7

- Self-contained foreground Quest app with embedded GeForce NOW/browser input routing.
- Restores the spatial browser frame with grab/move and four-corner continuous resizing.
- Controller routing defaults OFF so Quest UI interaction is available immediately after launch.
- LT + LB + RT + RB toggles Touch → Xbox ownership; the chord is side-specific and latched.
- Controller ON suppresses browser/UI pointer, gamepad-navigation, trigger-click, and stick-scroll handling while routed Touch input continues to the embedded virtual Xbox Gamepad API.
- Controller OFF restores Quest/browser interaction immediately.
- External controller engine, reconnect loop, and VrShell lease payload are removed.
- D-pad modifier preserves left-controller provenance so ordinary LB/stick combinations are not stolen by merged controller bits.
- Includes the Meta cursor drawable required by the Spatial SDK activity.


## v0.7.7 controller/window fixes
- D-pad requires BOTH Touch grips plus a left-stick direction; grips are modifier-only while both are held.
- Xbox View/Select moved from dual stick-click to Quest Menu (three-lines) + both grips. L3/R3 no longer trigger View.
- Interaction SDK controller rays/cursor are hidden while Controller ON.
- Spatial SDK locomotion is forced off so gameplay thumbsticks cannot move/turn the QuestPad scene.
- Replaced the broken Android MotionEvent corner resize path with Spatial SDK IsdkPanelResize (Relayout, aspect ratio preserved).
