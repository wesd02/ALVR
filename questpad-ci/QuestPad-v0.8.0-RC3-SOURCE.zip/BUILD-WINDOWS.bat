@echo off
setlocal

cd /d "%~dp0"

if not defined JAVA_HOME if exist "C:\Program Files\Android\Android Studio\jbr\bin\java.exe" (
  set "JAVA_HOME=C:\Program Files\Android\Android Studio\jbr"
)

if not defined ANDROID_HOME set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if not exist "%ANDROID_HOME%\platform-tools" (
  echo Android SDK was not found at: %ANDROID_HOME%
  echo Install Android SDK Platform 34 and Build-Tools 35.0.0 in Android Studio, then try again.
  pause
  exit /b 1
)
rem Android local.properties requires escaped drive and Windows separators or lint rejects it.
set "SDK_DIR=%ANDROID_HOME:\=\\%"
set "SDK_DIR=%SDK_DIR::=\:%"
>local.properties echo sdk.dir=%SDK_DIR%

echo Building Quest Input Lab...
call gradlew.bat clean test lintDebug assembleDebug --console=plain
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Review the Gradle error above.
  pause
  exit /b 1
)

echo.
echo BUILD PASSED.
echo APK: %CD%\app\build\outputs\apk\debug\app-debug.apk
echo.
echo Install while preserving the existing profile with:
echo adb install -r "%CD%\app\build\outputs\apk\debug\app-debug.apk"
echo.
pause

endlocal
