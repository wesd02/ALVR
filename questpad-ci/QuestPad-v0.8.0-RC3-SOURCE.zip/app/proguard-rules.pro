# Input Lab intentionally keeps readable symbols while the input bridge is experimental.
