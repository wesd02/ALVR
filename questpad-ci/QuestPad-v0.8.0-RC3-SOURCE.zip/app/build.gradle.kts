plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.jetbrains.kotlin.android)
  alias(libs.plugins.meta.spatial.plugin)
}

android {
  namespace = "com.dearformerself.questinputlab"
  compileSdk = 34

  defaultConfig {
    applicationId = "com.cornerofweird.questpad"
    minSdk = 34
    targetSdk = 34
    versionCode = 82
    versionName = "0.8.0-rc3"
    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
  }

  buildFeatures { buildConfig = true }

  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
  }

  kotlinOptions { jvmTarget = "17" }

  packaging {
    resources.excludes.add("META-INF/LICENSE")
    jniLibs.useLegacyPackaging = false
  }

  lint {
    abortOnError = true
    checkReleaseBuilds = true
    disable += setOf("GradleDependency", "OldTargetApi", "SetJavaScriptEnabled")
  }

  buildTypes {
    release {
      isMinifyEnabled = false
      proguardFiles(
          getDefaultProguardFile("proguard-android-optimize.txt"),
          "proguard-rules.pro",
      )
    }
  }

  testOptions { unitTests.isReturnDefaultValues = true }
}

dependencies {
  implementation(libs.androidx.core.ktx)

  implementation(libs.meta.spatial.sdk.base)
  implementation(libs.meta.spatial.sdk.toolkit)
  implementation(libs.meta.spatial.sdk.vr)
  implementation(libs.meta.spatial.sdk.isdk)

  testImplementation(libs.junit)
}

spatial { allowUsageDataCollection.set(false) }
