package com.dearformerself.questinputlab.input

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TrackingCaptureRecorderTest {
  @Test
  fun phaseTimerPausesWhenRequiredHandsDisappear() {
    val timeline = TrackingCaptureTimeline()

    timeline.update(1L, InputSnapshot())
    val progress = timeline.update(5_000_000_001L, InputSnapshot())

    assertEquals(TrackingCapturePhase.RELAXED_OPEN, progress.phase)
    assertEquals(0L, progress.phaseElapsedMillis)
    assertFalse(progress.ready)
    assertTrue(progress.statusText().contains("timer paused"))
  }

  @Test
  fun relaxedOpenAdvancesAfterThreeSecondsOfTrackedFrames() {
    val timeline = TrackingCaptureTimeline()
    val tracked =
        InputSnapshot(
            leftFingers = FingerInput(tracked = true),
            rightFingers = FingerInput(tracked = true),
        )
    var now = 1L
    var progress = timeline.update(now, tracked)

    repeat(30) {
      now += 100_000_000L
      progress = timeline.update(now, tracked)
    }

    assertEquals(TrackingCapturePhase.RELAXED_CONTROLLER_GRIP, progress.phase)
    assertEquals(0L, progress.phaseElapsedMillis)
    assertTrue(progress.ready)
  }

  @Test
  fun stickSweepRequiresThumbIndexSideContact() {
    val missing = InputSnapshot(leftFingers = FingerInput(tracked = true))
    val touching =
        InputSnapshot(
            leftFingers =
                FingerInput(
                    tracked = true,
                    thumbTrackpad = ThumbTrackpadSignal(enabled = true, touching = true),
                ),
        )

    assertFalse(TrackingCapturePhase.LEFT_STICK_SWEEP.isReady(missing))
    assertTrue(TrackingCapturePhase.LEFT_STICK_SWEEP.isReady(touching))
  }

  @Test
  fun recorderSchemaIsNumericalAndUsesStableLatestAlias() {
    val source =
        sourceFile(
            "app/src/main/java/com/dearformerself/questinputlab/input/TrackingCaptureRecorder.kt",
            "src/main/java/com/dearformerself/questinputlab/input/TrackingCaptureRecorder.kt",
        )

    assertTrue(source.contains("QuestInputLab-tracking-latest.jsonl"))
    assertTrue(source.contains("no camera or browser data"))
    assertTrue(source.contains("palmSideMm"))
    assertTrue(source.contains("calibrationMinAlongPercent"))
    assertTrue(source.contains("RELAXED_CONTROLLER_GRIP"))
    assertTrue(source.contains("THUMBS_LIFTED"))
    assertTrue(source.contains("TrackingProfileAnalyzer.evaluate"))
    assertTrue(source.contains("applyLatestProfile"))
    assertTrue(source.contains("relativeScore"))
    assertTrue(source.contains("conflictSuppressed"))
    assertTrue(source.contains("liftPoseMatched"))
  }

  @Test
  fun inputPollingNeutralizesOutputsButKeepsJointTrackingLiveDuringCapture() {
    val source =
        sourceFile(
            "app/src/main/java/com/dearformerself/questinputlab/input/InputPollingSystem.kt",
            "src/main/java/com/dearformerself/questinputlab/input/InputPollingSystem.kt",
        )

    assertTrue(source.contains("calibrating ||\n            capturingTracking"))
    assertTrue(source.contains("placingTable || calibrating || capturingTracking"))
    assertTrue(source.contains("onFrameObserved(state.snapshot())"))
  }

  private fun sourceFile(vararg candidates: String): String =
      requireNotNull(candidates.map(::File).firstOrNull(File::isFile)) {
            "Could not locate ${candidates.first()}"
          }
          .readText()
}
