package com.dearformerself.questinputlab.input

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HybridFingerFilterTest {
  @Test
  fun thumbContactPressesAndReleasesAnUncalibratedFinger() {
    val filter = HybridFingerFilter(Finger.MIDDLE)

    repeat(3) {
      assertFalse(filter.update(HybridFingerMeasurement(thumbDistanceMm = 20f), null).held)
    }
    val pressed = filter.update(HybridFingerMeasurement(thumbDistanceMm = 20f), null)
    assertTrue(pressed.held)
    assertEquals(FingerGestureSource.THUMB_CONTACT, pressed.source)

    var released = pressed
    repeat(6) {
      released = filter.update(HybridFingerMeasurement(thumbDistanceMm = 70f), null)
    }
    assertFalse(released.held)
  }

  @Test
  fun jointBendWorksWithoutPersonalCalibration() {
    val filter = HybridFingerFilter(Finger.RING)

    repeat(3) { filter.update(HybridFingerMeasurement(bendDegrees = 80f), null) }
    val signal = filter.update(HybridFingerMeasurement(bendDegrees = 80f), null)

    assertTrue(signal.held)
    assertEquals(FingerGestureSource.JOINT_BEND, signal.source)
  }

  @Test
  fun fallbackRatioWorksWhenContactAndAngleAreUnavailable() {
    val filter = HybridFingerFilter(Finger.LITTLE)

    repeat(3) { filter.update(HybridFingerMeasurement(curlRatio = 1.1f), null) }
    val signal = filter.update(HybridFingerMeasurement(curlRatio = 1.1f), null)

    assertTrue(signal.held)
    assertEquals(FingerGestureSource.FALLBACK_RATIO, signal.source)
  }

  @Test
  fun middleFingerContactHysteresisDoesNotReleaseInItsMiddleBand() {
    val filter = HybridFingerFilter(Finger.MIDDLE)
    repeat(3) { filter.update(HybridFingerMeasurement(thumbDistanceMm = 20f), null) }
    repeat(2) { filter.update(HybridFingerMeasurement(thumbDistanceMm = 20f), null) }

    repeat(8) {
      assertTrue(filter.update(HybridFingerMeasurement(thumbDistanceMm = 35f), null).held)
    }
  }

  @Test
  fun moderateBendDoesNotAccidentallyActivatePinkyOrMiddleFinger() {
    val little = HybridFingerFilter(Finger.LITTLE)
    val middle = HybridFingerFilter(Finger.MIDDLE)

    var littleSignal = FingerGestureSignal.NONE
    var middleSignal = FingerGestureSignal.NONE
    repeat(6) {
      val measurement = HybridFingerMeasurement(bendDegrees = 40f)
      littleSignal = little.update(measurement, null)
      middleSignal = middle.update(measurement, null)
    }

    assertFalse(littleSignal.held)
    assertEquals(FingerSensitivity.SENSITIVE, littleSignal.sensitivity)
    assertFalse(middleSignal.held)
    assertEquals(FingerSensitivity.DELIBERATE, middleSignal.sensitivity)
  }

  @Test
  fun middleAcceptsASlightlyLighterIntentionalBend() {
    val filter = HybridFingerFilter(Finger.MIDDLE)

    var signal = FingerGestureSignal.NONE
    repeat(5) {
      signal = filter.update(HybridFingerMeasurement(bendDegrees = 58f), null)
    }

    assertTrue(signal.held)
  }

  @Test
  fun ringIgnoresTheLooseContactThatPreviouslyActivatedIt() {
    val filter = HybridFingerFilter(Finger.RING)

    var signal = FingerGestureSignal.NONE
    repeat(6) {
      signal = filter.update(HybridFingerMeasurement(thumbDistanceMm = 40f), null)
    }

    assertFalse(signal.held)
  }

  @Test
  fun looseThumbProximityDoesNotAccidentallyActivatePinkyOrMiddleFinger() {
    val little = HybridFingerFilter(Finger.LITTLE)
    val middle = HybridFingerFilter(Finger.MIDDLE)

    var littleSignal = FingerGestureSignal.NONE
    var middleSignal = FingerGestureSignal.NONE
    repeat(6) {
      val measurement = HybridFingerMeasurement(thumbDistanceMm = 40f)
      littleSignal = little.update(measurement, null)
      middleSignal = middle.update(measurement, null)
    }

    assertFalse(littleSignal.held)
    assertFalse(middleSignal.held)
  }

  @Test
  fun pinkyContactCannotBeKeptLatchedByIncidentalBend() {
    val filter = HybridFingerFilter(Finger.LITTLE)

    var signal = FingerGestureSignal.NONE
    repeat(4) {
      signal =
          filter.update(
              HybridFingerMeasurement(thumbDistanceMm = 20f, bendDegrees = 70f),
              null,
          )
    }
    assertTrue(signal.held)
    assertEquals(FingerGestureSource.THUMB_CONTACT, signal.source)

    repeat(4) {
      signal =
          filter.update(
              HybridFingerMeasurement(thumbDistanceMm = 70f, bendDegrees = 70f),
              null,
          )
    }
    assertFalse(signal.held)
  }

  @Test
  fun personalCalibrationRetainsPerFingerSensitivity() {
    val little = HybridFingerFilter(Finger.LITTLE)
    val middle = HybridFingerFilter(Finger.MIDDLE)
    val personal = CurlThreshold(press = 1.60f, release = 1.93f, open = 2.50f, closed = 1.00f)

    var littleSignal = FingerGestureSignal.NONE
    var middleSignal = FingerGestureSignal.NONE
    repeat(6) {
      val measurement = HybridFingerMeasurement(curlRatio = 1.55f)
      littleSignal = little.update(measurement, personal)
      middleSignal = middle.update(measurement, personal)
    }

    assertTrue(littleSignal.held)
    assertFalse(middleSignal.held)
  }

  @Test
  fun thumbDoesNotFireWhileItIsTouchingAnotherFingertip() {
    val filter = HybridFingerFilter(Finger.THUMB)

    repeat(6) {
      val signal =
          filter.update(
              HybridFingerMeasurement(
                  bendDegrees = 90f,
                  palmDistanceMm = 20f,
                  suppressGesture = true,
              ),
              null,
          )
      assertFalse(signal.held)
    }
  }

  @Test
  fun personalMotionDetectsAWeakPinkyRelativeToItsLiveRestPose() {
    val filter = HybridFingerFilter(Finger.LITTLE)
    val profile =
        RelativeFingerProfile(
            bendPressDelta = 7f,
            bendReleaseDelta = 3f,
            ratioPressDelta = 0.06f,
            ratioReleaseDelta = 0.025f,
            palmPressDeltaMm = 4f,
            palmReleaseDeltaMm = 2f,
        )

    repeat(10) {
      val resting =
          filter.update(
              HybridFingerMeasurement(
                  bendDegrees = 10f,
                  curlRatio = 2.09f,
                  palmDistanceMm = 126f,
              ),
              null,
              profile,
          )
      assertFalse(resting.held)
    }

    var pressed = FingerGestureSignal.NONE
    repeat(8) {
      pressed =
          filter.update(
              HybridFingerMeasurement(
                  bendDegrees = 27f,
                  curlRatio = 1.94f,
                  palmDistanceMm = 117f,
              ),
              null,
              profile,
          )
    }
    assertTrue(pressed.held)
    assertEquals(FingerGestureSource.PERSONAL_MOTION, pressed.source)

    repeat(8) {
      pressed =
          filter.update(
              HybridFingerMeasurement(
                  bendDegrees = 10f,
                  curlRatio = 2.09f,
                  palmDistanceMm = 126f,
              ),
              null,
              profile,
          )
    }
    assertFalse(pressed.held)
  }

  @Test
  fun suppressedControllerGripBecomesThePersonalNeutralPose() {
    val filter = HybridFingerFilter(Finger.RING)
    val profile =
        RelativeFingerProfile(
            bendPressDelta = 8f,
            bendReleaseDelta = 3f,
            ratioPressDelta = 0.06f,
            ratioReleaseDelta = 0.025f,
            palmPressDeltaMm = 4f,
            palmReleaseDeltaMm = 2f,
        )

    repeat(12) {
      assertFalse(
          filter
              .update(
                  HybridFingerMeasurement(
                      bendDegrees = 80f,
                      curlRatio = 1.10f,
                      palmDistanceMm = 65f,
                      suppressGesture = true,
                  ),
                  null,
                  profile,
              )
              .held,
      )
    }
    repeat(12) {
      val releasedGrip =
          filter.update(
              HybridFingerMeasurement(
                  bendDegrees = 80f,
                  curlRatio = 1.10f,
                  palmDistanceMm = 65f,
              ),
              null,
              profile,
          )
      assertFalse(releasedGrip.held)
    }

    var pressedFromGrip = FingerGestureSignal.NONE
    repeat(8) {
      pressedFromGrip =
          filter.update(
              HybridFingerMeasurement(
                  bendDegrees = 92f,
                  curlRatio = 0.95f,
                  palmDistanceMm = 57f,
              ),
              null,
              profile,
          )
    }
    assertTrue(pressedFromGrip.held)
    assertEquals(FingerGestureSource.PERSONAL_MOTION, pressedFromGrip.source)
  }
}
