package com.dearformerself.questinputlab.input

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PersonalGestureProfileTest {
  @Test
  fun labeledCaptureLearnsSixFingerProfilesTwoSticksAndTwoLiftPoses() {
    val samples = mutableListOf<CapturedProfileSample>()
    repeat(40) { index ->
      samples += sample(TrackingCapturePhase.RELAXED_OPEN, index * 33L)
    }
    val targets =
        listOf(
            Triple(TrackingCapturePhase.LEFT_MIDDLE, HandSide.LEFT, Finger.MIDDLE),
            Triple(TrackingCapturePhase.LEFT_RING, HandSide.LEFT, Finger.RING),
            Triple(TrackingCapturePhase.LEFT_PINKY, HandSide.LEFT, Finger.LITTLE),
            Triple(TrackingCapturePhase.RIGHT_MIDDLE, HandSide.RIGHT, Finger.MIDDLE),
            Triple(TrackingCapturePhase.RIGHT_RING, HandSide.RIGHT, Finger.RING),
            Triple(TrackingCapturePhase.RIGHT_PINKY, HandSide.RIGHT, Finger.LITTLE),
        )
    targets.forEach { (phase, side, finger) ->
      repeat(40) { index ->
        samples +=
            sample(
                phase,
                1_050L + index * 33L,
                changedSide = side,
                changedFinger = finger,
            )
      }
    }
    repeat(60) { index ->
      val progress = index / 59f
      samples +=
          sample(
              TrackingCapturePhase.LEFT_STICK_SWEEP,
              index * 33L,
              leftTrackpad =
                  trackpad(
                      surface = -34f + progress * 41f,
                      along = 0.28f + progress * 0.58f,
                  ),
          )
      samples +=
          sample(
              TrackingCapturePhase.RIGHT_STICK_SWEEP,
              index * 33L,
              rightTrackpad =
                  trackpad(
                      surface = -15f + progress * 40f,
                      along = 0.48f + progress * 0.44f,
                  ),
          )
    }
    repeat(40) { index ->
      samples +=
          sample(
              TrackingCapturePhase.THUMBS_LIFTED,
              1_550L + index * 33L,
              leftTrackpad = trackpad(-20f, 0.67f, -24f, 32f),
              rightTrackpad = trackpad(15f, 0.60f, -34f, 37f),
          )
    }

    val result = TrackingProfileAnalyzer.evaluate(samples)

    assertEquals(6, result.fingers.size)
    assertEquals(2, result.trackpads.size)
    assertEquals(2, result.liftedThumbs.size)
    val rightPinky = result.fingers[HandFinger(HandSide.RIGHT, Finger.LITTLE)]
    assertNotNull(rightPinky)
    assertTrue(requireNotNull(rightPinky).usable)
    assertTrue(requireNotNull(rightPinky.bendPressDelta) < 10f)
    assertEquals(-1f, requireNotNull(result.trackpads[HandSide.LEFT]).stickX(-34f), 0.05f)
    assertTrue(
        requireNotNull(result.liftedThumbs[HandSide.RIGHT])
            .matches(15f, 0.60f, -34f, 37f),
    )
  }

  private fun sample(
      phase: TrackingCapturePhase,
      elapsed: Long,
      changedSide: HandSide? = null,
      changedFinger: Finger? = null,
      leftTrackpad: CapturedTrackpadMeasurement = CapturedTrackpadMeasurement(),
      rightTrackpad: CapturedTrackpadMeasurement = CapturedTrackpadMeasurement(),
  ): CapturedProfileSample =
      CapturedProfileSample(
          phase,
          elapsed,
          hand(changedSide == HandSide.LEFT, changedFinger, leftTrackpad),
          hand(changedSide == HandSide.RIGHT, changedFinger, rightTrackpad),
      )

  private fun hand(
      changed: Boolean,
      changedFinger: Finger?,
      trackpad: CapturedTrackpadMeasurement,
  ): CapturedHandMeasurement =
      CapturedHandMeasurement(
          tracked = true,
          fingers =
              Finger.entries.associateWith { finger ->
                if (changed && finger == changedFinger) {
                  CapturedFingerMeasurement(28f, 1.94f, 117f)
                } else {
                  CapturedFingerMeasurement(10f, 2.09f, 126f)
                }
              },
          trackpad = trackpad,
      )

  private fun trackpad(
      surface: Float,
      along: Float,
      palm: Float = -25f,
      distance: Float = 28f,
  ) =
      CapturedTrackpadMeasurement(
          available = true,
          surfaceOffsetMm = surface,
          alongPercent = along,
          palmSideMm = palm,
          contactDistanceMm = distance,
      )
}
