package com.dearformerself.questinputlab.input

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FingerCalibrationTest {
  @Test
  fun validFingerProducesDirectionalHysteresisThresholds() {
    val open = MutableList(24) { 2.10f }.also { it[0] = 4.40f }
    val closed = MutableList(24) { 1.10f }.also { it[0] = 0.31f }

    val result = FingerCalibrationEngine.evaluate(open, closed)

    assertEquals(FingerCalibrationStatus.READY, result.status)
    assertTrue(result.calibrated)
    assertNotNull(result.thresholdOrNull())
    assertTrue(requireNotNull(result.press) < requireNotNull(result.release))
    assertEquals(1.50f, requireNotNull(result.press), 0.001f)
    assertEquals(1.72f, requireNotNull(result.release), 0.001f)
  }

  @Test
  fun weakFingerFailsWithoutInvalidatingTheEvaluationOfOtherFingers() {
    val weak = FingerCalibrationEngine.evaluate(samples(1.60f), samples(1.52f))
    val strong = FingerCalibrationEngine.evaluate(samples(2.00f), samples(1.00f))

    assertEquals(FingerCalibrationStatus.SPAN_TOO_SMALL, weak.status)
    assertNull(weak.thresholdOrNull())
    assertEquals(FingerCalibrationStatus.READY, strong.status)
    assertNotNull(strong.thresholdOrNull())
  }

  @Test
  fun insufficientAndInvertedMeasurementsExplainWhyTheyAreDisabled() {
    val insufficient = FingerCalibrationEngine.evaluate(List(5) { 2f }, List(5) { 1f })
    val inverted = FingerCalibrationEngine.evaluate(samples(1f), samples(2f))

    assertEquals(FingerCalibrationStatus.NEEDS_SAMPLES, insufficient.status)
    assertEquals(FingerCalibrationStatus.INVERTED, inverted.status)
    assertNull(insufficient.thresholdOrNull())
    assertNull(inverted.thresholdOrNull())
  }

  private fun samples(value: Float): List<Float> =
      List(FingerCalibrationEngine.MIN_SAMPLE_FRAMES) { value }
}
