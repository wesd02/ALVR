package com.dearformerself.questinputlab.input

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ThumbIndexTrackpadFilterTest {
  @Test
  fun sideContactEngagesAfterTwoStableFrames() {
    val filter = ThumbIndexTrackpadFilter()

    assertFalse(filter.update(measurement(thumb = Point3(-0.018f, 0.035f, 0f))).active)
    val active = filter.update(measurement(thumb = Point3(-0.018f, 0.035f, 0f)))

    assertTrue(active.touching)
    assertTrue(active.active)
    assertEquals(0f, active.stickX, 0.001f)
    assertEquals(0f, active.stickY, 0.001f)
  }

  @Test
  fun realHandBoneCenterDistanceStillClaimsTrackpad() {
    val filter = ThumbIndexTrackpadFilter()

    val first = filter.update(measurement(thumb = Point3(-0.034f, 0.035f, 0f)))
    val active = filter.update(measurement(thumb = Point3(-0.034f, 0.035f, 0f)))

    assertTrue(first.touching)
    assertTrue(active.active)
    assertEquals(80f, active.indexLengthMm ?: 0f, 0.1f)
  }

  @Test
  fun shorterQuestJointSegmentCanStillDriveTrackpad() {
    val filter = ThumbIndexTrackpadFilter()
    val shortHand =
        ThumbTrackpadMeasurement(
            thumbTip = Point3(-0.025f, 0.020f, 0f),
            indexProximal = Point3(0f, 0f, 0f),
            indexTip = Point3(0f, 0.040f, 0f),
            middleProximal = Point3(0.012f, 0f, 0f),
        )

    filter.update(shortHand)
    val active = filter.update(shortHand)

    assertTrue(active.active)
    assertEquals(40f, active.indexLengthMm ?: 0f, 0.1f)
  }

  @Test
  fun thumbMotionProducesTwoIndependentAxes() {
    val filter = ThumbIndexTrackpadFilter()
    repeat(2) { filter.update(measurement(thumb = Point3(-0.018f, 0.035f, 0f))) }

    val moved = filter.update(measurement(thumb = Point3(-0.018f, 0.050f, -0.009f)))

    assertTrue(moved.active)
    assertTrue(moved.stickX > 0.20f)
    assertTrue(moved.stickY > 0.15f)
    assertTrue(moved.deltaX > 0f)
    assertTrue(moved.deltaY > 0f)
  }

  @Test
  fun wholeHandTranslationDoesNotMoveTrackpad() {
    val filter = ThumbIndexTrackpadFilter()
    repeat(2) { filter.update(measurement(thumb = Point3(-0.018f, 0.035f, 0f))) }

    val translated =
        filter.update(
            measurement(
                thumb = Point3(0.982f, 0.535f, 0.2f),
                offset = Point3(1f, 0.5f, 0.2f),
            ),
        )

    assertTrue(translated.active)
    assertEquals(0f, translated.deltaX, 0.002f)
    assertEquals(0f, translated.deltaY, 0.002f)
  }

  @Test
  fun indexFingertipPinchIsOutsideTrackpadZone() {
    val filter = ThumbIndexTrackpadFilter()

    repeat(4) {
      val signal = filter.update(measurement(thumb = Point3(-0.012f, 0.078f, 0f)))
      assertFalse(signal.touching)
      assertFalse(signal.active)
    }
  }

  @Test
  fun liftingThumbStopsOutputImmediately() {
    val filter = ThumbIndexTrackpadFilter()
    repeat(2) { filter.update(measurement(thumb = Point3(-0.018f, 0.035f, 0f))) }

    val lifted = filter.update(measurement(thumb = Point3(-0.080f, 0.035f, 0f)))

    assertFalse(lifted.touching)
    assertFalse(lifted.active)
    assertEquals(0f, lifted.stickX, 0.001f)
    assertEquals(0f, lifted.stickY, 0.001f)
  }

  @Test
  fun learnedThumbOffPoseReleasesEvenInsideTheBroadBoneCenterGate() {
    val filter = ThumbIndexTrackpadFilter()
    val lifted =
        ThumbLiftProfile(
            surfaceCenterMm = 0f,
            surfaceToleranceMm = 3f,
            alongCenter = 0.4375f,
            alongTolerance = 0.04f,
            palmSideCenterMm = -18f,
            palmSideToleranceMm = 3f,
            distanceCenterMm = 18f,
            distanceToleranceMm = 3f,
        )
    val pose = measurement(thumb = Point3(-0.018f, 0.035f, 0f))

    filter.update(pose, liftedProfile = lifted)
    filter.update(pose, liftedProfile = lifted)
    val released = filter.update(pose, liftedProfile = lifted)

    assertTrue(released.liftPoseMatched)
    assertFalse(released.touching)
    assertFalse(released.active)
  }

  private fun measurement(
      thumb: Point3,
      offset: Point3 = Point3(0f, 0f, 0f),
  ): ThumbTrackpadMeasurement =
      ThumbTrackpadMeasurement(
          thumbTip = thumb,
          indexProximal = Point3(offset.x, offset.y, offset.z),
          indexTip = Point3(offset.x, offset.y + 0.08f, offset.z),
          middleProximal = Point3(offset.x + 0.022f, offset.y, offset.z),
      )
}
