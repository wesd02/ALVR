package com.dearformerself.questinputlab.ui

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class WindowControlsAssetTest {
  @Test
  fun debugPanelIncludesEveryWindowAdjustment() {
    val layout = sourceFile("app/src/main/res/layout/debug_panel.xml", "src/main/res/layout/debug_panel.xml")

    listOf(
            "button_window_move",
            "button_window_left",
            "button_window_right",
            "button_window_up",
            "button_window_down",
            "button_window_near",
            "button_window_far",
            "button_window_smaller",
            "button_window_larger",
            "button_window_reset",
        )
        .forEach { id -> assertTrue("Missing window control $id", layout.contains(id)) }
  }

  @Test
  fun activityKeepsGrabLockedAndResizeBounded() {
    val activity =
        sourceFile(
            "app/src/main/java/com/dearformerself/questinputlab/QuestInputLabActivity.kt",
            "src/main/java/com/dearformerself/questinputlab/QuestInputLabActivity.kt",
        )

    assertTrue(activity.contains("Grabbable(enabled = false)"))
    assertTrue(activity.contains("!keyboardVisible && !browserGrabUnlocked"))
    assertTrue(activity.contains("MIN_BROWSER_WIDTH_METERS"))
    assertTrue(activity.contains("MAX_BROWSER_WIDTH_METERS"))
    assertTrue(activity.contains("BROWSER_ASPECT_HEIGHT_OVER_WIDTH"))
    assertTrue(activity.contains("resetBrowserWindow"))
  }

  @Test
  fun debugPanelExposesSeparateFingerAndThumbStickTuning() {
    val layout =
        sourceFile("app/src/main/res/layout/debug_panel.xml", "src/main/res/layout/debug_panel.xml")

    assertTrue(layout.contains("button_calibrate"))
    assertTrue(layout.contains("button_calibrate_sticks"))
  }

  @Test
  fun debugPanelExposesGuidedTrackingCapture() {
    val layout =
        sourceFile("app/src/main/res/layout/debug_panel.xml", "src/main/res/layout/debug_panel.xml")

    assertTrue(layout.contains("button_tracking_capture"))
    assertTrue(layout.contains("button_apply_latest_capture"))
    assertTrue(layout.contains("text_tracking_status"))
  }

  @Test
  fun debugPanelGroupsControlsIntoFourSections() {
    val layout =
        sourceFile("app/src/main/res/layout/debug_panel.xml", "src/main/res/layout/debug_panel.xml")

    listOf(
            "section_play",
            "section_calibration",
            "section_window",
            "section_diagnostics",
            "button_section_play",
            "button_section_calibration",
            "button_section_window",
            "button_section_diagnostics",
        )
        .forEach { id -> assertTrue("Missing organized section $id", layout.contains(id)) }
  }

  @Test
  fun browserPanelUsesNativeSpatialResizeInsteadOfAndroidDragHandles() {
    val layout =
        sourceFile(
            "app/src/main/res/layout/input_lab_panel.xml",
            "src/main/res/layout/input_lab_panel.xml",
        )
    val activity =
        sourceFile(
            "app/src/main/java/com/dearformerself/questinputlab/QuestInputLabActivity.kt",
            "src/main/java/com/dearformerself/questinputlab/QuestInputLabActivity.kt",
        )

    assertTrue(layout.contains("browser_window_border"))
    assertTrue(layout.contains("browser_title_bar"))
    assertTrue(layout.contains("button_browser_frame_move"))
    assertTrue(!layout.contains("browser_resize_top_left"))
    assertTrue(activity.contains("IsdkPanelResize("))
    assertTrue(activity.contains("resizeMode = ResizeMode.Relayout"))
    assertTrue(activity.contains("preserveAspectRatio = true"))
  }

  @Test
  fun xboxModeHidesSpatialCursorAndQuestPadDisablesLocomotion() {
    val activity =
        sourceFile(
            "app/src/main/java/com/dearformerself/questinputlab/QuestInputLabActivity.kt",
            "src/main/java/com/dearformerself/questinputlab/QuestInputLabActivity.kt",
        )

    assertTrue(activity.contains("findSystem<LocomotionSystem>().enableLocomotion(false)"))
    assertTrue(activity.contains("findSystem<IsdkDefaultCursorSystem>().enableInput(!controllerRoutingEnabled)"))
  }

  @Test
  fun focusModeUsesPassthroughToggleWithBlackBackfill() {
    val layout =
        sourceFile(
            "app/src/main/res/layout/input_lab_panel.xml",
            "src/main/res/layout/input_lab_panel.xml",
        )
    val activity =
        sourceFile(
            "app/src/main/java/com/dearformerself/questinputlab/QuestInputLabActivity.kt",
            "src/main/java/com/dearformerself/questinputlab/QuestInputLabActivity.kt",
        )

    assertTrue(layout.contains("button_browser_frame_focus"))
    assertTrue(activity.contains("scene.setBackfillColor(Color4("))
    assertTrue(activity.contains("scene.enablePassthrough(!focusModeEnabled)"))
    assertTrue(activity.contains("private fun toggleFocusMode()"))
  }

  @Test
  fun releaseManifestHasPermanentQuestPadIdentityAndCurrentQuestDevices() {
    val manifest =
        sourceFile(
            "app/src/main/AndroidManifest.xml",
            "src/main/AndroidManifest.xml",
        )
    val gradle =
        sourceFile(
            "app/build.gradle.kts",
            "build.gradle.kts",
        )

    assertTrue(gradle.contains("applicationId = \"com.cornerofweird.questpad\""))
    assertTrue(gradle.contains("versionName = \"0.8.0-rc3\""))
    assertTrue(gradle.contains("minSdk = 32"))
    assertTrue(gradle.contains("targetSdk = 34"))
    assertTrue(manifest.contains("android:name=\"android.hardware.vr.headtracking\""))
    assertTrue(manifest.contains("android:version=\"1\""))
    assertTrue(manifest.contains("quest2|questpro|quest3|quest3s"))
    assertTrue(manifest.contains("android:excludeFromRecents=\"true\""))
    assertTrue(manifest.contains("android:icon=\"@drawable/ic_questpad\""))
  }

  @Test
  fun releaseChromeHasBackAndKeyboardControlsAndHandControllerHandoff() {
    val layout =
        sourceFile(
            "app/src/main/res/layout/input_lab_panel.xml",
            "src/main/res/layout/input_lab_panel.xml",
        )
    val activity =
        sourceFile(
            "app/src/main/java/com/dearformerself/questinputlab/QuestInputLabActivity.kt",
            "src/main/java/com/dearformerself/questinputlab/QuestInputLabActivity.kt",
        )
    val polling =
        sourceFile(
            "app/src/main/java/com/dearformerself/questinputlab/input/InputPollingSystem.kt",
            "src/main/java/com/dearformerself/questinputlab/input/InputPollingSystem.kt",
        )

    assertTrue(layout.contains("button_browser_frame_back"))
    assertTrue(layout.contains("button_browser_frame_keyboard"))
    assertTrue(activity.contains("navigateBackOrLibrary"))
    assertTrue(activity.contains("both-hand full fist"))
    assertTrue(polling.contains("gestures.left.deepFist"))
    assertTrue(polling.contains("gestures.right.deepFist"))
    assertTrue(polling.contains("HAND_CONTROLLER_HANDOFF_HOLD_NANOS"))
  }

  private fun sourceFile(vararg candidates: String): String =
      requireNotNull(candidates.map(::File).firstOrNull(File::isFile)) {
            "Could not locate ${candidates.first()}"
          }
          .readText()
}
