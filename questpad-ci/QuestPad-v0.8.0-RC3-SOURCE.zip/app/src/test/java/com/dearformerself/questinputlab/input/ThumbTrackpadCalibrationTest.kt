package com.dearformerself.questinputlab.input

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ThumbTrackpadCalibrationTest {
  @Test
  fun learnedAsymmetricRangeMapsItsMidpointAndBothExtremes() {
    val samples =
        (0 until 60).map { index ->
          val progress = index / 59f
          ThumbTrackpadCalibrationSample(
              surfaceMm = -14f + progress * 22f,
              alongPercent = 0.12f + progress * 0.66f,
          )
        }

    val result = ThumbTrackpadCalibrationEngine.evaluate(samples)
    assertNotNull(result)
    val calibration = requireNotNull(result)
    val centerSurface = (calibration.minSurfaceMm + calibration.maxSurfaceMm) / 2f
    val centerAlong = (calibration.minAlongPercent + calibration.maxAlongPercent) / 2f

    assertEquals(-1f, calibration.stickX(calibration.minSurfaceMm), 0.001f)
    assertEquals(0f, calibration.stickX(centerSurface), 0.001f)
    assertEquals(1f, calibration.stickX(calibration.maxSurfaceMm), 0.001f)
    assertEquals(-1f, calibration.stickY(calibration.minAlongPercent), 0.001f)
    assertEquals(0f, calibration.stickY(centerAlong), 0.001f)
    assertEquals(1f, calibration.stickY(calibration.maxAlongPercent), 0.001f)
  }

  @Test
  fun calibrationRejectsAOneDirectionWiggleWithoutTwoAxisTravel() {
    val samples =
        (0 until 40).map { index ->
          ThumbTrackpadCalibrationSample(
              surfaceMm = index * 0.4f,
              alongPercent = 0.42f + (index % 2) * 0.01f,
          )
        }

    assertNull(ThumbTrackpadCalibrationEngine.evaluate(samples))
  }

  @Test
  fun calibratedFilterCanProduceBothSignsOnBothAxes() {
    val calibration =
        ThumbTrackpadCalibration(
            minSurfaceMm = -10f,
            maxSurfaceMm = 10f,
            minAlongPercent = 0.20f,
            maxAlongPercent = 0.70f,
        )

    val negative = movedSignal(Point3(-0.018f, 0.018f, 0.009f), calibration)
    val positive = movedSignal(Point3(-0.018f, 0.055f, -0.009f), calibration)

    assertTrue(negative.calibrated)
    assertTrue(negative.stickX < 0f)
    assertTrue(negative.stickY < 0f)
    assertTrue(positive.stickX > 0f)
    assertTrue(positive.stickY > 0f)
  }

  private fun movedSignal(
      movedThumb: Point3,
      calibration: ThumbTrackpadCalibration,
  ): ThumbTrackpadSignal {
    val filter = ThumbIndexTrackpadFilter()
    repeat(2) { filter.update(measurement(Point3(-0.018f, 0.036f, 0f)), calibration) }
    return filter.update(measurement(movedThumb), calibration)
  }

  private fun measurement(thumb: Point3): ThumbTrackpadMeasurement =
      ThumbTrackpadMeasurement(
          thumbTip = thumb,
          indexProximal = Point3(0f, 0f, 0f),
          indexTip = Point3(0f, 0.08f, 0f),
          middleProximal = Point3(0.022f, 0f, 0f),
      )
}
