package com.dearformerself.questinputlab.input

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VirtualInputStateTest {
  @Test
  fun leftHandPinchUsesObservedButtonXBit() {
    assertEquals(0x00000004, primaryButtonMask(isHand = true, side = HandSide.LEFT))
  }

  @Test
  fun completeFramePublishesKeyboardMouseAndGamepadOutputs() {
    val state = VirtualInputState()
    state.updateFrame(
        right = PhysicalInput(source = PhysicalSource.HAND_TRACKING, active = true),
        left = PhysicalInput(source = PhysicalSource.HAND_TRACKING, active = true),
        rightFingers = FingerInput(tracked = true, active = setOf(Finger.INDEX)),
        leftFingers = FingerInput(tracked = true, active = setOf(Finger.MIDDLE)),
        heldKeys = setOf(KeyboardKey.W),
        mouse = MouseState(setOf(MouseButton.LEFT)),
        gamepad = GamepadState(setOf(GamepadButton.A)),
        gestureStatus = "ready",
    )

    assertTrue(state.snapshot().xboxA)
    assertTrue(state.snapshot().keyW)
    assertTrue(state.snapshot().mouse.isHeld(MouseButton.LEFT))
  }

  @Test
  fun changingModesAtomicallyReleasesEveryOutput() {
    val state = VirtualInputState()
    state.updateFrame(
        right = PhysicalInput.NONE,
        left = PhysicalInput.NONE,
        rightFingers = FingerInput.NONE,
        leftFingers = FingerInput.NONE,
        heldKeys = setOf(KeyboardKey.W, KeyboardKey.SPACE),
        mouse = MouseState(setOf(MouseButton.LEFT)),
        gamepad = GamepadState(setOf(GamepadButton.A)),
        gestureStatus = "test",
    )

    state.setMode(InputMode.HAND_XBOX)

    assertEquals(InputMode.HAND_XBOX, state.snapshot().mode)
    assertTrue(state.snapshot().heldKeys.isEmpty())
    assertTrue(state.snapshot().mouse.buttons.isEmpty())
    assertTrue(state.snapshot().gamepad.buttons.isEmpty())
  }

  @Test
  fun releaseAllClearsEveryOutput() {
    val state = VirtualInputState()
    state.updateFrame(
        right = PhysicalInput(active = true, primaryHeld = true),
        left = PhysicalInput(active = true, primaryHeld = true),
        rightFingers = FingerInput(tracked = true, active = setOf(Finger.INDEX)),
        leftFingers = FingerInput(tracked = true, active = setOf(Finger.MIDDLE)),
        heldKeys = setOf(KeyboardKey.W),
        mouse = MouseState(setOf(MouseButton.LEFT)),
        gamepad = GamepadState(setOf(GamepadButton.A)),
        gestureStatus = "test",
    )

    state.releaseAll("test")

    assertFalse(state.snapshot().xboxA)
    assertFalse(state.snapshot().keyW)
    assertTrue(state.snapshot().mouse.buttons.isEmpty())
    assertTrue(state.snapshot().lastReleaseReason == "test")
  }
}
