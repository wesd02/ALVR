package com.dearformerself.questinputlab.input

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FingerConflictResolverTest {
  @Test
  fun simultaneousMiddleRingCouplingChoosesMiddleUntilRingReleases() {
    val resolver = FingerConflictResolver()
    val coupled =
        mapOf(
            Finger.MIDDLE to signal(held = true, bend = 91f, ratio = 0.90f),
            Finger.RING to signal(held = true, bend = 88f, ratio = 0.92f),
        )

    val first = resolver.resolve(coupled)
    assertEquals(setOf(Finger.MIDDLE), first.active)
    assertEquals(setOf(Finger.RING), first.suppressed)
    assertEquals(setOf(Finger.MIDDLE), resolver.resolve(coupled).active)

    resolver.resolve(
        mapOf(
            Finger.MIDDLE to signal(held = true, bend = 91f, ratio = 0.90f),
            Finger.RING to signal(held = false, bend = 20f, ratio = 2.2f),
        ),
    )
    val chord = resolver.resolve(coupled)
    assertEquals(setOf(Finger.MIDDLE, Finger.RING), chord.active)
    assertTrue(chord.suppressed.isEmpty())
  }

  private fun signal(held: Boolean, bend: Float, ratio: Float) =
      FingerGestureSignal(
          usable = true,
          held = held,
          source = FingerGestureSource.JOINT_BEND,
          bendDegrees = bend,
          curlRatio = ratio,
      )
}
