package com.dearformerself.questinputlab.browser

import org.junit.Assert.assertEquals
import org.junit.Test

class ChromiumKeyTest {
  @Test
  fun emailAtKeyUsesShiftedDigitTwo() {
    val key = ChromiumKey.character('@')

    assertEquals("Digit2", key.code)
    assertEquals(50, key.virtualKeyCode)
    assertEquals("@", key.text)
    assertEquals("2", key.unmodifiedText)
    assertEquals(ChromiumKey.SHIFT_MODIFIER, key.modifiers)
  }

  @Test
  fun uppercaseLetterCarriesShiftWhileKeepingPhysicalCode() {
    val key = ChromiumKey.character('W')

    assertEquals("KeyW", key.code)
    assertEquals("W", key.text)
    assertEquals("w", key.unmodifiedText)
    assertEquals(ChromiumKey.SHIFT_MODIFIER, key.modifiers)
  }

  @Test
  fun backspaceDoesNotEmitText() {
    assertEquals("Backspace", ChromiumKey.BACKSPACE.code)
    assertEquals(null, ChromiumKey.BACKSPACE.text)
  }

  @Test
  fun heldModifiersUseChromiumBitMaskValues() {
    assertEquals(8, ChromiumKey.SHIFT.modifiers)
    assertEquals(2, ChromiumKey.CONTROL.modifiers)
    assertEquals(1, ChromiumKey.ALT.modifiers)
  }
}
