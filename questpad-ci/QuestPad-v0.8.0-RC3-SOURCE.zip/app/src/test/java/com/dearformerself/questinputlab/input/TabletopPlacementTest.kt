package com.dearformerself.questinputlab.input

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TabletopPlacementTest {
  @Test
  fun `places keyboard beyond hands and below palm centers`() {
    val pose =
        requireNotNull(
            TabletopPlacement.from(
                TablePlacementSample(
                    leftPalm = Point3(-0.25f, 0.75f, 0.55f),
                    rightPalm = Point3(0.25f, 0.75f, 0.55f),
                    head = Point3(0f, 1.65f, 0f),
                ),
            ),
        )

    assertEquals(0f, pose.center.x, 0.0001f)
    assertTrue(pose.center.y < 0.75f)
    assertTrue(pose.center.z > 0.55f)
    assertEquals(0f, pose.yawDegrees, 0.0001f)
  }

  @Test
  fun `rejects palms that are too close for a deliberate placement`() {
    assertNull(
        TabletopPlacement.from(
            TablePlacementSample(
                leftPalm = Point3(0f, 0.7f, 0.5f),
                rightPalm = Point3(0.05f, 0.7f, 0.5f),
                head = null,
            ),
        ),
    )
  }

  @Test
  fun `scene surface faces keyboard toward viewer`() {
    val pose =
        requireNotNull(
            TabletopPlacement.fromSceneSurface(
                surfaceCenter = Point3(0f, 0.74f, 1f),
                head = Point3(0f, 1.65f, 0f),
            ),
        )

    assertEquals(0f, pose.yawDegrees, 0.0001f)
    assertTrue(pose.center.y > 0.74f)
  }
}
