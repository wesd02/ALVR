package com.dearformerself.questinputlab.browser

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class StrokeMonitorAssetTest {
  @Test
  fun visualizerIncludesEveryFingerAndMappedOutput() {
    val html = strokeMonitorHtml()

    listOf("thumb", "index", "middle", "ring", "little").forEach { finger ->
      assertTrue("Missing finger $finger", html.contains("'$finger'"))
    }
    listOf("Space", "Shift", "W", "A", "S", "D", "E", "R", "LMB", "RMB").forEach {
        output ->
      assertTrue("Missing keyboard/mouse output $output", html.contains("'$output'"))
    }
    listOf("View", "Menu", "L3", "R3", "D↑", "D↓", "D←", "D→").forEach { output ->
      assertTrue("Missing Xbox output $output", html.contains("'$output'"))
    }
  }

  @Test
  fun visualizerSeparatesRecognitionRequestAndTrustedDelivery() {
    val html = strokeMonitorHtml()

    assertTrue(html.contains("STROKE HELD"))
    assertTrue(html.contains("requested"))
    assertTrue(html.contains("trusted held"))
    assertTrue(html.contains("OUTPUT ✓"))
  }

  @Test
  fun visualizerExposesEveryHybridRecognizerMeasurement() {
    val html = strokeMonitorHtml()

    listOf(
            "Joint signals:",
            "hybridUsable",
            "bendDegrees",
            "thumbDistanceMm",
            "palmDistanceMm",
            "sensitivity",
            "SENS = per-finger sensitivity",
            "THUMB CONTACT",
            "JOINT BEND",
            "FALLBACK RATIO",
            "PALM TAP",
        )
        .forEach { label -> assertTrue("Missing hybrid diagnostic $label", html.contains(label)) }
  }

  @Test
  fun visualizerIncludesThumbIndexTrackpadDiagnostics() {
    val html = strokeMonitorHtml()

    listOf(
            "LEFT THUMB × INDEX-SIDE STICK",
            "RIGHT THUMB × INDEX-SIDE TRACKPAD",
            "thumbTrackpad",
            "stickX",
            "stickY",
            "palmSideMm",
            "contactDistanceMm",
            "indexLengthMm",
            "calibrated range",
            "mouse/right stick",
        )
        .forEach { label -> assertTrue("Missing trackpad diagnostic $label", html.contains(label)) }
  }

  private fun strokeMonitorHtml(): String {
    val candidates =
        listOf(
            File("app/src/main/assets/input_tester/index.html"),
            File("src/main/assets/input_tester/index.html"),
        )
    return requireNotNull(candidates.firstOrNull(File::isFile)) {
          "Could not locate the local stroke-monitor asset"
        }
        .readText()
  }
}
