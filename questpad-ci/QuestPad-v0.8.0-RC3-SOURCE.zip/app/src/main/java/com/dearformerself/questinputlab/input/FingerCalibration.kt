package com.dearformerself.questinputlab.input

enum class FingerCalibrationStatus {
  READY,
  NEEDS_SAMPLES,
  SPAN_TOO_SMALL,
  INVERTED,
}

data class FingerCalibrationDiagnostic(
    val status: FingerCalibrationStatus,
    val open: Float? = null,
    val closed: Float? = null,
    val span: Float? = null,
    val press: Float? = null,
    val release: Float? = null,
    val openSamples: Int = 0,
    val closedSamples: Int = 0,
) {
  val calibrated: Boolean
    get() =
        status == FingerCalibrationStatus.READY &&
            press != null &&
            release != null

  internal fun thresholdOrNull(): CurlThreshold? {
    if (!calibrated) return null
    return CurlThreshold(
        press = requireNotNull(press),
        release = requireNotNull(release),
        open = open,
        closed = closed,
    )
  }
}

internal data class CurlThreshold(
    val press: Float,
    val release: Float,
    val open: Float? = null,
    val closed: Float? = null,
)

/** Pure calibration math, kept separate so headset measurements can be regression-tested. */
internal object FingerCalibrationEngine {
  const val MIN_SAMPLE_FRAMES = 18
  const val MIN_CALIBRATION_SPAN = 0.12f
  private const val PRESS_FRACTION = 0.40f
  private const val RELEASE_FRACTION = 0.62f

  fun evaluate(
      openSamples: List<Float>,
      closedSamples: List<Float>,
  ): FingerCalibrationDiagnostic {
    if (openSamples.size < MIN_SAMPLE_FRAMES || closedSamples.size < MIN_SAMPLE_FRAMES) {
      return FingerCalibrationDiagnostic(
          status = FingerCalibrationStatus.NEEDS_SAMPLES,
          open = openSamples.medianOrNull(),
          closed = closedSamples.medianOrNull(),
          span = sampleSpan(openSamples, closedSamples),
          openSamples = openSamples.size,
          closedSamples = closedSamples.size,
      )
    }

    val open = requireNotNull(openSamples.medianOrNull())
    val closed = requireNotNull(closedSamples.medianOrNull())
    val span = open - closed
    if (span <= 0f) {
      return FingerCalibrationDiagnostic(
          status = FingerCalibrationStatus.INVERTED,
          open = open,
          closed = closed,
          span = span,
          openSamples = openSamples.size,
          closedSamples = closedSamples.size,
      )
    }
    if (span < MIN_CALIBRATION_SPAN) {
      return FingerCalibrationDiagnostic(
          status = FingerCalibrationStatus.SPAN_TOO_SMALL,
          open = open,
          closed = closed,
          span = span,
          openSamples = openSamples.size,
          closedSamples = closedSamples.size,
      )
    }

    return FingerCalibrationDiagnostic(
        status = FingerCalibrationStatus.READY,
        open = open,
        closed = closed,
        span = span,
        press = closed + span * PRESS_FRACTION,
        release = closed + span * RELEASE_FRACTION,
        openSamples = openSamples.size,
        closedSamples = closedSamples.size,
    )
  }

  private fun sampleSpan(openSamples: List<Float>, closedSamples: List<Float>): Float? {
    val open = openSamples.medianOrNull() ?: return null
    val closed = closedSamples.medianOrNull() ?: return null
    return open - closed
  }

  private fun List<Float>.medianOrNull(): Float? {
    if (isEmpty()) return null
    val sorted = sorted()
    val middle = sorted.size / 2
    return if (sorted.size % 2 == 0) {
      (sorted[middle - 1] + sorted[middle]) / 2f
    } else {
      sorted[middle]
    }
  }
}
