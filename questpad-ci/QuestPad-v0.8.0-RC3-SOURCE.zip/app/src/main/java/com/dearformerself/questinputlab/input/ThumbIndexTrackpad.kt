package com.dearformerself.questinputlab.input

import kotlin.math.sqrt

data class ThumbTrackpadSignal(
    val enabled: Boolean = false,
    val available: Boolean = false,
    val touching: Boolean = false,
    val active: Boolean = false,
    val stickX: Float = 0f,
    val stickY: Float = 0f,
    val deltaX: Float = 0f,
    val deltaY: Float = 0f,
    val alongPercent: Float? = null,
    val surfaceOffsetMm: Float? = null,
    val palmSideMm: Float? = null,
    val contactDistanceMm: Float? = null,
    val indexLengthMm: Float? = null,
    val calibrated: Boolean = false,
    val calibrationMinSurfaceMm: Float? = null,
    val calibrationMaxSurfaceMm: Float? = null,
    val calibrationMinAlongPercent: Float? = null,
    val calibrationMaxAlongPercent: Float? = null,
    val liftPoseMatched: Boolean = false,
) {
  companion object {
    val NONE = ThumbTrackpadSignal()
    val WAITING = ThumbTrackpadSignal(enabled = true)
  }
}

internal data class ThumbTrackpadMeasurement(
    val thumbTip: Point3?,
    val indexProximal: Point3?,
    val indexTip: Point3?,
    val middleProximal: Point3?,
)

/**
 * Turns the side of the index finger into a tiny two-dimensional trackpad.
 *
 * The coordinate frame follows the index finger, so translating or rotating the whole hand does
 * not create pointer movement. Longitudinal motion follows the index; lateral motion follows the
 * tangent of its thumb-facing side.
 */
internal class ThumbIndexTrackpadFilter {
  private var contactActive = false
  private var transitionFrames = 0
  private var originAlongMeters = 0f
  private var originSurfaceMeters = 0f
  private var previousAlongMeters = 0f
  private var previousSurfaceMeters = 0f
  private var smoothedAlongMeters: Float? = null
  private var smoothedSurfaceMeters: Float? = null
  private var liftedPoseFrames = 0

  fun update(
      measurement: ThumbTrackpadMeasurement,
      calibration: ThumbTrackpadCalibration? = null,
      liftedProfile: ThumbLiftProfile? = null,
  ): ThumbTrackpadSignal {
    val frame = coordinateFrame(measurement) ?: return resetAndNone(calibration)
    smoothedAlongMeters = smooth(smoothedAlongMeters, frame.alongMeters)
    smoothedSurfaceMeters = smooth(smoothedSurfaceMeters, frame.surfaceMeters)
    val along = requireNotNull(smoothedAlongMeters)
    val surface = requireNotNull(smoothedSurfaceMeters)
    val alongPercent = along / frame.indexLengthMeters
    val distanceThreshold =
        if (contactActive) CONTACT_RELEASE_METERS else CONTACT_PRESS_METERS
    val looksLifted =
        liftedProfile?.matches(
            surfaceMm = frame.surfaceMeters * METERS_TO_MILLIMETERS,
            alongPercent = alongPercent,
            palmSideMm = frame.palmSideMeters * METERS_TO_MILLIMETERS,
            distanceMm = frame.contactDistanceMeters * METERS_TO_MILLIMETERS,
        ) == true
    liftedPoseFrames = if (looksLifted) liftedPoseFrames + 1 else 0
    val liftedPoseMatched = liftedPoseFrames >= LIFTED_POSE_TRANSITION_FRAMES
    val rawTouch =
        !liftedPoseMatched &&
            frame.alongPercent in MIN_TRACKPAD_ALONG..MAX_TRACKPAD_ALONG &&
            frame.contactDistanceMeters <= distanceThreshold &&
            frame.palmSideMeters <= MAX_THUMB_SIDE_METERS

    if (rawTouch == contactActive) {
      transitionFrames = 0
    } else {
      transitionFrames++
      if (transitionFrames >= CONTACT_TRANSITION_FRAMES) {
        contactActive = rawTouch
        transitionFrames = 0
        if (contactActive) {
          originAlongMeters = along
          originSurfaceMeters = surface
          previousAlongMeters = along
          previousSurfaceMeters = surface
        }
      }
    }

    // A missing contact stops output immediately even while the release debounce is settling.
    val engaged = contactActive && rawTouch
    if (!engaged) {
      if (contactActive) {
        previousAlongMeters = along
        previousSurfaceMeters = surface
      }
      return ThumbTrackpadSignal(
          enabled = true,
          available = true,
          touching = rawTouch,
          alongPercent = alongPercent,
          surfaceOffsetMm = frame.surfaceMeters * METERS_TO_MILLIMETERS,
          palmSideMm = frame.palmSideMeters * METERS_TO_MILLIMETERS,
          contactDistanceMm = frame.contactDistanceMeters * METERS_TO_MILLIMETERS,
          indexLengthMm = frame.indexLengthMeters * METERS_TO_MILLIMETERS,
          calibrated = calibration != null,
          calibrationMinSurfaceMm = calibration?.minSurfaceMm,
          calibrationMaxSurfaceMm = calibration?.maxSurfaceMm,
          calibrationMinAlongPercent = calibration?.minAlongPercent,
          calibrationMaxAlongPercent = calibration?.maxAlongPercent,
          liftPoseMatched = liftedPoseMatched,
      )
    }

    val deltaX = ((surface - previousSurfaceMeters) / LATERAL_RANGE_METERS).coerceIn(-1f, 1f)
    val deltaY = ((along - previousAlongMeters) / LONGITUDINAL_RANGE_METERS).coerceIn(-1f, 1f)
    previousAlongMeters = along
    previousSurfaceMeters = surface
    val calibratedX = calibration?.stickX(surface * METERS_TO_MILLIMETERS)
    val calibratedY = calibration?.stickY(alongPercent)
    return ThumbTrackpadSignal(
        enabled = true,
        available = true,
        touching = true,
        active = true,
        stickX =
            calibratedX
                ?: ((surface - originSurfaceMeters) / LATERAL_RANGE_METERS).coerceIn(-1f, 1f),
        stickY =
            calibratedY
                ?: ((along - originAlongMeters) / LONGITUDINAL_RANGE_METERS).coerceIn(-1f, 1f),
        deltaX = deltaX,
        deltaY = deltaY,
        alongPercent = alongPercent,
        surfaceOffsetMm = frame.surfaceMeters * METERS_TO_MILLIMETERS,
        palmSideMm = frame.palmSideMeters * METERS_TO_MILLIMETERS,
        contactDistanceMm = frame.contactDistanceMeters * METERS_TO_MILLIMETERS,
        indexLengthMm = frame.indexLengthMeters * METERS_TO_MILLIMETERS,
        calibrated = calibration != null,
        calibrationMinSurfaceMm = calibration?.minSurfaceMm,
        calibrationMaxSurfaceMm = calibration?.maxSurfaceMm,
        calibrationMinAlongPercent = calibration?.minAlongPercent,
        calibrationMaxAlongPercent = calibration?.maxAlongPercent,
        liftPoseMatched = liftedPoseMatched,
    )
  }

  fun reset() {
    contactActive = false
    transitionFrames = 0
    originAlongMeters = 0f
    originSurfaceMeters = 0f
    previousAlongMeters = 0f
    previousSurfaceMeters = 0f
    smoothedAlongMeters = null
    smoothedSurfaceMeters = null
    liftedPoseFrames = 0
  }

  private fun resetAndNone(calibration: ThumbTrackpadCalibration?): ThumbTrackpadSignal {
    reset()
    return ThumbTrackpadSignal(
        enabled = true,
        calibrated = calibration != null,
        calibrationMinSurfaceMm = calibration?.minSurfaceMm,
        calibrationMaxSurfaceMm = calibration?.maxSurfaceMm,
        calibrationMinAlongPercent = calibration?.minAlongPercent,
        calibrationMaxAlongPercent = calibration?.maxAlongPercent,
    )
  }

  private fun coordinateFrame(measurement: ThumbTrackpadMeasurement): TrackpadCoordinate? {
    val thumb = measurement.thumbTip ?: return null
    val indexBase = measurement.indexProximal ?: return null
    val indexTip = measurement.indexTip ?: return null
    val middleBase = measurement.middleProximal ?: return null
    val alongVector = indexTip - indexBase
    val indexLength = alongVector.length()
    if (indexLength !in MIN_INDEX_LENGTH_METERS..MAX_INDEX_LENGTH_METERS) return null
    val alongUnit = alongVector.scaled(1f / indexLength)
    val acrossRaw = middleBase - indexBase
    val acrossProjected = acrossRaw - alongUnit.scaled(acrossRaw.dot(alongUnit))
    val acrossLength = acrossProjected.length()
    if (acrossLength < MIN_BASIS_LENGTH_METERS) return null
    val acrossPalmUnit = acrossProjected.scaled(1f / acrossLength)
    val surfaceUnit = alongUnit.cross(acrossPalmUnit).normalizedOrNull() ?: return null

    val thumbFromBase = thumb - indexBase
    val alongMeters = thumbFromBase.dot(alongUnit)
    val alongPercent = alongMeters / indexLength
    val radial = thumbFromBase - alongUnit.scaled(alongMeters)
    return TrackpadCoordinate(
        alongMeters = alongMeters,
        alongPercent = alongPercent,
        indexLengthMeters = indexLength,
        surfaceMeters = radial.dot(surfaceUnit),
        palmSideMeters = radial.dot(acrossPalmUnit),
        contactDistanceMeters = radial.length(),
    )
  }

  private fun smooth(previous: Float?, current: Float): Float =
      previous?.let { it + (current - it) * SMOOTHING_ALPHA } ?: current

  private data class TrackpadCoordinate(
      val alongMeters: Float,
      val alongPercent: Float,
      val indexLengthMeters: Float,
      val surfaceMeters: Float,
      val palmSideMeters: Float,
      val contactDistanceMeters: Float,
  )

  companion object {
    // Quest hand joints represent bone centers, not the skin surface. The wider gate lets a real
    // thumb claim the index-side control before natural finger curl can become button input.
    private const val CONTACT_PRESS_METERS = 0.036f
    private const val CONTACT_RELEASE_METERS = 0.048f
    private const val MIN_TRACKPAD_ALONG = 0.03f
    private const val MAX_TRACKPAD_ALONG = 0.92f
    private const val MAX_THUMB_SIDE_METERS = 0.006f
    private const val MIN_INDEX_LENGTH_METERS = 0.025f
    private const val MAX_INDEX_LENGTH_METERS = 0.15f
    private const val MIN_BASIS_LENGTH_METERS = 0.004f
    private const val LATERAL_RANGE_METERS = 0.018f
    private const val LONGITUDINAL_RANGE_METERS = 0.035f
    private const val CONTACT_TRANSITION_FRAMES = 2
    private const val LIFTED_POSE_TRANSITION_FRAMES = 3
    private const val SMOOTHING_ALPHA = 0.55f
    private const val METERS_TO_MILLIMETERS = 1_000f
  }
}

private fun Point3.dot(other: Point3): Float = x * other.x + y * other.y + z * other.z

private fun Point3.cross(other: Point3): Point3 =
    Point3(
        y * other.z - z * other.y,
        z * other.x - x * other.z,
        x * other.y - y * other.x,
    )

private fun Point3.length(): Float = sqrt(dot(this))

private fun Point3.scaled(amount: Float): Point3 = Point3(x * amount, y * amount, z * amount)

private fun Point3.normalizedOrNull(): Point3? {
  val length = length()
  return if (length > 0.0001f) scaled(1f / length) else null
}
