package com.dearformerself.questinputlab.ui

import android.annotation.SuppressLint
import android.content.res.ColorStateList
import android.graphics.Color
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import androidx.core.graphics.toColorInt
import com.dearformerself.questinputlab.R
import com.dearformerself.questinputlab.browser.ChromiumKey
import com.dearformerself.questinputlab.input.MouseButton

/** Toggleable spatial keyboard used for login and ordinary browser text fields. */
class KeyboardPanelController(
    private val onKeyTap: (ChromiumKey) -> Unit,
    private val onMouseMove: (Float, Float) -> Unit,
    private val onMouseButton: (MouseButton, Boolean) -> Unit,
    private val onClose: () -> Unit,
) : AutoCloseable {
  private var rootView: View? = null
  private var shiftEnabled = false
  private var symbolsEnabled = false
  private var lastTrackpadX: Float? = null
  private var lastTrackpadY: Float? = null

  @SuppressLint("ClickableViewAccessibility")
  fun attach(root: View) {
    rootView = root
    root.findViewById<Button>(R.id.button_keyboard_close).apply {
      isFocusable = false
      isFocusableInTouchMode = false
      setOnClickListener { onClose() }
    }
    root.findViewById<View>(R.id.mouse_trackpad).apply {
      isFocusable = false
      setOnTouchListener { view, event -> handleTrackpadTouch(view, event) }
    }
    attachMouseButton(root.findViewById(R.id.button_mouse_left), MouseButton.LEFT)
    attachMouseButton(root.findViewById(R.id.button_mouse_right), MouseButton.RIGHT)
    renderKeys()
  }

  private fun handleTrackpadTouch(view: View, event: MotionEvent): Boolean {
    when (event.actionMasked) {
      MotionEvent.ACTION_DOWN -> {
        lastTrackpadX = event.x
        lastTrackpadY = event.y
        view.performClick()
      }
      MotionEvent.ACTION_MOVE -> {
        val oldX = lastTrackpadX
        val oldY = lastTrackpadY
        if (oldX != null && oldY != null) {
          onMouseMove(
              (event.x - oldX).coerceIn(-MAX_TRACKPAD_DELTA, MAX_TRACKPAD_DELTA),
              (event.y - oldY).coerceIn(-MAX_TRACKPAD_DELTA, MAX_TRACKPAD_DELTA),
          )
        }
        lastTrackpadX = event.x
        lastTrackpadY = event.y
      }
      MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
        lastTrackpadX = null
        lastTrackpadY = null
      }
    }
    return true
  }

  private fun attachMouseButton(button: Button, mouseButton: MouseButton) {
    button.apply {
      isFocusable = false
      isFocusableInTouchMode = false
      setOnTouchListener { view, event ->
        when (event.actionMasked) {
          MotionEvent.ACTION_DOWN -> {
            onMouseButton(mouseButton, true)
            view.isPressed = true
            view.performClick()
          }
          MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
            onMouseButton(mouseButton, false)
            view.isPressed = false
          }
        }
        true
      }
    }
  }

  private fun renderKeys() {
    val root = rootView ?: return
    val container = root.findViewById<LinearLayout>(R.id.keyboard_rows)
    container.removeAllViews()

    if (symbolsEnabled) {
      addCharacterRow(container, "!@#$%^&*()")
      addCharacterRow(container, "[]{}<>/\\|~")
      addCharacterRow(container, "`'\":;?+=")
      addCharacterRow(container, ",.-_()")
    } else {
      addCharacterRow(container, "1234567890")
      addCharacterRow(container, "qwertyuiop")
      addCharacterRow(container, "asdfghjkl")
      addRow(
          container,
          listOf(
              KeyButton(
                  label = if (shiftEnabled) "CAPS ✓" else "⇧ CAPS",
                  weight = 1.7f,
                  active = shiftEnabled,
              ) {
                shiftEnabled = !shiftEnabled
                renderKeys()
              },
          ) +
              "zxcvbnm".map { letter -> characterButton(letter) } +
              KeyButton("⌫", weight = 1.7f) { onKeyTap(ChromiumKey.BACKSPACE) },
      )
    }

    addRow(
        container,
        listOf(
            KeyButton(if (symbolsEnabled) "ABC" else "123!?", weight = 1.5f) {
              symbolsEnabled = !symbolsEnabled
              renderKeys()
            },
            KeyButton("Esc", weight = 1.0f) { onKeyTap(ChromiumKey.ESCAPE) },
            KeyButton("Tab", weight = 1.1f) { onKeyTap(ChromiumKey.TAB) },
            KeyButton("@") { onKeyTap(ChromiumKey.character('@')) },
            KeyButton(".com", weight = 1.4f) { typeText(".com") },
            KeyButton("Space", weight = 3.8f) { onKeyTap(ChromiumKey.SPACE) },
            KeyButton("Enter", weight = 1.8f) { onKeyTap(ChromiumKey.ENTER) },
            KeyButton("⌫", weight = 1.2f) { onKeyTap(ChromiumKey.BACKSPACE) },
        ),
    )
  }

  private fun addCharacterRow(container: LinearLayout, characters: String) {
    addRow(container, characters.map(::characterButton))
  }

  private fun characterButton(character: Char): KeyButton {
    val output =
        if (!symbolsEnabled && character.isLetter() && shiftEnabled) {
          character.uppercaseChar()
        } else {
          character
        }
    return KeyButton(output.toString()) { onKeyTap(ChromiumKey.character(output)) }
  }

  private fun typeText(text: String) {
    text.forEach { character -> onKeyTap(ChromiumKey.character(character)) }
  }

  private fun addRow(container: LinearLayout, keys: List<KeyButton>) {
    val context = container.context
    val row =
        LinearLayout(context).apply {
          orientation = LinearLayout.HORIZONTAL
          gravity = Gravity.CENTER
          layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
    keys.forEach { key ->
      row.addView(
          Button(context).apply {
            text = key.label
            isAllCaps = false
            isFocusable = false
            isFocusableInTouchMode = false
            minWidth = 0
            minHeight = 0
            minimumWidth = 0
            minimumHeight = 0
            setPadding(dp(4), 0, dp(4), 0)
            setTextColor(Color.WHITE)
            textSize = if (key.label.length > 4) 13f else 17f
            backgroundTintList =
                ColorStateList.valueOf(
                    (if (key.active) "#167E9B" else "#1A2836").toColorInt(),
                )
            layoutParams =
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, key.weight)
                    .apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
            setOnClickListener { key.action() }
          },
      )
    }
    container.addView(row)
  }

  private fun dp(value: Int): Int {
    val density = rootView?.resources?.displayMetrics?.density ?: 1f
    return (value * density).toInt()
  }

  override fun close() {
    onMouseButton(MouseButton.LEFT, false)
    onMouseButton(MouseButton.RIGHT, false)
    rootView = null
  }

  private data class KeyButton(
      val label: String,
      val weight: Float = 1f,
      val active: Boolean = false,
      val action: () -> Unit,
  )

  companion object {
    private const val MAX_TRACKPAD_DELTA = 100f
  }
}
