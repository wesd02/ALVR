package com.dearformerself.questinputlab.input

/**
 * Prevents one anatomical curl from becoming several buttons while preserving held chords.
 *
 * Middle/ring/pinky often move together. When several begin on the same tracking frame, only the
 * strongest motion owns that onset and the incidental fingers stay blocked until they physically
 * release. A second finger pressed after the first is already held is accepted, so W then A still
 * produces W+A and held gameplay chords remain possible.
 */
internal class FingerConflictResolver {
  private val accepted = mutableSetOf<Finger>()
  private val blockedUntilRelease = mutableSetOf<Finger>()

  fun resolve(signals: Map<Finger, FingerGestureSignal>): FingerConflictResult {
    val rawHeld = signals.filterValues(FingerGestureSignal::held).keys
    accepted.retainAll(rawHeld)
    blockedUntilRelease.retainAll(rawHeld)

    val candidates = rawHeld - accepted - blockedUntilRelease
    val independent = candidates - FLEXION_GROUP
    accepted += independent

    val flexionCandidates = candidates intersect FLEXION_GROUP
    if (flexionCandidates.size == 1) {
      accepted += flexionCandidates
    } else if (flexionCandidates.size > 1) {
      val winner =
          flexionCandidates.maxWithOrNull(
              compareBy<Finger> { intentScore(requireNotNull(signals[it])) }
                  .thenBy { FLEXION_PRIORITY.indexOf(it) },
          )
      if (winner != null) {
        accepted += winner
        blockedUntilRelease += flexionCandidates - winner
      }
    }

    return FingerConflictResult(
        active = accepted.toSet(),
        suppressed = blockedUntilRelease.toSet(),
    )
  }

  fun reset() {
    accepted.clear()
    blockedUntilRelease.clear()
  }

  private fun intentScore(signal: FingerGestureSignal): Float {
    if (signal.source == FingerGestureSource.THUMB_CONTACT) {
      return 1_000f - (signal.thumbDistanceMm ?: 1_000f)
    }
    val bend = signal.bendDegrees ?: 0f
    val ratio = signal.curlRatio?.let { (2.5f - it).coerceAtLeast(0f) * 12f } ?: 0f
    return bend + ratio
  }

  companion object {
    private val FLEXION_GROUP = setOf(Finger.MIDDLE, Finger.RING, Finger.LITTLE)
    // A near-tie from natural middle/ring coupling should prefer middle.
    private val FLEXION_PRIORITY = listOf(Finger.LITTLE, Finger.RING, Finger.MIDDLE)
  }
}

internal data class FingerConflictResult(
    val active: Set<Finger>,
    val suppressed: Set<Finger>,
)
