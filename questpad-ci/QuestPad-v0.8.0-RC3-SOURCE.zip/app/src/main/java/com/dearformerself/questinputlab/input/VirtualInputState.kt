package com.dearformerself.questinputlab.input

import java.util.concurrent.CopyOnWriteArraySet

enum class InputMode(val displayName: String, val shortLabel: String) {
  TOUCH_XBOX("Quest controllers → Xbox", "Touch → Xbox"),
  HAND_XBOX("Hands → invisible Xbox", "Hands → Xbox"),
  HAND_KEYBOARD_MOUSE("Hands → gesture keyboard/mouse", "Hands → K/M"),
  TABLETOP_KEYBOARD_MOUSE("Hands → tabletop keyboard/mouse", "Tabletop K/M"),
}

enum class PhysicalSource(val displayName: String) {
  NONE("Not tracked"),
  TOUCH_CONTROLLER("Touch controller"),
  HAND_TRACKING("Hand tracking"),
}

enum class Finger {
  THUMB,
  INDEX,
  MIDDLE,
  RING,
  LITTLE,
}

enum class KeyboardKey(val displayName: String) {
  W("W"),
  A("A"),
  S("S"),
  D("D"),
  Q("Q"),
  E("E"),
  R("R"),
  F("F"),
  G("G"),
  X("X"),
  Z("Z"),
  C("C"),
  V("V"),
  DIGIT_1("1"),
  DIGIT_2("2"),
  DIGIT_3("3"),
  DIGIT_4("4"),
  DIGIT_5("5"),
  SPACE("Space"),
  SHIFT("Shift"),
  CONTROL("Ctrl"),
  ALT("Alt"),
  TAB("Tab"),
  ESCAPE("Esc"),
}

enum class GamepadButton(val standardIndex: Int, val displayName: String) {
  A(0, "A"),
  B(1, "B"),
  X(2, "X"),
  Y(3, "Y"),
  LEFT_BUMPER(4, "LB"),
  RIGHT_BUMPER(5, "RB"),
  LEFT_TRIGGER(6, "LT"),
  RIGHT_TRIGGER(7, "RT"),
  VIEW(8, "View"),
  MENU(9, "Menu"),
  LEFT_STICK(10, "L3"),
  RIGHT_STICK(11, "R3"),
  DPAD_UP(12, "D↑"),
  DPAD_DOWN(13, "D↓"),
  DPAD_LEFT(14, "D←"),
  DPAD_RIGHT(15, "D→"),
  GUIDE(16, "Xbox"),
}

enum class MouseButton(val cdpName: String, val cdpMask: Int, val displayName: String) {
  LEFT("left", 1, "LMB"),
  RIGHT("right", 2, "RMB"),
}

data class PhysicalInput(
    val source: PhysicalSource = PhysicalSource.NONE,
    val active: Boolean = false,
    val primaryHeld: Boolean = false,
    val rawButtons: Int = 0,
) {
  companion object {
    val NONE = PhysicalInput()
  }
}

data class FingerInput(
    val tracked: Boolean = false,
    val active: Set<Finger> = emptySet(),
    val curlRatios: Map<Finger, Float> = emptyMap(),
    val calibrated: Set<Finger> = emptySet(),
    val calibration: Map<Finger, FingerCalibrationDiagnostic> = emptyMap(),
    val signals: Map<Finger, FingerGestureSignal> = emptyMap(),
    val thumbTrackpad: ThumbTrackpadSignal = ThumbTrackpadSignal.NONE,
) {
  fun isActive(finger: Finger): Boolean = finger in active

  fun isCalibrated(finger: Finger): Boolean = finger in calibrated

  fun isUsable(finger: Finger): Boolean =
      isCalibrated(finger) || signals[finger]?.usable == true

  companion object {
    val NONE = FingerInput()
  }
}

data class GamepadState(
    val buttons: Set<GamepadButton> = emptySet(),
    val leftX: Float = 0f,
    val leftY: Float = 0f,
    val rightX: Float = 0f,
    val rightY: Float = 0f,
) {
  fun isHeld(button: GamepadButton): Boolean = button in buttons

  companion object {
    val NEUTRAL = GamepadState()
  }
}

data class MouseState(
    val buttons: Set<MouseButton> = emptySet(),
    val deltaX: Float = 0f,
    val deltaY: Float = 0f,
) {
  fun isHeld(button: MouseButton): Boolean = button in buttons

  companion object {
    val NEUTRAL = MouseState()
  }
}

data class InputSnapshot(
    val sequence: Long = 0,
    val mode: InputMode = InputMode.HAND_KEYBOARD_MOUSE,
    val right: PhysicalInput = PhysicalInput.NONE,
    val left: PhysicalInput = PhysicalInput.NONE,
    val rightFingers: FingerInput = FingerInput.NONE,
    val leftFingers: FingerInput = FingerInput.NONE,
    val heldKeys: Set<KeyboardKey> = emptySet(),
    val mouse: MouseState = MouseState.NEUTRAL,
    val gamepad: GamepadState = GamepadState.NEUTRAL,
    val gestureStatus: String = "Joint tracking starting",
    val changedAtNanos: Long = 0,
    val lastReleaseReason: String? = null,
) {
  val xboxA: Boolean
    get() = gamepad.isHeld(GamepadButton.A)

  val keyW: Boolean
    get() = KeyboardKey.W in heldKeys
}

/**
 * The single source of truth for every emulated output and all debug-visible input state.
 *
 * Input providers write complete frames. Output sinks listen to snapshots, which guarantees one
 * release-all path for tracking loss, focus loss, mode changes, keyboard overlays, and shutdown.
 */
class VirtualInputState {
  private val listeners = CopyOnWriteArraySet<(InputSnapshot) -> Unit>()

  @Volatile private var current = InputSnapshot()

  fun snapshot(): InputSnapshot = current

  fun addListener(listener: (InputSnapshot) -> Unit): AutoCloseable {
    listeners.add(listener)
    listener(current)
    return AutoCloseable { listeners.remove(listener) }
  }

  fun setMode(mode: InputMode, reason: String = "Input mode changed") {
    val next =
        synchronized(this) {
          if (current.mode == mode) return
          current
              .copy(
                  sequence = current.sequence + 1,
                  mode = mode,
                  right = PhysicalInput.NONE,
                  left = PhysicalInput.NONE,
                  rightFingers = FingerInput.NONE,
                  leftFingers = FingerInput.NONE,
                  heldKeys = emptySet(),
                  mouse = MouseState.NEUTRAL,
                  gamepad = GamepadState.NEUTRAL,
                  changedAtNanos = System.nanoTime(),
                  lastReleaseReason = reason,
              )
              .also { current = it }
        }
    publish(next)
  }

  fun updateFrame(
      right: PhysicalInput,
      left: PhysicalInput,
      rightFingers: FingerInput,
      leftFingers: FingerInput,
      heldKeys: Set<KeyboardKey>,
      mouse: MouseState,
      gamepad: GamepadState,
      gestureStatus: String,
  ) {
    val next =
        synchronized(this) {
          val noMouseMotion = mouse.deltaX == 0f && mouse.deltaY == 0f
          if (
              current.right == right &&
                  current.left == left &&
                  current.rightFingers == rightFingers &&
                  current.leftFingers == leftFingers &&
                  current.heldKeys == heldKeys &&
                  current.mouse.copy(deltaX = 0f, deltaY = 0f) ==
                      mouse.copy(deltaX = 0f, deltaY = 0f) &&
                  current.gamepad == gamepad &&
                  current.gestureStatus == gestureStatus &&
                  current.lastReleaseReason == null &&
                  noMouseMotion
          ) {
            null
          } else {
            current
                .copy(
                    sequence = current.sequence + 1,
                    right = right,
                    left = left,
                    rightFingers = rightFingers,
                    leftFingers = leftFingers,
                    heldKeys = heldKeys.toSet(),
                    mouse = mouse,
                    gamepad = gamepad,
                    gestureStatus = gestureStatus,
                    changedAtNanos = System.nanoTime(),
                    lastReleaseReason = null,
                )
                .also { current = it }
          }
        }
    next?.let(::publish)
  }

  fun releaseAll(reason: String) {
    val next =
        synchronized(this) {
          current
              .copy(
                  sequence = current.sequence + 1,
                  right = PhysicalInput.NONE,
                  left = PhysicalInput.NONE,
                  rightFingers = FingerInput.NONE,
                  leftFingers = FingerInput.NONE,
                  heldKeys = emptySet(),
                  mouse = MouseState.NEUTRAL,
                  gamepad = GamepadState.NEUTRAL,
                  changedAtNanos = System.nanoTime(),
                  lastReleaseReason = reason,
              )
              .also { current = it }
        }
    publish(next)
  }

  private fun publish(snapshot: InputSnapshot) {
    listeners.forEach { listener -> listener(snapshot) }
  }
}
