package com.dearformerself.questinputlab.input

enum class FingerGestureSource(val displayName: String) {
  NONE("idle"),
  THUMB_CONTACT("thumb contact"),
  PERSONAL_MOTION("personal motion"),
  JOINT_BEND("joint bend"),
  PERSONAL_RATIO("personal ratio"),
  FALLBACK_RATIO("fallback ratio"),
  PALM_TAP("palm tap"),
}

enum class FingerSensitivity(val displayName: String) {
  DELIBERATE("deliberate"),
  STANDARD("standard"),
  SENSITIVE("sensitive"),
  EXTRA_SENSITIVE("extra sensitive"),
}

data class FingerGestureSignal(
    val usable: Boolean = false,
    val held: Boolean = false,
    val source: FingerGestureSource = FingerGestureSource.NONE,
    val sensitivity: FingerSensitivity = FingerSensitivity.STANDARD,
    val curlRatio: Float? = null,
    val bendDegrees: Float? = null,
    val thumbDistanceMm: Float? = null,
    val palmDistanceMm: Float? = null,
    val contactActive: Boolean = false,
    val bendActive: Boolean = false,
    val ratioActive: Boolean = false,
    val palmActive: Boolean = false,
    val relativeScore: Float? = null,
    val conflictSuppressed: Boolean = false,
) {
  companion object {
    val NONE = FingerGestureSignal()
  }
}

internal data class HybridFingerMeasurement(
    val curlRatio: Float? = null,
    val bendDegrees: Float? = null,
    val thumbDistanceMm: Float? = null,
    val palmDistanceMm: Float? = null,
    val suppressGesture: Boolean = false,
)

/**
 * Calibration-free recognition using several independent physical measurements.
 *
 * A finger may be held by touching the thumb, bending its joints, or approaching the palm. The
 * older personal ratio remains a fourth signal, but no longer gates the other recognizers.
 */
internal class HybridFingerFilter(private val finger: Finger) {
  private val profile = sensitivityProfile(finger)
  private var held = false
  private var transitionFrames = 0
  private var source = FingerGestureSource.NONE
  private var smoothedRatio: Float? = null
  private var smoothedBend: Float? = null
  private var smoothedThumbDistance: Float? = null
  private var smoothedPalmDistance: Float? = null
  private var baselineBend: Float? = null
  private var baselineRatio: Float? = null
  private var baselinePalmDistance: Float? = null
  private var baselineFrames = 0

  fun update(
      measurement: HybridFingerMeasurement,
      personalThreshold: CurlThreshold?,
      relativeProfile: RelativeFingerProfile? = null,
  ): FingerGestureSignal {
    smoothedRatio = smooth(smoothedRatio, measurement.curlRatio)
    smoothedBend = smooth(smoothedBend, measurement.bendDegrees)
    smoothedThumbDistance = smooth(smoothedThumbDistance, measurement.thumbDistanceMm)
    smoothedPalmDistance = smooth(smoothedPalmDistance, measurement.palmDistanceMm)

    val usable =
        smoothedRatio != null ||
            smoothedBend != null ||
            smoothedThumbDistance != null ||
            smoothedPalmDistance != null
    if (!usable) {
      reset()
      return FingerGestureSignal.NONE
    }

    if (relativeProfile != null &&
        (measurement.suppressGesture || baselineFrames < BASELINE_INITIAL_FRAMES)) {
      observeRelativeBaseline(fast = measurement.suppressGesture)
    }
    val baselineReady = relativeProfile == null || baselineFrames >= BASELINE_INITIAL_FRAMES

    val contactActive =
        finger != Finger.THUMB &&
            smoothedThumbDistance?.let {
              it < if (held) profile.contactReleaseMm else profile.contactPressMm
            } == true
    val bendActive =
        smoothedBend?.let {
          it > if (held) profile.bendReleaseDegrees else profile.bendPressDegrees
        } == true
    val personalRatioActive =
        personalThreshold?.let { threshold ->
          smoothedRatio?.let {
            it <
                if (held) {
                  profile.personalRelease(threshold)
                } else {
                  profile.personalPress(threshold)
                }
          }
        } == true
    val fallbackRatioActive =
        smoothedRatio?.let {
          it < if (held) profile.ratioRelease else profile.ratioPress
        } == true
    val palmActive =
        finger == Finger.THUMB &&
            !measurement.suppressGesture &&
            smoothedPalmDistance?.let {
              it < if (held) profile.palmReleaseMm else profile.palmPressMm
            } == true
    val relativePress = relativeActivity(relativeProfile, releasing = false)
    val relativeRelease = relativeActivity(relativeProfile, releasing = true)

    // Once a stroke begins, its original physical signal owns the release. This prevents a
    // disappearing thumb contact from being kept latched by incidental bend/ratio noise.
    val candidateSource =
        if (held) {
          when (source) {
            FingerGestureSource.THUMB_CONTACT ->
                if (contactActive) FingerGestureSource.THUMB_CONTACT else FingerGestureSource.NONE
            FingerGestureSource.PERSONAL_MOTION ->
                if (relativeRelease.active) FingerGestureSource.PERSONAL_MOTION
                else FingerGestureSource.NONE
            FingerGestureSource.JOINT_BEND ->
                if (bendActive) FingerGestureSource.JOINT_BEND else FingerGestureSource.NONE
            FingerGestureSource.PERSONAL_RATIO ->
                if (personalRatioActive) FingerGestureSource.PERSONAL_RATIO
                else FingerGestureSource.NONE
            FingerGestureSource.FALLBACK_RATIO ->
                if (fallbackRatioActive) FingerGestureSource.FALLBACK_RATIO
                else FingerGestureSource.NONE
            FingerGestureSource.PALM_TAP ->
                if (palmActive) FingerGestureSource.PALM_TAP else FingerGestureSource.NONE
            FingerGestureSource.NONE -> FingerGestureSource.NONE
          }
        } else {
          when {
            measurement.suppressGesture || !baselineReady -> FingerGestureSource.NONE
            contactActive -> FingerGestureSource.THUMB_CONTACT
            relativePress.active -> FingerGestureSource.PERSONAL_MOTION
            relativeProfile == null && bendActive -> FingerGestureSource.JOINT_BEND
            relativeProfile == null && personalRatioActive -> FingerGestureSource.PERSONAL_RATIO
            relativeProfile == null && fallbackRatioActive -> FingerGestureSource.FALLBACK_RATIO
            palmActive -> FingerGestureSource.PALM_TAP
            else -> FingerGestureSource.NONE
          }
        }
    val wantsHeld = candidateSource != FingerGestureSource.NONE
    if (measurement.suppressGesture) {
      held = false
      source = FingerGestureSource.NONE
      transitionFrames = 0
    } else if (wantsHeld == held) {
      transitionFrames = 0
      if (held && candidateSource != FingerGestureSource.NONE) source = candidateSource
    } else {
      transitionFrames++
      if (transitionFrames >= profile.transitionFrames) {
        held = wantsHeld
        source = if (held) candidateSource else FingerGestureSource.NONE
        transitionFrames = 0
      }
    }

    if (!measurement.suppressGesture &&
        relativeProfile != null &&
        baselineReady &&
        !held &&
        candidateSource == FingerGestureSource.NONE) {
      observeRelativeBaseline(fast = false)
    }

    return FingerGestureSignal(
        usable = true,
        held = held,
        source = source,
        sensitivity = profile.sensitivity,
        curlRatio = smoothedRatio,
        bendDegrees = smoothedBend,
        thumbDistanceMm = smoothedThumbDistance,
        palmDistanceMm = smoothedPalmDistance,
        contactActive = contactActive,
        bendActive = bendActive,
        ratioActive = personalRatioActive || fallbackRatioActive,
        palmActive = palmActive,
        relativeScore = relativePress.score,
    )
  }

  fun reset() {
    held = false
    transitionFrames = 0
    source = FingerGestureSource.NONE
    smoothedRatio = null
    smoothedBend = null
    smoothedThumbDistance = null
    smoothedPalmDistance = null
    baselineBend = null
    baselineRatio = null
    baselinePalmDistance = null
    baselineFrames = 0
  }

  private fun relativeActivity(
      profile: RelativeFingerProfile?,
      releasing: Boolean,
  ): RelativeActivity {
    if (profile == null || baselineFrames < BASELINE_INITIAL_FRAMES) return RelativeActivity.NONE
    val scores = buildList {
      val bendThreshold =
          if (releasing) profile.bendReleaseDelta else profile.bendPressDelta
      if (bendThreshold != null && bendThreshold > 0f) {
        val delta =
            baselineBend?.let { baseline -> smoothedBend?.let { current -> current - baseline } }
        delta?.let { add(it / bendThreshold) }
      }
      val ratioThreshold =
          if (releasing) profile.ratioReleaseDelta else profile.ratioPressDelta
      if (ratioThreshold != null && ratioThreshold > 0f) {
        val delta =
            baselineRatio?.let { baseline -> smoothedRatio?.let { current -> baseline - current } }
        delta?.let { add(it / ratioThreshold) }
      }
      val palmThreshold =
          if (releasing) profile.palmReleaseDeltaMm else profile.palmPressDeltaMm
      if (palmThreshold != null && palmThreshold > 0f) {
        val delta =
            baselinePalmDistance?.let { baseline ->
              smoothedPalmDistance?.let { current -> baseline - current }
            }
        delta?.let { add(it / palmThreshold) }
      }
    }
    if (scores.isEmpty()) return RelativeActivity.NONE
    val activeSignals = scores.count { it >= 1f }
    return RelativeActivity(
        active = activeSignals >= profile.requiredSignals.coerceAtMost(scores.size),
        score = scores.sortedDescending().take(profile.requiredSignals).average().toFloat(),
    )
  }

  private fun observeRelativeBaseline(fast: Boolean) {
    val alpha =
        when {
          baselineFrames == 0 -> 1f
          baselineFrames < BASELINE_INITIAL_FRAMES -> 1f / (baselineFrames + 1f)
          fast -> FAST_BASELINE_ALPHA
          else -> IDLE_BASELINE_ALPHA
        }
    baselineBend = blend(baselineBend, smoothedBend, alpha)
    baselineRatio = blend(baselineRatio, smoothedRatio, alpha)
    baselinePalmDistance = blend(baselinePalmDistance, smoothedPalmDistance, alpha)
    baselineFrames++
  }

  private fun blend(previous: Float?, current: Float?, alpha: Float): Float? {
    if (current == null || !current.isFinite()) return previous
    return previous?.let { it + (current - it) * alpha } ?: current
  }

  private fun smooth(previous: Float?, current: Float?): Float? {
    if (current == null || !current.isFinite()) return null
    return previous?.let { it + (current - it) * profile.smoothingAlpha } ?: current
  }

  companion object {
    private const val BASELINE_INITIAL_FRAMES = 8
    private const val FAST_BASELINE_ALPHA = 0.16f
    private const val IDLE_BASELINE_ALPHA = 0.018f

    private fun sensitivityProfile(finger: Finger): FingerSensitivityProfile =
        when (finger) {
          Finger.THUMB ->
              FingerSensitivityProfile(
                  sensitivity = FingerSensitivity.STANDARD,
                  contactPressMm = 36f,
                  contactReleaseMm = 50f,
                  bendPressDegrees = 30f,
                  bendReleaseDegrees = 17f,
                  ratioPress = 1.62f,
                  ratioRelease = 1.88f,
                  palmPressMm = 43f,
                  palmReleaseMm = 56f,
                  personalPressFraction = 0.40f,
                  personalReleaseFraction = 0.62f,
                  transitionFrames = 3,
                  smoothingAlpha = 0.42f,
              )
          Finger.INDEX ->
              FingerSensitivityProfile(
                  sensitivity = FingerSensitivity.STANDARD,
                  contactPressMm = 36f,
                  contactReleaseMm = 50f,
                  bendPressDegrees = 47f,
                  bendReleaseDegrees = 30f,
                  ratioPress = 1.62f,
                  ratioRelease = 1.88f,
                  personalPressFraction = 0.40f,
                  personalReleaseFraction = 0.62f,
                  transitionFrames = 3,
                  smoothingAlpha = 0.42f,
              )
          Finger.MIDDLE ->
              FingerSensitivityProfile(
                  sensitivity = FingerSensitivity.DELIBERATE,
                  contactPressMm = 32f,
                  contactReleaseMm = 43f,
                  bendPressDegrees = 56f,
                  bendReleaseDegrees = 39f,
                  ratioPress = 1.46f,
                  ratioRelease = 1.70f,
                  personalPressFraction = 0.30f,
                  personalReleaseFraction = 0.49f,
                  transitionFrames = 4,
                  smoothingAlpha = 0.35f,
              )
          Finger.RING ->
              FingerSensitivityProfile(
                  sensitivity = FingerSensitivity.SENSITIVE,
                  contactPressMm = 38f,
                  contactReleaseMm = 50f,
                  bendPressDegrees = 43f,
                  bendReleaseDegrees = 31f,
                  ratioPress = 1.68f,
                  ratioRelease = 1.94f,
                  personalPressFraction = 0.44f,
                  personalReleaseFraction = 0.65f,
                  transitionFrames = 3,
                  smoothingAlpha = 0.47f,
              )
          Finger.LITTLE ->
              FingerSensitivityProfile(
                  sensitivity = FingerSensitivity.SENSITIVE,
                  contactPressMm = 37f,
                  contactReleaseMm = 48f,
                  bendPressDegrees = 46f,
                  bendReleaseDegrees = 34f,
                  ratioPress = 1.65f,
                  ratioRelease = 1.84f,
                  personalPressFraction = 0.42f,
                  personalReleaseFraction = 0.60f,
                  transitionFrames = 3,
                  smoothingAlpha = 0.44f,
              )
        }
  }

  private data class RelativeActivity(
      val active: Boolean,
      val score: Float,
  ) {
    companion object {
      val NONE = RelativeActivity(false, 0f)
    }
  }
}

private data class FingerSensitivityProfile(
    val sensitivity: FingerSensitivity,
    val contactPressMm: Float,
    val contactReleaseMm: Float,
    val bendPressDegrees: Float,
    val bendReleaseDegrees: Float,
    val ratioPress: Float,
    val ratioRelease: Float,
    val palmPressMm: Float = 43f,
    val palmReleaseMm: Float = 56f,
    val personalPressFraction: Float,
    val personalReleaseFraction: Float,
    val transitionFrames: Int,
    val smoothingAlpha: Float,
) {
  fun personalPress(threshold: CurlThreshold): Float =
      personalizedThreshold(threshold, personalPressFraction, threshold.press)

  fun personalRelease(threshold: CurlThreshold): Float =
      personalizedThreshold(threshold, personalReleaseFraction, threshold.release)

  private fun personalizedThreshold(
      threshold: CurlThreshold,
      fraction: Float,
      fallback: Float,
  ): Float {
    val open = threshold.open ?: return fallback
    val closed = threshold.closed ?: return fallback
    if (open <= closed) return fallback
    return closed + (open - closed) * fraction
  }
}
