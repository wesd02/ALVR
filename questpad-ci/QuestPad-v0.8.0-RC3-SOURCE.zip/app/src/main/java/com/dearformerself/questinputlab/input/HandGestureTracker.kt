package com.dearformerself.questinputlab.input

import android.content.SharedPreferences
import androidx.core.content.edit
import com.meta.spatial.core.SpatialSDKExperimentalAPI
import com.meta.spatial.core.Vector3
import com.meta.spatial.runtime.ControllerPose
import com.meta.spatial.runtime.JointType
import com.meta.spatial.runtime.Scene
import com.meta.spatial.runtime.SkeletonJoint
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.sqrt

/** Reads body-joint positions and applies headset-specific per-finger calibration. */
@OptIn(SpatialSDKExperimentalAPI::class)
class HandGestureTracker(
    private val scene: Scene,
    private val preferences: SharedPreferences,
) {
  private val jointPoses = mutableListOf<ControllerPose>()
  private val skeletonPoses = mutableListOf<SkeletonJoint>()
  private val leftFilters = Finger.entries.associateWith(::HybridFingerFilter)
  private val rightFilters = Finger.entries.associateWith(::HybridFingerFilter)
  private val leftThumbTrackpad = ThumbIndexTrackpadFilter()
  private val rightThumbTrackpad = ThumbIndexTrackpadFilter()
  private val leftConflictResolver = FingerConflictResolver()
  private val rightConflictResolver = FingerConflictResolver()
  private var thumbTrackpadCalibrations = loadThumbTrackpadCalibrations()
  private var relativeFingerProfiles = loadRelativeFingerProfiles()
  private var thumbLiftProfiles = loadThumbLiftProfiles()
  private var diagnostics: Map<SideFinger, FingerCalibrationDiagnostic> = loadDiagnostics()
  private var thresholds: Map<SideFinger, CurlThreshold> = thresholdsFrom(diagnostics)
  private var calibration: CalibrationRun? = null
  private var thumbTrackpadCalibration: ThumbTrackpadCalibrationRun? = null
  private var calibrationResult: String? = null
  private var unavailableReason: String? = null
  private var retryAfterNanos = 0L

  fun startCalibration() {
    thumbTrackpadCalibration = null
    calibration = CalibrationRun(phaseStartedNanos = System.nanoTime())
    calibrationResult = null
    resetFingerStates()
  }

  fun startThumbTrackpadCalibration() {
    calibration = null
    thumbTrackpadCalibration =
        ThumbTrackpadCalibrationRun(phaseStartedNanos = System.nanoTime())
    calibrationResult = null
    resetFingerStates()
  }

  fun isCalibrating(): Boolean = calibration != null || thumbTrackpadCalibration != null

  fun isFingerCalibrating(): Boolean = calibration != null

  fun isThumbTrackpadCalibrating(): Boolean = thumbTrackpadCalibration != null

  fun cancelCalibration() {
    if (!isCalibrating()) return
    calibration = null
    thumbTrackpadCalibration = null
    calibrationResult = "Calibration canceled"
    resetFingerStates()
  }

  internal fun applyPersonalProfile(profile: PersonalGestureProfile): String {
    if (!profile.usable) return "Personal profile rejected · capture did not contain usable ranges"
    relativeFingerProfiles = relativeFingerProfiles + profile.fingers
    thumbTrackpadCalibrations = thumbTrackpadCalibrations + profile.trackpads
    thumbLiftProfiles = thumbLiftProfiles + profile.liftedThumbs
    saveRelativeFingerProfiles(profile.fingers)
    profile.trackpads.forEach { (side, value) -> saveThumbTrackpadCalibration(side, value) }
    saveThumbLiftProfiles(profile.liftedThumbs)
    calibrationResult = "${profile.summary()} · applied"
    resetFingerStates()
    return requireNotNull(calibrationResult)
  }

  fun read(
      leftActive: Boolean,
      rightActive: Boolean,
      leftTrackpadEnabled: Boolean = false,
      rightTrackpadEnabled: Boolean = true,
  ): HandGestureFrame {
    if (!leftActive && !rightActive) {
      resetFingerStates()
      return HandGestureFrame(
          left = metadataHand(HandSide.LEFT, leftTrackpadEnabled),
          right = metadataHand(HandSide.RIGHT, rightTrackpadEnabled),
          status =
              calibration?.let { "Finger calibration waiting for visible hand joints" }
                  ?: thumbTrackpadCalibration?.let {
                    "Stick tuning waiting for visible left/right hand joints"
                  }
                  ?: "Joint tracking idle · switch to hands",
      )
    }
    val now = System.nanoTime()
    unavailableReason?.let { reason ->
      if (now < retryAfterNanos) {
        return HandGestureFrame(
            left = metadataHand(HandSide.LEFT, leftTrackpadEnabled),
            right = metadataHand(HandSide.RIGHT, rightTrackpadEnabled),
            status = "Joint tracking retrying · $reason · index-pinch fallback active",
        )
      }
    }

    val updated =
        try {
          scene.updateBodyTrackingBuffersAtTime(jointPoses, skeletonPoses).also { success ->
            if (success) unavailableReason = null
          }
        } catch (error: Throwable) {
          unavailableReason =
              (error.message ?: error.javaClass.simpleName).replace('\n', ' ').take(52)
          retryAfterNanos = now + RETRY_INTERVAL_NANOS
          false
        }
    if (!updated || jointPoses.isEmpty()) {
      resetFingerStates()
      return HandGestureFrame(
          left = metadataHand(HandSide.LEFT, leftTrackpadEnabled),
          right = metadataHand(HandSide.RIGHT, rightTrackpadEnabled),
          status = "Waiting for tracked hand joints · index-pinch fallback active",
      )
    }

    val left =
        if (leftActive) {
          readHand(HandSide.LEFT, leftFilters, leftTrackpadEnabled)
        } else {
          metadataHand(HandSide.LEFT, leftTrackpadEnabled)
        }
    val right =
        if (rightActive) {
          readHand(HandSide.RIGHT, rightFilters, rightTrackpadEnabled)
        } else {
          metadataHand(HandSide.RIGHT, rightTrackpadEnabled)
        }
    if (!leftActive) {
      clearHand(leftFilters)
      leftThumbTrackpad.reset()
      leftConflictResolver.reset()
    }
    if (!rightActive) {
      clearHand(rightFilters)
      rightThumbTrackpad.reset()
      rightConflictResolver.reset()
    }

    val calibrationStatus = updateCalibration(now, left, right)
    val thumbTrackpadCalibrationStatus = updateThumbTrackpadCalibration(now, left, right)
    val ready = left.tracked || right.tracked
    val usable = left.signals.count { it.value.usable } + right.signals.count { it.value.usable }
    return HandGestureFrame(
        left = left,
        right = right,
        status =
            calibrationStatus
                ?: thumbTrackpadCalibrationStatus
                ?: calibrationResult
                ?: when {
                  !ready -> "Hand joints invalid · index-pinch fallback active"
                  left.thumbTrackpad.active ->
                      "LEFT THUMB STICK · X %.2f · Y %.2f".format(
                          left.thumbTrackpad.stickX,
                          left.thumbTrackpad.stickY,
                      )
                  right.thumbTrackpad.active ->
                      "RIGHT THUMB TRACKPAD · X %.2f · Y %.2f".format(
                          right.thumbTrackpad.stickX,
                          right.thumbTrackpad.stickY,
                      )
                  else ->
                      "$usable/$TOTAL_FINGERS hybrid stroke signals ready · touch thumb or bend a finger"
                },
    )
  }

  fun reset() {
    resetFingerStates()
  }

  private fun resetFingerStates() {
    clearHand(leftFilters)
    clearHand(rightFilters)
    leftThumbTrackpad.reset()
    rightThumbTrackpad.reset()
    leftConflictResolver.reset()
    rightConflictResolver.reset()
  }

  private fun clearHand(filters: Map<Finger, HybridFingerFilter>) =
      filters.values.forEach(HybridFingerFilter::reset)

  private fun readHand(
      side: HandSide,
      filters: Map<Finger, HybridFingerFilter>,
      trackpadEnabled: Boolean,
  ): TrackedHandPose {
    val left = side == HandSide.LEFT
    val palm = joint(if (left) JointType.LEFT_HAND_PALM else JointType.RIGHT_HAND_PALM)
        ?: return metadataHand(side, trackpadEnabled).also {
          clearHand(filters)
          if (left) leftThumbTrackpad.reset() else rightThumbTrackpad.reset()
          if (left) leftConflictResolver.reset() else rightConflictResolver.reset()
        }
    val definitions = if (left) LEFT_FINGERS else RIGHT_FINGERS
    val tips =
        definitions.mapValues { (_, definition) ->
          joint(definition.tip)
        }
    val proximals =
        definitions.mapValues { (_, definition) ->
          joint(definition.proximal)
        }
    val thumbTip = tips[Finger.THUMB]
    val thumbProximal = proximals[Finger.THUMB]
    val thumbContacts =
        Finger.entries
            .filter { it != Finger.THUMB }
            .mapNotNull { finger ->
              val tip = tips[finger] ?: return@mapNotNull null
              thumbTip?.distanceTo(tip)?.times(METERS_TO_MILLIMETERS)
            }
    val trackpadFilter = if (left) leftThumbTrackpad else rightThumbTrackpad
    val trackpad =
        if (!trackpadEnabled) {
          trackpadFilter.reset()
          ThumbTrackpadSignal.NONE
        } else {
          trackpadFilter.update(
              ThumbTrackpadMeasurement(
                  thumbTip = thumbTip?.toPoint3(),
                  indexProximal = proximals[Finger.INDEX]?.toPoint3(),
                  indexTip = tips[Finger.INDEX]?.toPoint3(),
                  middleProximal = proximals[Finger.MIDDLE]?.toPoint3(),
              ),
              thumbTrackpadCalibrations[side],
              thumbLiftProfiles[side],
          )
        }
    val suppressThumb =
        thumbContacts.any { it < THUMB_CONTACT_SUPPRESSION_MM } || trackpad.touching

    val signals = buildMap {
      definitions.forEach { (finger, definition) ->
        val proximal = proximals[finger]
        val tip = tips[finger]
        val denominator = proximal?.let(palm::distanceTo)
        val ratio =
            if (tip != null && denominator != null && denominator >= MIN_JOINT_DISTANCE_METERS) {
              (palm.distanceTo(tip) / denominator).coerceIn(MIN_CURL_RATIO, MAX_CURL_RATIO)
            } else {
              null
            }
        val thumbDistance =
            if (finger == Finger.THUMB) {
              thumbContacts.minOrNull()
            } else if (thumbTip != null && tip != null) {
              thumbTip.distanceTo(tip) * METERS_TO_MILLIMETERS
            } else {
              null
            }
        val palmDistance = tip?.let { palm.distanceTo(it) * METERS_TO_MILLIMETERS }
        val measurement =
            HybridFingerMeasurement(
                curlRatio = ratio,
                bendDegrees = bendAmount(definition.chain),
                thumbDistanceMm = thumbDistance,
                palmDistanceMm = palmDistance,
                suppressGesture =
                    trackpad.touching || (finger == Finger.THUMB && suppressThumb),
            )
        val filter = requireNotNull(filters[finger])
        put(
            finger,
            filter.update(
                measurement,
                thresholds[SideFinger(side, finger)],
                relativeFingerProfiles[HandFinger(side, finger)],
            ),
        )
      }
    }
    val deepFist = Finger.entries.all { finger -> isDeepFistFinger(finger, signals[finger]) }
    val resolved =
        (if (left) leftConflictResolver else rightConflictResolver).resolve(signals)
    val visibleSignals =
        signals.mapValues { (finger, signal) ->
          when {
            finger in resolved.suppressed ->
                signal.copy(held = false, conflictSuppressed = true)
            signal.held && finger !in resolved.active -> signal.copy(held = false)
            else -> signal
          }
        }
    val ratios =
        visibleSignals.mapNotNull { (finger, signal) ->
          signal.curlRatio?.let { finger to it }
        }.toMap()
    val active = resolved.active
    val thumbInward = visibleSignals[Finger.THUMB]?.palmActive == true
    // LOCAL_FLOOR has a stable up axis.  Requiring the tip to rise above both the thumb base and
    // palm prevents ordinary side-facing thumbs from opening the menu/UI gate.
    val thumbUp =
        thumbTip != null &&
            thumbProximal != null &&
            thumbTip.y - thumbProximal.y >= THUMB_UP_FROM_BASE_METERS &&
            thumbTip.y - palm.y >= THUMB_UP_FROM_PALM_METERS
    return TrackedHandPose(
        tracked = visibleSignals.values.any { it.usable },
        fingers = active,
        palm = Point3(palm.x, palm.y, palm.z),
        curlRatios = ratios,
        calibratedFingers = calibratedFingers(side),
        calibration = diagnosticsFor(side),
        signals = visibleSignals,
        thumbTrackpad = trackpad,
        thumbInward = thumbInward,
        thumbUp = thumbUp,
        deepFist = deepFist,
    )
  }

  private fun isDeepFistFinger(finger: Finger, signal: FingerGestureSignal?): Boolean {
    signal ?: return false
    if (!signal.usable) return false
    if (finger == Finger.THUMB) {
      return signal.palmActive ||
          (signal.palmDistanceMm?.let { it <= FULL_FIST_THUMB_PALM_MM } == true) ||
          (signal.curlRatio?.let { it <= FULL_FIST_RATIO } == true)
    }
    return (signal.bendDegrees?.let { it >= FULL_FIST_BEND_DEGREES } == true) ||
        (signal.curlRatio?.let { it <= FULL_FIST_RATIO } == true)
  }

  private fun Vector3.toPoint3(): Point3 = Point3(x, y, z)

  private fun bendAmount(chain: List<JointType>): Float? {
    val positions = chain.map(::joint)
    val bends =
        (1 until positions.lastIndex).mapNotNull { index ->
          val first = positions[index - 1] ?: return@mapNotNull null
          val middle = positions[index] ?: return@mapNotNull null
          val last = positions[index + 1] ?: return@mapNotNull null
          jointBendDegrees(first, middle, last)
        }
    if (bends.isEmpty()) return null
    return bends.sortedDescending().take(2).average().toFloat()
  }

  private fun jointBendDegrees(first: Vector3, middle: Vector3, last: Vector3): Float? {
    val ax = first.x - middle.x
    val ay = first.y - middle.y
    val az = first.z - middle.z
    val bx = last.x - middle.x
    val by = last.y - middle.y
    val bz = last.z - middle.z
    val aLength = sqrt(ax * ax + ay * ay + az * az)
    val bLength = sqrt(bx * bx + by * by + bz * bz)
    if (aLength < MIN_JOINT_SEGMENT_METERS || bLength < MIN_JOINT_SEGMENT_METERS) return null
    val cosine = ((ax * bx + ay * by + az * bz) / (aLength * bLength)).coerceIn(-1f, 1f)
    val angle = acos(cosine.toDouble()) * 180.0 / PI
    return (180.0 - angle).toFloat().coerceIn(0f, 180f)
  }

  private fun metadataHand(
      side: HandSide,
      trackpadEnabled: Boolean = false,
  ): TrackedHandPose =
      TrackedHandPose(
          calibratedFingers = calibratedFingers(side),
          calibration = diagnosticsFor(side),
          thumbTrackpad =
              if (trackpadEnabled) {
                val calibration = thumbTrackpadCalibrations[side]
                ThumbTrackpadSignal(
                    enabled = true,
                    calibrated = calibration != null,
                    calibrationMinSurfaceMm = calibration?.minSurfaceMm,
                    calibrationMaxSurfaceMm = calibration?.maxSurfaceMm,
                    calibrationMinAlongPercent = calibration?.minAlongPercent,
                    calibrationMaxAlongPercent = calibration?.maxAlongPercent,
                )
              } else {
                ThumbTrackpadSignal.NONE
              },
      )

  private fun calibratedFingers(side: HandSide): Set<Finger> = buildSet {
    thresholds.keys.filter { it.side == side }.forEach { add(it.finger) }
    relativeFingerProfiles.keys.filter { it.side == side }.forEach { add(it.finger) }
  }

  private fun diagnosticsFor(side: HandSide): Map<Finger, FingerCalibrationDiagnostic> =
      diagnostics
          .filterKeys { it.side == side }
          .mapKeys { it.key.finger }

  private fun updateCalibration(
      now: Long,
      left: TrackedHandPose,
      right: TrackedHandPose,
  ): String? {
    val run = calibration ?: return null
    val phaseElapsed = now - run.phaseStartedNanos
    when (run.phase) {
      CalibrationPhase.PREPARE_OPEN -> {
        if (phaseElapsed >= PREPARE_OPEN_NANOS) run.advance(CalibrationPhase.SAMPLE_OPEN, now)
        return "CALIBRATION 1/2 · hold both hands fully open and apart"
      }
      CalibrationPhase.SAMPLE_OPEN -> {
        run.addSamples(left, right, open = true)
        if (phaseElapsed >= SAMPLE_NANOS && run.hasEnoughSamples(open = true)) {
          run.advance(CalibrationPhase.PREPARE_CLOSED, now)
        }
        return if (left.tracked || right.tracked) {
          "CALIBRATION 1/2 · measuring open hands · keep still"
        } else {
          "CALIBRATION 1/2 · waiting for visible fingers"
        }
      }
      CalibrationPhase.PREPARE_CLOSED -> {
        if (phaseElapsed >= PREPARE_CLOSED_NANOS) {
          run.advance(CalibrationPhase.SAMPLE_CLOSED, now)
        }
        return "CALIBRATION 2/2 · close both hands into comfortable fists"
      }
      CalibrationPhase.SAMPLE_CLOSED -> {
        run.addSamples(left, right, open = false)
        if (phaseElapsed >= SAMPLE_NANOS && run.hasEnoughSamples(open = false)) {
          finishCalibration(run)
          return calibrationResult
        }
        return if (left.tracked || right.tracked) {
          "CALIBRATION 2/2 · measuring closed hands · keep still"
        } else {
          "CALIBRATION 2/2 · waiting for visible fingers"
        }
      }
    }
  }

  private fun finishCalibration(run: CalibrationRun) {
    val result = buildMap<SideFinger, FingerCalibrationDiagnostic> {
      HandSide.entries.forEach { side ->
        Finger.entries.forEach { finger ->
          val key = SideFinger(side, finger)
          put(
              key,
              FingerCalibrationEngine.evaluate(
                  run.openSamples[key].orEmpty(),
                  run.closedSamples[key].orEmpty(),
              ),
          )
        }
      }
    }
    calibration = null
    diagnostics = result
    thresholds = thresholdsFrom(result)
    saveDiagnostics(result)
    calibrationResult = calibrationSummary(result)
    resetFingerStates()
  }

  private fun updateThumbTrackpadCalibration(
      now: Long,
      left: TrackedHandPose,
      right: TrackedHandPose,
  ): String? {
    val run = thumbTrackpadCalibration ?: return null
    val elapsed = now - run.phaseStartedNanos
    return when (run.phase) {
      ThumbTrackpadCalibrationPhase.PREPARE_LEFT -> {
        if (!left.thumbTrackpad.touching) {
          run.phaseStartedNanos = now
        } else if (elapsed >= THUMB_TRACKPAD_PREPARE_NANOS) {
          run.advance(ThumbTrackpadCalibrationPhase.SAMPLE_LEFT, now)
        }
        "STICK TUNE 1/2 · relax right hand · touch and hold LEFT thumb on index side"
      }
      ThumbTrackpadCalibrationPhase.SAMPLE_LEFT -> {
        run.addSample(HandSide.LEFT, left)
        if (elapsed >= THUMB_TRACKPAD_SAMPLE_NANOS) {
          run.advance(ThumbTrackpadCalibrationPhase.PREPARE_RIGHT, now)
        }
        "STICK TUNE 1/2 · sweep LEFT thumb fully: left, right, tip, and base"
      }
      ThumbTrackpadCalibrationPhase.PREPARE_RIGHT -> {
        if (!right.thumbTrackpad.touching) {
          run.phaseStartedNanos = now
        } else if (elapsed >= THUMB_TRACKPAD_PREPARE_NANOS) {
          run.advance(ThumbTrackpadCalibrationPhase.SAMPLE_RIGHT, now)
        }
        "STICK TUNE 2/2 · relax left hand · touch and hold RIGHT thumb on index side"
      }
      ThumbTrackpadCalibrationPhase.SAMPLE_RIGHT -> {
        run.addSample(HandSide.RIGHT, right)
        if (elapsed >= THUMB_TRACKPAD_SAMPLE_NANOS) {
          finishThumbTrackpadCalibration(run)
          calibrationResult ?: "Stick tuning finished"
        } else {
          "STICK TUNE 2/2 · sweep RIGHT thumb fully: left, right, tip, and base"
        }
      }
    }
  }

  private fun finishThumbTrackpadCalibration(run: ThumbTrackpadCalibrationRun) {
    val learned =
        HandSide.entries.associateWith { side ->
          ThumbTrackpadCalibrationEngine.evaluate(run.samples[side].orEmpty())
        }
    learned.forEach { (side, value) ->
      if (value != null) {
        thumbTrackpadCalibrations = thumbTrackpadCalibrations + (side to value)
        saveThumbTrackpadCalibration(side, value)
      }
    }
    val summary =
        HandSide.entries.joinToString(" · ") { side ->
          val value = learned[side]
          if (value == null) {
            "${side.name} RETRY"
          } else {
            "${side.name} OK X${"%.0f".format(value.surfaceSpanMm)}mm " +
                "Y${"%.0f".format(value.alongSpan * 100f)}%"
          }
        }
    thumbTrackpadCalibration = null
    calibrationResult = "STICK TUNE · $summary"
    resetFingerStates()
  }

  private fun calibrationSummary(
      result: Map<SideFinger, FingerCalibrationDiagnostic>,
  ): String {
    val ready = result.count { it.value.calibrated }
    if (ready == TOTAL_FINGERS) return "Calibration saved · all ten fingers ready"
    val failed =
        result
            .filterValues { !it.calibrated }
            .keys
            .map { "${if (it.side == HandSide.LEFT) "L" else "R"} ${it.finger.shortName()}" }
    val shown = failed.take(MAX_FAILED_FINGERS_IN_STATUS).joinToString(", ")
    val remainder = failed.size - MAX_FAILED_FINGERS_IN_STATUS
    val suffix = if (remainder > 0) ", +$remainder more" else ""
    return "Calibration saved $ready/$TOTAL_FINGERS · retry $shown$suffix"
  }

  private fun Finger.shortName(): String = name.lowercase().replaceFirstChar { it.uppercase() }

  private fun loadThumbTrackpadCalibrations(): Map<HandSide, ThumbTrackpadCalibration> =
      buildMap {
        HandSide.entries.forEach { side ->
          val prefix = thumbTrackpadPreferencePrefix(side)
          val minSurface = preferences.floatOrNull("${prefix}_min_surface_mm")
          val maxSurface = preferences.floatOrNull("${prefix}_max_surface_mm")
          val minAlong = preferences.floatOrNull("${prefix}_min_along")
          val maxAlong = preferences.floatOrNull("${prefix}_max_along")
          if (minSurface != null &&
              maxSurface != null &&
              minAlong != null &&
              maxAlong != null &&
              maxSurface > minSurface &&
              maxAlong > minAlong) {
            put(
                side,
                ThumbTrackpadCalibration(
                    minSurfaceMm = minSurface,
                    maxSurfaceMm = maxSurface,
                    minAlongPercent = minAlong,
                    maxAlongPercent = maxAlong,
                ),
            )
          }
        }
      }

  private fun saveThumbTrackpadCalibration(
      side: HandSide,
      value: ThumbTrackpadCalibration,
  ) {
    val prefix = thumbTrackpadPreferencePrefix(side)
    preferences.edit {
      putFloat("${prefix}_min_surface_mm", value.minSurfaceMm)
      putFloat("${prefix}_max_surface_mm", value.maxSurfaceMm)
      putFloat("${prefix}_min_along", value.minAlongPercent)
      putFloat("${prefix}_max_along", value.maxAlongPercent)
    }
  }

  private fun thumbTrackpadPreferencePrefix(side: HandSide): String =
      "thumb_trackpad_${side.name.lowercase()}"

  private fun loadRelativeFingerProfiles(): Map<HandFinger, RelativeFingerProfile> =
      buildMap {
        HandSide.entries.forEach { side ->
          listOf(Finger.MIDDLE, Finger.RING, Finger.LITTLE).forEach { finger ->
            val prefix = relativeFingerPreferencePrefix(side, finger)
            val value =
                RelativeFingerProfile(
                    bendPressDelta = preferences.floatOrNull("${prefix}_bend_press"),
                    bendReleaseDelta = preferences.floatOrNull("${prefix}_bend_release"),
                    ratioPressDelta = preferences.floatOrNull("${prefix}_ratio_press"),
                    ratioReleaseDelta = preferences.floatOrNull("${prefix}_ratio_release"),
                    palmPressDeltaMm = preferences.floatOrNull("${prefix}_palm_press"),
                    palmReleaseDeltaMm = preferences.floatOrNull("${prefix}_palm_release"),
                    requiredSignals = preferences.getInt("${prefix}_required", 2),
                )
            if (value.usable) put(HandFinger(side, finger), value)
          }
        }
      }

  private fun saveRelativeFingerProfiles(values: Map<HandFinger, RelativeFingerProfile>) {
    preferences.edit {
      values.forEach { (key, value) ->
        val prefix = relativeFingerPreferencePrefix(key.side, key.finger)
        value.bendPressDelta?.let { putFloat("${prefix}_bend_press", it) }
        value.bendReleaseDelta?.let { putFloat("${prefix}_bend_release", it) }
        value.ratioPressDelta?.let { putFloat("${prefix}_ratio_press", it) }
        value.ratioReleaseDelta?.let { putFloat("${prefix}_ratio_release", it) }
        value.palmPressDeltaMm?.let { putFloat("${prefix}_palm_press", it) }
        value.palmReleaseDeltaMm?.let { putFloat("${prefix}_palm_release", it) }
        putInt("${prefix}_required", value.requiredSignals)
      }
    }
  }

  private fun relativeFingerPreferencePrefix(side: HandSide, finger: Finger): String =
      "personal_motion_${side.name.lowercase()}_${finger.name.lowercase()}"

  private fun loadThumbLiftProfiles(): Map<HandSide, ThumbLiftProfile> =
      buildMap {
        HandSide.entries.forEach { side ->
          val prefix = thumbLiftPreferencePrefix(side)
          val surface = preferences.floatOrNull("${prefix}_surface") ?: return@forEach
          val surfaceTolerance =
              preferences.floatOrNull("${prefix}_surface_tolerance") ?: return@forEach
          val along = preferences.floatOrNull("${prefix}_along") ?: return@forEach
          val alongTolerance =
              preferences.floatOrNull("${prefix}_along_tolerance") ?: return@forEach
          val palm = preferences.floatOrNull("${prefix}_palm") ?: return@forEach
          val palmTolerance =
              preferences.floatOrNull("${prefix}_palm_tolerance") ?: return@forEach
          val distance = preferences.floatOrNull("${prefix}_distance") ?: return@forEach
          val distanceTolerance =
              preferences.floatOrNull("${prefix}_distance_tolerance") ?: return@forEach
          put(
              side,
              ThumbLiftProfile(
                  surface,
                  surfaceTolerance,
                  along,
                  alongTolerance,
                  palm,
                  palmTolerance,
                  distance,
                  distanceTolerance,
              ),
          )
        }
      }

  private fun saveThumbLiftProfiles(values: Map<HandSide, ThumbLiftProfile>) {
    preferences.edit {
      values.forEach { (side, value) ->
        val prefix = thumbLiftPreferencePrefix(side)
        putFloat("${prefix}_surface", value.surfaceCenterMm)
        putFloat("${prefix}_surface_tolerance", value.surfaceToleranceMm)
        putFloat("${prefix}_along", value.alongCenter)
        putFloat("${prefix}_along_tolerance", value.alongTolerance)
        putFloat("${prefix}_palm", value.palmSideCenterMm)
        putFloat("${prefix}_palm_tolerance", value.palmSideToleranceMm)
        putFloat("${prefix}_distance", value.distanceCenterMm)
        putFloat("${prefix}_distance_tolerance", value.distanceToleranceMm)
      }
    }
  }

  private fun thumbLiftPreferencePrefix(side: HandSide): String =
      "thumb_lift_${side.name.lowercase()}"

  private fun loadDiagnostics(): Map<SideFinger, FingerCalibrationDiagnostic> {
    val result = mutableMapOf<SideFinger, FingerCalibrationDiagnostic>()
    HandSide.entries.forEach { side ->
      Finger.entries.forEach { finger ->
        val prefix = preferencePrefix(side, finger)
        val hasThreshold =
            preferences.contains("${prefix}_press") && preferences.contains("${prefix}_release")
        val storedStatus =
            preferences.getString("${prefix}_status", null)?.let {
              runCatching { FingerCalibrationStatus.valueOf(it) }.getOrNull()
            }
        if (!hasThreshold && storedStatus == null) return@forEach
        val press = preferences.floatOrNull("${prefix}_press")
        val release = preferences.floatOrNull("${prefix}_release")
        val status =
            if (hasThreshold && press != null && release != null && press < release) {
              FingerCalibrationStatus.READY
            } else {
              storedStatus
                  ?.takeUnless { it == FingerCalibrationStatus.READY }
                  ?: FingerCalibrationStatus.NEEDS_SAMPLES
            }
        result[SideFinger(side, finger)] =
            FingerCalibrationDiagnostic(
                status = status,
                open = preferences.floatOrNull("${prefix}_open"),
                closed = preferences.floatOrNull("${prefix}_closed"),
                span = preferences.floatOrNull("${prefix}_span"),
                press = if (status == FingerCalibrationStatus.READY) press else null,
                release = if (status == FingerCalibrationStatus.READY) release else null,
                openSamples = preferences.getInt("${prefix}_open_samples", 0),
                closedSamples = preferences.getInt("${prefix}_closed_samples", 0),
            )
      }
    }
    return result
  }

  private fun SharedPreferences.floatOrNull(key: String): Float? =
      if (contains(key)) getFloat(key, 0f).takeIf { it.isFinite() } else null

  private fun thresholdsFrom(
      values: Map<SideFinger, FingerCalibrationDiagnostic>,
  ): Map<SideFinger, CurlThreshold> = buildMap {
    values.forEach { (key, diagnostic) ->
      diagnostic.thresholdOrNull()?.let { put(key, it) }
    }
  }

  private fun saveDiagnostics(values: Map<SideFinger, FingerCalibrationDiagnostic>) {
    preferences.edit {
      HandSide.entries.forEach { side ->
        Finger.entries.forEach { finger ->
          val prefix = preferencePrefix(side, finger)
          CALIBRATION_SUFFIXES.forEach { suffix -> remove("${prefix}_$suffix") }
        }
      }
      values.forEach { (key, diagnostic) ->
        val prefix = preferencePrefix(key.side, key.finger)
        putString("${prefix}_status", diagnostic.status.name)
        diagnostic.open?.let { putFloat("${prefix}_open", it) }
        diagnostic.closed?.let { putFloat("${prefix}_closed", it) }
        diagnostic.span?.let { putFloat("${prefix}_span", it) }
        diagnostic.press?.let { putFloat("${prefix}_press", it) }
        diagnostic.release?.let { putFloat("${prefix}_release", it) }
        putInt("${prefix}_open_samples", diagnostic.openSamples)
        putInt("${prefix}_closed_samples", diagnostic.closedSamples)
      }
    }
  }

  private fun preferencePrefix(side: HandSide, finger: Finger): String =
      "curl_${side.name.lowercase()}_${finger.name.lowercase()}"

  private fun joint(type: JointType): Vector3? {
    val index = type.index
    if (index !in jointPoses.indices) return null
    val joint = jointPoses[index]
    if (joint.flags and ControllerPose.ValidBits == 0) return null
    return joint.pose.t
  }

  private data class FingerJoints(
      val chain: List<JointType>,
      val proximal: JointType,
      val tip: JointType,
  )

  private data class SideFinger(val side: HandSide, val finger: Finger)

  private enum class CalibrationPhase {
    PREPARE_OPEN,
    SAMPLE_OPEN,
    PREPARE_CLOSED,
    SAMPLE_CLOSED,
  }

  private enum class ThumbTrackpadCalibrationPhase {
    PREPARE_LEFT,
    SAMPLE_LEFT,
    PREPARE_RIGHT,
    SAMPLE_RIGHT,
  }

  private data class ThumbTrackpadCalibrationRun(
      var phase: ThumbTrackpadCalibrationPhase = ThumbTrackpadCalibrationPhase.PREPARE_LEFT,
      var phaseStartedNanos: Long,
      val samples:
          MutableMap<HandSide, MutableList<ThumbTrackpadCalibrationSample>> = mutableMapOf(),
  ) {
    fun advance(next: ThumbTrackpadCalibrationPhase, now: Long) {
      phase = next
      phaseStartedNanos = now
    }

    fun addSample(side: HandSide, pose: TrackedHandPose) {
      val trackpad = pose.thumbTrackpad
      val surface = trackpad.surfaceOffsetMm
      val along = trackpad.alongPercent
      if (!trackpad.touching || surface == null || along == null) return
      samples
          .getOrPut(side) { mutableListOf() }
          .add(ThumbTrackpadCalibrationSample(surface, along))
    }
  }

  private data class CalibrationRun(
      var phase: CalibrationPhase = CalibrationPhase.PREPARE_OPEN,
      var phaseStartedNanos: Long,
      val openSamples: MutableMap<SideFinger, MutableList<Float>> = mutableMapOf(),
      val closedSamples: MutableMap<SideFinger, MutableList<Float>> = mutableMapOf(),
  ) {
    fun advance(next: CalibrationPhase, now: Long) {
      phase = next
      phaseStartedNanos = now
    }

    fun addSamples(left: TrackedHandPose, right: TrackedHandPose, open: Boolean) {
      val target = if (open) openSamples else closedSamples
      addHand(target, HandSide.LEFT, left)
      addHand(target, HandSide.RIGHT, right)
    }

    fun hasEnoughSamples(open: Boolean): Boolean =
        (if (open) openSamples else closedSamples).values.any {
          it.size >= FingerCalibrationEngine.MIN_SAMPLE_FRAMES
        }

    private fun addHand(
        target: MutableMap<SideFinger, MutableList<Float>>,
        side: HandSide,
        pose: TrackedHandPose,
    ) {
      pose.curlRatios.forEach { (finger, ratio) ->
        val key = SideFinger(side, finger)
        target.getOrPut(key) { mutableListOf() }.add(ratio)
      }
    }
  }

  companion object {
    private const val MIN_JOINT_DISTANCE_METERS = 0.012f
    private const val MIN_JOINT_SEGMENT_METERS = 0.004f
    private const val MIN_CURL_RATIO = 0.30f
    private const val MAX_CURL_RATIO = 4.50f
    private const val FULL_FIST_RATIO = 1.48f
    private const val FULL_FIST_BEND_DEGREES = 58f
    private const val FULL_FIST_THUMB_PALM_MM = 44f
    private const val METERS_TO_MILLIMETERS = 1_000f
    private const val THUMB_CONTACT_SUPPRESSION_MM = 48f
    private const val THUMB_UP_FROM_BASE_METERS = 0.025f
    private const val THUMB_UP_FROM_PALM_METERS = 0.040f
    private const val PREPARE_OPEN_NANOS = 2_000_000_000L
    private const val PREPARE_CLOSED_NANOS = 2_500_000_000L
    private const val SAMPLE_NANOS = 1_200_000_000L
    private const val THUMB_TRACKPAD_PREPARE_NANOS = 1_500_000_000L
    private const val THUMB_TRACKPAD_SAMPLE_NANOS = 4_000_000_000L
    private const val RETRY_INTERVAL_NANOS = 2_000_000_000L
    private const val TOTAL_FINGERS = 10
    private const val MAX_FAILED_FINGERS_IN_STATUS = 4
    private val CALIBRATION_SUFFIXES =
        listOf(
            "status",
            "open",
            "closed",
            "span",
            "press",
            "release",
            "open_samples",
            "closed_samples",
        )

    private fun fingerJoints(vararg chain: JointType): FingerJoints =
        FingerJoints(
            chain = chain.toList(),
            proximal = chain[1],
            tip = chain.last(),
        )

    private val LEFT_FINGERS =
        mapOf(
            Finger.THUMB to
                fingerJoints(
                    JointType.LEFT_HAND_THUMB_METACARPAL,
                    JointType.LEFT_HAND_THUMB_PROXIMAL,
                    JointType.LEFT_HAND_THUMB_DISTAL,
                    JointType.LEFT_HAND_THUMB_TIP,
                ),
            Finger.INDEX to
                fingerJoints(
                    JointType.LEFT_HAND_INDEX_METACARPAL,
                    JointType.LEFT_HAND_INDEX_PROXIMAL,
                    JointType.LEFT_HAND_INDEX_INTERMEDIATE,
                    JointType.LEFT_HAND_INDEX_DISTAL,
                    JointType.LEFT_HAND_INDEX_TIP,
                ),
            Finger.MIDDLE to
                fingerJoints(
                    JointType.LEFT_HAND_MIDDLE_METACARPAL,
                    JointType.LEFT_HAND_MIDDLE_PROXIMAL,
                    JointType.LEFT_HAND_MIDDLE_INTERMEDIATE,
                    JointType.LEFT_HAND_MIDDLE_DISTAL,
                    JointType.LEFT_HAND_MIDDLE_TIP,
                ),
            Finger.RING to
                fingerJoints(
                    JointType.LEFT_HAND_RING_METACARPAL,
                    JointType.LEFT_HAND_RING_PROXIMAL,
                    JointType.LEFT_HAND_RING_INTERMEDIATE,
                    JointType.LEFT_HAND_RING_DISTAL,
                    JointType.LEFT_HAND_RING_TIP,
                ),
            Finger.LITTLE to
                fingerJoints(
                    JointType.LEFT_HAND_LITTLE_METACARPAL,
                    JointType.LEFT_HAND_LITTLE_PROXIMAL,
                    JointType.LEFT_HAND_LITTLE_INTERMEDIATE,
                    JointType.LEFT_HAND_LITTLE_DISTAL,
                    JointType.LEFT_HAND_LITTLE_TIP,
                ),
        )
    private val RIGHT_FINGERS =
        mapOf(
            Finger.THUMB to
                fingerJoints(
                    JointType.RIGHT_HAND_THUMB_METACARPAL,
                    JointType.RIGHT_HAND_THUMB_PROXIMAL,
                    JointType.RIGHT_HAND_THUMB_DISTAL,
                    JointType.RIGHT_HAND_THUMB_TIP,
                ),
            Finger.INDEX to
                fingerJoints(
                    JointType.RIGHT_HAND_INDEX_METACARPAL,
                    JointType.RIGHT_HAND_INDEX_PROXIMAL,
                    JointType.RIGHT_HAND_INDEX_INTERMEDIATE,
                    JointType.RIGHT_HAND_INDEX_DISTAL,
                    JointType.RIGHT_HAND_INDEX_TIP,
                ),
            Finger.MIDDLE to
                fingerJoints(
                    JointType.RIGHT_HAND_MIDDLE_METACARPAL,
                    JointType.RIGHT_HAND_MIDDLE_PROXIMAL,
                    JointType.RIGHT_HAND_MIDDLE_INTERMEDIATE,
                    JointType.RIGHT_HAND_MIDDLE_DISTAL,
                    JointType.RIGHT_HAND_MIDDLE_TIP,
                ),
            Finger.RING to
                fingerJoints(
                    JointType.RIGHT_HAND_RING_METACARPAL,
                    JointType.RIGHT_HAND_RING_PROXIMAL,
                    JointType.RIGHT_HAND_RING_INTERMEDIATE,
                    JointType.RIGHT_HAND_RING_DISTAL,
                    JointType.RIGHT_HAND_RING_TIP,
                ),
            Finger.LITTLE to
                fingerJoints(
                    JointType.RIGHT_HAND_LITTLE_METACARPAL,
                    JointType.RIGHT_HAND_LITTLE_PROXIMAL,
                    JointType.RIGHT_HAND_LITTLE_INTERMEDIATE,
                    JointType.RIGHT_HAND_LITTLE_DISTAL,
                    JointType.RIGHT_HAND_LITTLE_TIP,
                ),
        )
  }
}
