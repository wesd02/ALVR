package com.dearformerself.questinputlab.input

/** Persistent anatomical range learned independently for one thumb-on-index surface. */
data class ThumbTrackpadCalibration(
    val minSurfaceMm: Float,
    val maxSurfaceMm: Float,
    val minAlongPercent: Float,
    val maxAlongPercent: Float,
) {
  val surfaceSpanMm: Float
    get() = maxSurfaceMm - minSurfaceMm

  val alongSpan: Float
    get() = maxAlongPercent - minAlongPercent

  fun stickX(surfaceMm: Float): Float = normalize(surfaceMm, minSurfaceMm, maxSurfaceMm)

  fun stickY(alongPercent: Float): Float =
      normalize(alongPercent, minAlongPercent, maxAlongPercent)

  private fun normalize(value: Float, minimum: Float, maximum: Float): Float {
    if (!value.isFinite() || maximum <= minimum) return 0f
    return (((value - minimum) / (maximum - minimum)) * 2f - 1f).coerceIn(-1f, 1f)
  }
}

data class ThumbTrackpadCalibrationSample(
    val surfaceMm: Float,
    val alongPercent: Float,
)

/** Rejects tracking spikes and requires useful travel on both axes before saving a profile. */
object ThumbTrackpadCalibrationEngine {
  const val MIN_SAMPLE_FRAMES = 24
  private const val MIN_SURFACE_SPAN_MM = 5f
  private const val MIN_ALONG_SPAN = 0.10f

  fun evaluate(samples: List<ThumbTrackpadCalibrationSample>): ThumbTrackpadCalibration? {
    val valid =
        samples.filter {
          it.surfaceMm.isFinite() &&
              it.alongPercent.isFinite() &&
              it.alongPercent in -0.20f..1.20f
        }
    if (valid.size < MIN_SAMPLE_FRAMES) return null
    val surface = valid.map { it.surfaceMm }.sorted()
    val along = valid.map { it.alongPercent }.sorted()
    val lowIndex = (valid.lastIndex * 0.05f).toInt()
    val highIndex = (valid.lastIndex * 0.95f).toInt().coerceAtLeast(lowIndex + 1)
    val result =
        ThumbTrackpadCalibration(
            minSurfaceMm = surface[lowIndex],
            maxSurfaceMm = surface[highIndex],
            minAlongPercent = along[lowIndex],
            maxAlongPercent = along[highIndex],
        )
    if (result.surfaceSpanMm < MIN_SURFACE_SPAN_MM || result.alongSpan < MIN_ALONG_SPAN) {
      return null
    }
    return result
  }
}
