package com.dearformerself.questinputlab.input

import kotlin.math.abs

internal data class HandFinger(
    val side: HandSide,
    val finger: Finger,
)

/** Per-finger movement needed beyond the current resting pose. */
internal data class RelativeFingerProfile(
    val bendPressDelta: Float? = null,
    val bendReleaseDelta: Float? = null,
    val ratioPressDelta: Float? = null,
    val ratioReleaseDelta: Float? = null,
    val palmPressDeltaMm: Float? = null,
    val palmReleaseDeltaMm: Float? = null,
    val requiredSignals: Int = 2,
) {
  val signalCount: Int
    get() =
        listOf(bendPressDelta, ratioPressDelta, palmPressDeltaMm).count { value ->
          value != null
        }

  val usable: Boolean
    get() = signalCount >= requiredSignals
}

/** A learned thumb-off pose that must never continue emitting an analog stick. */
internal data class ThumbLiftProfile(
    val surfaceCenterMm: Float,
    val surfaceToleranceMm: Float,
    val alongCenter: Float,
    val alongTolerance: Float,
    val palmSideCenterMm: Float,
    val palmSideToleranceMm: Float,
    val distanceCenterMm: Float,
    val distanceToleranceMm: Float,
) {
  internal fun matches(
      surfaceMm: Float,
      alongPercent: Float,
      palmSideMm: Float,
      distanceMm: Float,
  ): Boolean =
      abs(surfaceMm - surfaceCenterMm) <= surfaceToleranceMm &&
          abs(alongPercent - alongCenter) <= alongTolerance &&
          abs(palmSideMm - palmSideCenterMm) <= palmSideToleranceMm &&
          abs(distanceMm - distanceCenterMm) <= distanceToleranceMm
}

internal data class PersonalGestureProfile(
    val fingers: Map<HandFinger, RelativeFingerProfile> = emptyMap(),
    val trackpads: Map<HandSide, ThumbTrackpadCalibration> = emptyMap(),
    val liftedThumbs: Map<HandSide, ThumbLiftProfile> = emptyMap(),
) {
  val usable: Boolean
    get() = fingers.isNotEmpty() || trackpads.isNotEmpty() || liftedThumbs.isNotEmpty()

  fun summary(): String =
      "PERSONAL PROFILE · ${fingers.size}/6 finger strokes · " +
          "${trackpads.size}/2 stick ranges · ${liftedThumbs.size}/2 thumb releases"
}

internal data class CapturedFingerMeasurement(
    val bendDegrees: Float? = null,
    val curlRatio: Float? = null,
    val palmDistanceMm: Float? = null,
)

internal data class CapturedTrackpadMeasurement(
    val available: Boolean = false,
    val surfaceOffsetMm: Float? = null,
    val alongPercent: Float? = null,
    val palmSideMm: Float? = null,
    val contactDistanceMm: Float? = null,
)

internal data class CapturedHandMeasurement(
    val tracked: Boolean = false,
    val fingers: Map<Finger, CapturedFingerMeasurement> = emptyMap(),
    val trackpad: CapturedTrackpadMeasurement = CapturedTrackpadMeasurement(),
)

internal data class CapturedProfileSample(
    val phase: TrackingCapturePhase,
    val phaseElapsedMillis: Long,
    val left: CapturedHandMeasurement,
    val right: CapturedHandMeasurement,
) {
  fun hand(side: HandSide): CapturedHandMeasurement =
      if (side == HandSide.LEFT) left else right
}

/** Converts the recorder's labeled phases into a persistent hand-specific control profile. */
internal object TrackingProfileAnalyzer {
  private val TARGET_PHASES =
      mapOf(
          HandFinger(HandSide.LEFT, Finger.MIDDLE) to TrackingCapturePhase.LEFT_MIDDLE,
          HandFinger(HandSide.LEFT, Finger.RING) to TrackingCapturePhase.LEFT_RING,
          HandFinger(HandSide.LEFT, Finger.LITTLE) to TrackingCapturePhase.LEFT_PINKY,
          HandFinger(HandSide.RIGHT, Finger.MIDDLE) to TrackingCapturePhase.RIGHT_MIDDLE,
          HandFinger(HandSide.RIGHT, Finger.RING) to TrackingCapturePhase.RIGHT_RING,
          HandFinger(HandSide.RIGHT, Finger.LITTLE) to TrackingCapturePhase.RIGHT_PINKY,
      )

  fun evaluate(samples: List<CapturedProfileSample>): PersonalGestureProfile {
    val fingers =
        TARGET_PHASES.mapNotNull { (key, phase) ->
              learnFinger(samples, key, phase)?.let { key to it }
            }
            .toMap()
    val trackpads =
        HandSide.entries.mapNotNull { side ->
              learnTrackpad(samples, side)?.let { side to it }
            }
            .toMap()
    val liftedThumbs =
        HandSide.entries.mapNotNull { side ->
              learnLiftedThumb(samples, side)?.let { side to it }
            }
            .toMap()
    return PersonalGestureProfile(fingers, trackpads, liftedThumbs)
  }

  private fun learnFinger(
      samples: List<CapturedProfileSample>,
      key: HandFinger,
      targetPhase: TrackingCapturePhase,
  ): RelativeFingerProfile? {
    val neutral =
        samples
            .asSequence()
            .filter { it.phase == TrackingCapturePhase.RELAXED_OPEN && it.hand(key.side).tracked }
            .mapNotNull { it.hand(key.side).fingers[key.finger] }
            .toList()
    // A short guard removes motion carried across from the preceding prompt.
    val target =
        samples
            .asSequence()
            .filter {
              it.phase == targetPhase &&
                  it.phaseElapsedMillis >= TARGET_SETTLE_MILLIS &&
                  it.hand(key.side).tracked
            }
            .mapNotNull { it.hand(key.side).fingers[key.finger] }
            .toList()
    if (neutral.size < MIN_FINGER_SAMPLES || target.size < MIN_FINGER_SAMPLES) return null

    val limits = limitsFor(key.finger)
    val bend =
        increasingDelta(
            neutral.mapNotNull { it.bendDegrees },
            target.mapNotNull { it.bendDegrees },
            limits.minBend,
            limits.maxBend,
            MIN_BEND_EVIDENCE,
        )
    val ratio =
        decreasingDelta(
            neutral.mapNotNull { it.curlRatio },
            target.mapNotNull { it.curlRatio },
            limits.minRatio,
            limits.maxRatio,
            MIN_RATIO_EVIDENCE,
        )
    val palm =
        decreasingDelta(
            neutral.mapNotNull { it.palmDistanceMm },
            target.mapNotNull { it.palmDistanceMm },
            limits.minPalm,
            limits.maxPalm,
            MIN_PALM_EVIDENCE_MM,
        )
    val result =
        RelativeFingerProfile(
            bendPressDelta = bend?.first,
            bendReleaseDelta = bend?.second,
            ratioPressDelta = ratio?.first,
            ratioReleaseDelta = ratio?.second,
            palmPressDeltaMm = palm?.first,
            palmReleaseDeltaMm = palm?.second,
        )
    return result.takeIf(RelativeFingerProfile::usable)
  }

  private fun learnTrackpad(
      samples: List<CapturedProfileSample>,
      side: HandSide,
  ): ThumbTrackpadCalibration? {
    val phase =
        if (side == HandSide.LEFT) {
          TrackingCapturePhase.LEFT_STICK_SWEEP
        } else {
          TrackingCapturePhase.RIGHT_STICK_SWEEP
        }
    val values =
        samples
            .asSequence()
            .filter { it.phase == phase && it.hand(side).tracked }
            .map { it.hand(side).trackpad }
            .filter { it.available }
            .mapNotNull { value ->
              val surface = value.surfaceOffsetMm
              val along = value.alongPercent
              if (surface == null || along == null) null
              else ThumbTrackpadCalibrationSample(surface, along)
            }
            .toList()
    return ThumbTrackpadCalibrationEngine.evaluate(values)
  }

  private fun learnLiftedThumb(
      samples: List<CapturedProfileSample>,
      side: HandSide,
  ): ThumbLiftProfile? {
    val values =
        samples
            .asSequence()
            .filter {
              it.phase == TrackingCapturePhase.THUMBS_LIFTED &&
                  it.phaseElapsedMillis >= LIFTED_THUMB_SETTLE_MILLIS &&
                  it.hand(side).tracked
            }
            .map { it.hand(side).trackpad }
            .filter { it.available }
            .toList()
    if (values.size < MIN_LIFT_SAMPLES) return null
    val surface = values.mapNotNull { it.surfaceOffsetMm }
    val along = values.mapNotNull { it.alongPercent }
    val palmSide = values.mapNotNull { it.palmSideMm }
    val distance = values.mapNotNull { it.contactDistanceMm }
    if (listOf(surface, along, palmSide, distance).any { it.size < MIN_LIFT_SAMPLES }) return null
    return ThumbLiftProfile(
        surfaceCenterMm = requireNotNull(surface.medianOrNull()),
        surfaceToleranceMm = surface.learnedTolerance(MIN_SURFACE_TOLERANCE_MM),
        alongCenter = requireNotNull(along.medianOrNull()),
        alongTolerance = along.learnedTolerance(MIN_ALONG_TOLERANCE),
        palmSideCenterMm = requireNotNull(palmSide.medianOrNull()),
        palmSideToleranceMm = palmSide.learnedTolerance(MIN_PALM_SIDE_TOLERANCE_MM),
        distanceCenterMm = requireNotNull(distance.medianOrNull()),
        distanceToleranceMm = distance.learnedTolerance(MIN_DISTANCE_TOLERANCE_MM),
    )
  }

  private fun increasingDelta(
      neutral: List<Float>,
      target: List<Float>,
      minimumPress: Float,
      maximumPress: Float,
      minimumEvidence: Float,
  ): Pair<Float, Float>? {
    if (neutral.size < MIN_FINGER_SAMPLES || target.size < MIN_FINGER_SAMPLES) return null
    val span = requireNotNull(target.medianOrNull()) - requireNotNull(neutral.medianOrNull())
    if (span < minimumEvidence) return null
    val press = (span * PRESS_FRACTION).coerceIn(minimumPress, maximumPress)
    return press to (press * RELEASE_FRACTION)
  }

  private fun decreasingDelta(
      neutral: List<Float>,
      target: List<Float>,
      minimumPress: Float,
      maximumPress: Float,
      minimumEvidence: Float,
  ): Pair<Float, Float>? {
    if (neutral.size < MIN_FINGER_SAMPLES || target.size < MIN_FINGER_SAMPLES) return null
    val span = requireNotNull(neutral.medianOrNull()) - requireNotNull(target.medianOrNull())
    if (span < minimumEvidence) return null
    val press = (span * PRESS_FRACTION).coerceIn(minimumPress, maximumPress)
    return press to (press * RELEASE_FRACTION)
  }

  private fun List<Float>.learnedTolerance(minimum: Float): Float {
    val low = percentile(0.10f) ?: return minimum
    val high = percentile(0.90f) ?: return minimum
    return ((high - low) * TOLERANCE_SPAN_MULTIPLIER).coerceAtLeast(minimum)
  }

  private fun List<Float>.medianOrNull(): Float? = percentile(0.50f)

  private fun List<Float>.percentile(fraction: Float): Float? {
    val values = filter(Float::isFinite).sorted()
    if (values.isEmpty()) return null
    val position = (values.lastIndex * fraction.coerceIn(0f, 1f))
    val lower = position.toInt()
    val upper = (lower + 1).coerceAtMost(values.lastIndex)
    val remainder = position - lower
    return values[lower] + (values[upper] - values[lower]) * remainder
  }

  private fun limitsFor(finger: Finger): FingerDeltaLimits =
      when (finger) {
        Finger.MIDDLE -> FingerDeltaLimits(5f, 18f, 0.04f, 0.28f, 3f, 16f)
        Finger.RING -> FingerDeltaLimits(4f, 15f, 0.035f, 0.22f, 2.5f, 12f)
        Finger.LITTLE -> FingerDeltaLimits(2.5f, 10f, 0.025f, 0.12f, 1.5f, 8f)
        else -> FingerDeltaLimits(5f, 18f, 0.04f, 0.28f, 3f, 16f)
      }

  private data class FingerDeltaLimits(
      val minBend: Float,
      val maxBend: Float,
      val minRatio: Float,
      val maxRatio: Float,
      val minPalm: Float,
      val maxPalm: Float,
  )

  private const val TARGET_SETTLE_MILLIS = 1_000L
  private const val LIFTED_THUMB_SETTLE_MILLIS = 1_500L
  private const val MIN_FINGER_SAMPLES = 18
  private const val MIN_LIFT_SAMPLES = 18
  private const val MIN_BEND_EVIDENCE = 2f
  private const val MIN_RATIO_EVIDENCE = 0.018f
  private const val MIN_PALM_EVIDENCE_MM = 1.2f
  private const val PRESS_FRACTION = 0.55f
  private const val RELEASE_FRACTION = 0.45f
  private const val TOLERANCE_SPAN_MULTIPLIER = 1.5f
  private const val MIN_SURFACE_TOLERANCE_MM = 3f
  private const val MIN_ALONG_TOLERANCE = 0.04f
  private const val MIN_PALM_SIDE_TOLERANCE_MM = 3f
  private const val MIN_DISTANCE_TOLERANCE_MM = 2.5f
}
