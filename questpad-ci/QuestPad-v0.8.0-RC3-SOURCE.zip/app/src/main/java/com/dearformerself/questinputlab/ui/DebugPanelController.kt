package com.dearformerself.questinputlab.ui

import android.content.res.ColorStateList
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.core.graphics.toColorInt
import com.dearformerself.questinputlab.R
import com.dearformerself.questinputlab.input.Finger
import com.dearformerself.questinputlab.input.FingerCalibrationDiagnostic
import com.dearformerself.questinputlab.input.FingerCalibrationStatus
import com.dearformerself.questinputlab.input.FingerGestureSignal
import com.dearformerself.questinputlab.input.FingerInput
import com.dearformerself.questinputlab.input.InputMode
import com.dearformerself.questinputlab.input.InputSnapshot
import com.dearformerself.questinputlab.input.PhysicalInput
import com.dearformerself.questinputlab.input.VirtualInputState

private enum class DebugSection {
  PLAY,
  CALIBRATION,
  WINDOW,
  DIAGNOSTICS,
}

class DebugPanelController(
    inputState: VirtualInputState,
    private val onOpenLocal: () -> Unit,
    private val onOpenGeForceNow: () -> Unit,
    private val onToggleKeyboard: () -> Unit,
    private val onSelectMode: (InputMode) -> Unit,
    private val onPlaceTable: () -> Unit,
    private val onCalibrateFingers: () -> Unit,
    private val onCalibrateThumbSticks: () -> Unit,
    private val onToggleTrackingCapture: () -> Unit,
    private val onApplyLatestCapture: () -> Unit,
    private val onRecenterHands: () -> Unit,
    private val onReleaseAll: () -> Unit,
    private val onControllerOn: () -> Unit,
    private val onControllerOff: () -> Unit,
    private val onToggleFocus: () -> Unit,
    private val onToggleWindowMove: () -> Unit,
    private val onAdjustWindow: (BrowserWindowAdjustment) -> Unit,
) : AutoCloseable {
  private var rootView: View? = null
  private var lastSnapshot = inputState.snapshot()
  private var browserStatus = "Starting browser…"
  private var controllerStatus = "Controller engine: checking…"
  private var controllerXboxActive = false
  private var controllerSuppressionActive = false
  private var keyboardVisible = false
  private var focusModeEnabled = false
  private var tableStatus = "Table keyboard not placed · choose Place on table"
  private var windowMoveUnlocked = false
  private var windowWidthMeters = 1.60f
  private var windowHeightMeters = 0.90f
  private var activeSection = DebugSection.PLAY
  private var trackingCaptureActive = false
  private var trackingCaptureStatus = "Tracking capture idle · numerical hand data only"
  private val stateSubscription = inputState.addListener(::onSnapshot)

  fun attach(root: View) {
    rootView = root
    root.findViewById<Button>(R.id.button_local).setOnClickListener { onOpenLocal() }
    root.findViewById<Button>(R.id.button_gfn).setOnClickListener { onOpenGeForceNow() }
    root.findViewById<Button>(R.id.button_keyboard).setOnClickListener { onToggleKeyboard() }
    root.findViewById<Button>(R.id.button_focus).setOnClickListener { onToggleFocus() }
    root.findViewById<Button>(R.id.button_place_table).setOnClickListener { onPlaceTable() }
    root.findViewById<Button>(R.id.button_calibrate).setOnClickListener {
      onCalibrateFingers()
    }
    root.findViewById<Button>(R.id.button_calibrate_sticks).setOnClickListener {
      onCalibrateThumbSticks()
    }
    root.findViewById<Button>(R.id.button_tracking_capture).setOnClickListener {
      onToggleTrackingCapture()
    }
    root.findViewById<Button>(R.id.button_apply_latest_capture).setOnClickListener {
      onApplyLatestCapture()
    }
    root.findViewById<Button>(R.id.button_recenter).setOnClickListener { onRecenterHands() }
    root.findViewById<Button>(R.id.button_release).setOnClickListener { onReleaseAll() }
    root.findViewById<Button>(R.id.button_controller_on).setOnClickListener { onControllerOn() }
    root.findViewById<Button>(R.id.button_controller_off).setOnClickListener { onControllerOff() }
    root.findViewById<Button>(R.id.button_window_move).setOnClickListener {
      onToggleWindowMove()
    }
    WINDOW_BUTTONS.forEach { (id, adjustment) ->
      root.findViewById<Button>(id).setOnClickListener { onAdjustWindow(adjustment) }
    }
    MODE_BUTTONS.forEach { (id, mode) ->
      root.findViewById<Button>(id).setOnClickListener { onSelectMode(mode) }
    }
    SECTION_BUTTONS.forEach { (id, section) ->
      root.findViewById<Button>(id).setOnClickListener {
        activeSection = section
        render()
      }
    }
    render()
  }

  fun setBrowserStatus(status: String) {
    browserStatus = status
    render()
  }

  fun setControllerStatus(status: String, xboxActive: Boolean, suppressionActive: Boolean) {
    controllerStatus = status
    controllerXboxActive = xboxActive
    controllerSuppressionActive = suppressionActive
    render()
  }

  fun setKeyboardVisible(visible: Boolean) {
    keyboardVisible = visible
    render()
  }

  fun setFocusModeEnabled(enabled: Boolean) {
    focusModeEnabled = enabled
    render()
  }

  fun setTableStatus(status: String) {
    tableStatus = status
    render()
  }

  fun setWindowMoveUnlocked(unlocked: Boolean) {
    windowMoveUnlocked = unlocked
    if (unlocked) activeSection = DebugSection.WINDOW
    render()
  }

  fun setWindowSize(width: Float, height: Float) {
    windowWidthMeters = width
    windowHeightMeters = height
    render()
  }

  fun setTrackingCaptureState(active: Boolean, status: String) {
    trackingCaptureActive = active
    trackingCaptureStatus = status
    if (active) activeSection = DebugSection.CALIBRATION
    render()
  }

  private fun onSnapshot(snapshot: InputSnapshot) {
    lastSnapshot = snapshot
    render()
  }

  private fun render() {
    val root = rootView ?: return
    root.post {
      val snapshot = lastSnapshot
      root.findViewById<TextView>(R.id.text_mode).text =
          root.context.getString(
              R.string.current_mode_format,
              "QuestPad ${com.dearformerself.questinputlab.BuildConfig.VERSION_NAME} · ${snapshot.mode.displayName}",
          )
      root.findViewById<TextView>(R.id.text_mode_hint).text = modeHint(snapshot.mode)
      SECTION_VIEWS.forEach { (id, section) ->
        root.findViewById<View>(id).visibility =
            if (activeSection == section) View.VISIBLE else View.GONE
      }
      SECTION_BUTTONS.forEach { (id, section) ->
        root.findViewById<Button>(id).backgroundTintList =
            ColorStateList.valueOf(
                (if (activeSection == section) "#167E9B" else "#243443").toColorInt(),
            )
      }
      root.findViewById<Button>(R.id.button_window_move).apply {
        text =
            root.context.getString(
                if (windowMoveUnlocked) R.string.window_move_lock else R.string.window_move_unlock,
            )
        backgroundTintList =
            ColorStateList.valueOf(
                (if (windowMoveUnlocked) "#B36B18" else "#243443").toColorInt(),
            )
      }
      root.findViewById<Button>(R.id.button_tracking_capture).apply {
        text =
            root.context.getString(
                if (trackingCaptureActive) {
                  R.string.tracking_capture_stop
                } else {
                  R.string.tracking_capture_start
                },
            )
        backgroundTintList =
            ColorStateList.valueOf(
                (if (trackingCaptureActive) "#A33A3A" else "#245460").toColorInt(),
            )
      }
      MODE_BUTTONS.forEach { (id, mode) ->
        root.findViewById<Button>(id).backgroundTintList =
            ColorStateList.valueOf(
                (if (snapshot.mode == mode) "#167E9B" else "#243443").toColorInt(),
            )
      }

      root.findViewById<TextView>(R.id.text_right_input).text = formatInput(snapshot.right)
      root.findViewById<TextView>(R.id.text_left_input).text = formatInput(snapshot.left)
      root.findViewById<TextView>(R.id.text_output).text = formatOutput(snapshot)
      root.findViewById<TextView>(R.id.text_browser).text = browserStatus
      root.findViewById<TextView>(R.id.text_controller_status).text = controllerStatus
      root.findViewById<Button>(R.id.button_controller_on).apply {
        isEnabled = !controllerXboxActive
        backgroundTintList =
            ColorStateList.valueOf(
                (if (controllerXboxActive) "#167E9B" else "#245460").toColorInt(),
            )
      }
      root.findViewById<Button>(R.id.button_controller_off).apply {
        isEnabled = controllerXboxActive
        backgroundTintList =
            ColorStateList.valueOf(
                (if (!controllerXboxActive) "#167E9B" else "#7A3A3A").toColorInt(),
            )
      }
      root.findViewById<TextView>(R.id.text_controller_suppression).text =
          root.context.getString(
              if (controllerSuppressionActive) R.string.controller_suppression_on
              else R.string.controller_suppression_off,
          )
      root.findViewById<TextView>(R.id.text_gesture_status).text = snapshot.gestureStatus
      root.findViewById<TextView>(R.id.text_table_status).text = tableStatus
      root.findViewById<TextView>(R.id.text_tracking_status).text = trackingCaptureStatus
      root.findViewById<TextView>(R.id.text_window_status).text =
          root.context.getString(
              R.string.window_status_format,
              windowWidthMeters,
              windowHeightMeters,
              root.context.getString(
                  if (windowMoveUnlocked) R.string.window_grab_enabled
                  else R.string.window_movement_locked,
              ),
          )
      root.findViewById<TextView>(R.id.text_left_fingers).text =
          fingerLine("LEFT", snapshot.leftFingers, fingerLabels(snapshot.mode, left = true))
      root.findViewById<TextView>(R.id.text_right_fingers).text =
          fingerLine("RIGHT", snapshot.rightFingers, fingerLabels(snapshot.mode, left = false))
      root.findViewById<Button>(R.id.button_keyboard).text =
          root.context.getString(
              if (keyboardVisible) R.string.keyboard_toggle_hide else R.string.keyboard_toggle_show,
          )
      root.findViewById<Button>(R.id.button_focus).apply {
        text = root.context.getString(if (focusModeEnabled) R.string.focus_mode_on else R.string.focus_mode_off)
        backgroundTintList =
            ColorStateList.valueOf(
                (if (focusModeEnabled) "#167E9B" else "#243443").toColorInt(),
            )
      }
      root.findViewById<TextView>(R.id.text_focus_status).text =
          root.context.getString(
              if (focusModeEnabled) R.string.focus_mode_enabled else R.string.focus_mode_disabled,
          )
      root.findViewById<TextView>(R.id.text_event).text =
          snapshot.lastReleaseReason?.let {
            root.context.getString(R.string.debug_safety_release, it)
          } ?: root.context.getString(R.string.debug_event_format, snapshot.sequence)
    }
  }

  private fun formatInput(input: PhysicalInput): String {
    val root = rootView ?: return ""
    val active =
        root.context.getString(
            if (input.active) R.string.debug_active else R.string.debug_inactive,
        )
    val held = heldLabel(input.primaryHeld)
    return root.context.getString(
        R.string.debug_input_format,
        input.source.displayName,
        active,
        held,
        "0x%08X".format(input.rawButtons),
    )
  }

  private fun formatOutput(snapshot: InputSnapshot): String {
    val gamepad =
        snapshot.gamepad.buttons.joinToString(", ") { it.displayName }.ifBlank { "idle" }
    val keys = snapshot.heldKeys.joinToString("+") { it.displayName }.ifBlank { "idle" }
    val mouse =
        snapshot.mouse.buttons.joinToString("+") { it.displayName }.ifBlank { "idle" }
    return "Pad: $gamepad · Keys: $keys · Mouse: $mouse"
  }

  private fun fingerLine(prefix: String, input: FingerInput, labels: List<String>): CharSequence {
    val usableCount = Finger.entries.count(input::isUsable)
    val builder =
        SpannableStringBuilder("$prefix  $usableCount/${Finger.entries.size} signals  ")
    Finger.entries.forEachIndexed { index, finger ->
      if (index > 0) builder.append("  ")
      val start = builder.length
      val ratio = input.curlRatios[finger]
      val measurement = ratio?.let { " %.2f".format(it) } ?: ""
      val marker =
          when {
            input.isUsable(finger) -> " ✓"
            input.calibration.containsKey(finger) -> " !"
            else -> ""
          }
      builder.append(" ${labels[index]}$measurement$marker ")
      val end = builder.length
      val active = input.isActive(finger)
      val usable = input.isUsable(finger)
      val attempted = !usable && input.calibration.containsKey(finger)
      builder.setSpan(
          BackgroundColorSpan(
              when {
                active -> "#16A8C9"
                usable -> "#245460"
                attempted -> "#6A3030"
                else -> "#243443"
              }.toColorInt(),
          ),
          start,
          end,
          Spanned.SPAN_EXCLUSIVE_EXCLUSIVE,
      )
      builder.setSpan(
          ForegroundColorSpan("#FFFFFF".toColorInt()),
          start,
          end,
          Spanned.SPAN_EXCLUSIVE_EXCLUSIVE,
      )
      if (active) {
        builder.setSpan(
            StyleSpan(Typeface.BOLD),
            start,
            end,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE,
        )
      }
    }
    builder.append('\n')
    Finger.entries.forEachIndexed { index, finger ->
      if (index > 0) builder.append("  ·  ")
      builder.append(signalDetails(finger, input.signals[finger], input.calibration[finger]))
    }
    if (input.thumbTrackpad.enabled) {
      val trackpad = input.thumbTrackpad
      val state =
          when {
            trackpad.liftPoseMatched -> "LIFTED"
            trackpad.active -> "ACTIVE"
            trackpad.touching -> "CONTACT"
            !trackpad.available -> "WAITING"
            else -> "READY"
          }
      builder.append(
          "\nINDEX-SIDE TRACKPAD $state · X${number(trackpad.stickX)} " +
              "Y${number(trackpad.stickY)} · D${number(trackpad.contactDistanceMm)}mm " +
              "S${number(trackpad.palmSideMm)}mm · L${number(trackpad.indexLengthMm)}mm " +
              if (trackpad.calibrated) "CAL" else "UNCAL",
      )
    }
    return builder
  }

  private fun signalDetails(
      finger: Finger,
      signal: FingerGestureSignal?,
      diagnostic: FingerCalibrationDiagnostic?,
  ): String {
    val name = finger.name.first().toString()
    if (signal?.usable != true) return calibrationDetails(finger, diagnostic)
    val source =
        when {
          signal.conflictSuppressed -> "CONFLICT BLOCKED"
          signal.held -> signal.source.name
          else -> "READY"
        }
    return "$name B${number(signal.bendDegrees)}° T${number(signal.thumbDistanceMm)}mm " +
        "R${number(signal.curlRatio)} P${number(signal.relativeScore)} " +
        "${signal.sensitivity.name} $source"
  }

  private fun calibrationDetails(
      finger: Finger,
      diagnostic: FingerCalibrationDiagnostic?,
  ): String {
    val name = finger.name.first().toString()
    if (diagnostic == null) return "$name UNCAL"
    val state =
        when (diagnostic.status) {
          FingerCalibrationStatus.READY -> "OK"
          FingerCalibrationStatus.NEEDS_SAMPLES -> "DATA"
          FingerCalibrationStatus.SPAN_TOO_SMALL -> "SPAN"
          FingerCalibrationStatus.INVERTED -> "DIR"
        }
    return "$name O${number(diagnostic.open)} C${number(diagnostic.closed)} " +
        "Δ${number(diagnostic.span)} P${number(diagnostic.press)}/R${number(diagnostic.release)} " +
        "$state"
  }

  private fun number(value: Float?): String = value?.let { "%.2f".format(it) } ?: "—"

  private fun fingerLabels(mode: InputMode, left: Boolean): List<String> =
      when (mode) {
        InputMode.HAND_KEYBOARD_MOUSE ->
            if (left) listOf("SPACE", "D", "W", "A", "S")
            else listOf("SHIFT", "LMB", "RMB", "E", "R")
        InputMode.HAND_XBOX ->
            if (left) listOf("MENU", "LT", "LB", "L3", "VIEW")
            else listOf("A", "RT", "RB", "B", "Y")
        InputMode.TOUCH_XBOX -> listOf("—", "—", "—", "—", "—")
        InputMode.TABLETOP_KEYBOARD_MOUSE -> listOf("UI", "UI", "UI", "UI", "UI")
      }

  private fun modeHint(mode: InputMode): String =
      when (mode) {
        InputMode.TOUCH_XBOX ->
            "Touch → Xbox: A/B, X/Y, triggers, grips and stick clicks. Hold both grips + left stick for D-pad; hold both grips + three-lines for View."
        InputMode.HAND_XBOX -> "Move palms as sticks · curl lit fingers · Recenter at a relaxed pose."
        InputMode.HAND_KEYBOARD_MOUSE ->
            "Left hand holds movement · right hand moves/clicks the mouse."
        InputMode.TABLETOP_KEYBOARD_MOUSE ->
            "Place it once per room/session, then use the visible keys and trackpad."
      }

  private fun heldLabel(held: Boolean): String {
    val root = rootView ?: return if (held) "HELD" else "idle"
    return root.context.getString(if (held) R.string.debug_held else R.string.debug_idle)
  }

  override fun close() {
    stateSubscription.close()
    rootView = null
  }

  companion object {
    private val MODE_BUTTONS =
        mapOf(
            R.id.button_mode_touch to InputMode.TOUCH_XBOX,
            R.id.button_mode_hand_xbox to InputMode.HAND_XBOX,
            R.id.button_mode_hand_km to InputMode.HAND_KEYBOARD_MOUSE,
            R.id.button_mode_tabletop to InputMode.TABLETOP_KEYBOARD_MOUSE,
        )
    private val SECTION_BUTTONS =
        mapOf(
            R.id.button_section_play to DebugSection.PLAY,
            R.id.button_section_calibration to DebugSection.CALIBRATION,
            R.id.button_section_window to DebugSection.WINDOW,
            R.id.button_section_diagnostics to DebugSection.DIAGNOSTICS,
        )
    private val SECTION_VIEWS =
        mapOf(
            R.id.section_play to DebugSection.PLAY,
            R.id.section_calibration to DebugSection.CALIBRATION,
            R.id.section_window to DebugSection.WINDOW,
            R.id.section_diagnostics to DebugSection.DIAGNOSTICS,
        )
    private val WINDOW_BUTTONS =
        mapOf(
            R.id.button_window_left to BrowserWindowAdjustment.LEFT,
            R.id.button_window_right to BrowserWindowAdjustment.RIGHT,
            R.id.button_window_up to BrowserWindowAdjustment.UP,
            R.id.button_window_down to BrowserWindowAdjustment.DOWN,
            R.id.button_window_near to BrowserWindowAdjustment.NEARER,
            R.id.button_window_far to BrowserWindowAdjustment.FARTHER,
            R.id.button_window_smaller to BrowserWindowAdjustment.SMALLER,
            R.id.button_window_larger to BrowserWindowAdjustment.LARGER,
            R.id.button_window_reset to BrowserWindowAdjustment.RESET,
        )
  }
}

enum class BrowserWindowAdjustment {
  LEFT,
  RIGHT,
  UP,
  DOWN,
  NEARER,
  FARTHER,
  SMALLER,
  LARGER,
  RESET,
}
