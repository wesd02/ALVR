package com.dearformerself.questinputlab.input

import android.content.Context
import com.dearformerself.questinputlab.BuildConfig
import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import kotlin.math.ceil
import org.json.JSONArray
import org.json.JSONObject

internal enum class TrackingCaptureRequirement {
  BOTH_HANDS,
  LEFT_HAND,
  RIGHT_HAND,
  LEFT_TRACKPAD_CONTACT,
  RIGHT_TRACKPAD_CONTACT,
}

internal enum class TrackingCapturePhase(
    val prompt: String,
    val durationMillis: Long,
    val requirement: TrackingCaptureRequirement,
) {
  RELAXED_OPEN(
      "hold both hands comfortably open and apart",
      3_000L,
      TrackingCaptureRequirement.BOTH_HANDS,
  ),
  RELAXED_CONTROLLER_GRIP(
      "hold a relaxed invisible-controller grip without pressing",
      4_000L,
      TrackingCaptureRequirement.BOTH_HANDS,
  ),
  LEFT_MIDDLE(
      "relax 1s, then press and hold only LEFT MIDDLE",
      5_000L,
      TrackingCaptureRequirement.LEFT_HAND,
  ),
  LEFT_RING(
      "relax 1s, then press and hold only LEFT RING",
      5_000L,
      TrackingCaptureRequirement.LEFT_HAND,
  ),
  LEFT_PINKY(
      "relax 1s, then press and hold only LEFT PINKY",
      5_000L,
      TrackingCaptureRequirement.LEFT_HAND,
  ),
  RIGHT_MIDDLE(
      "relax 1s, then press and hold only RIGHT MIDDLE",
      5_000L,
      TrackingCaptureRequirement.RIGHT_HAND,
  ),
  RIGHT_RING(
      "relax 1s, then press and hold only RIGHT RING",
      5_000L,
      TrackingCaptureRequirement.RIGHT_HAND,
  ),
  RIGHT_PINKY(
      "relax 1s, then press and hold only RIGHT PINKY",
      5_000L,
      TrackingCaptureRequirement.RIGHT_HAND,
  ),
  LEFT_STICK_SWEEP(
      "keep contact and sweep LEFT stick fully in all four directions",
      6_000L,
      TrackingCaptureRequirement.LEFT_TRACKPAD_CONTACT,
  ),
  RIGHT_STICK_SWEEP(
      "keep contact and sweep RIGHT stick fully in all four directions",
      6_000L,
      TrackingCaptureRequirement.RIGHT_TRACKPAD_CONTACT,
  ),
  THUMBS_LIFTED(
      "lift both thumbs and hold an ordinary resting posture",
      3_000L,
      TrackingCaptureRequirement.BOTH_HANDS,
  );

  fun isReady(snapshot: InputSnapshot): Boolean =
      when (requirement) {
        TrackingCaptureRequirement.BOTH_HANDS ->
            snapshot.leftFingers.tracked && snapshot.rightFingers.tracked
        TrackingCaptureRequirement.LEFT_HAND -> snapshot.leftFingers.tracked
        TrackingCaptureRequirement.RIGHT_HAND -> snapshot.rightFingers.tracked
        TrackingCaptureRequirement.LEFT_TRACKPAD_CONTACT ->
            snapshot.leftFingers.thumbTrackpad.touching
        TrackingCaptureRequirement.RIGHT_TRACKPAD_CONTACT ->
            snapshot.rightFingers.thumbTrackpad.touching
      }

  fun waitingMessage(): String =
      when (requirement) {
        TrackingCaptureRequirement.BOTH_HANDS -> "waiting for both tracked hands"
        TrackingCaptureRequirement.LEFT_HAND -> "waiting for the left tracked hand"
        TrackingCaptureRequirement.RIGHT_HAND -> "waiting for the right tracked hand"
        TrackingCaptureRequirement.LEFT_TRACKPAD_CONTACT ->
            "waiting for left thumb/index-side contact"
        TrackingCaptureRequirement.RIGHT_TRACKPAD_CONTACT ->
            "waiting for right thumb/index-side contact"
      }
}

internal data class TrackingCaptureProgress(
    val phase: TrackingCapturePhase?,
    val phaseIndex: Int,
    val phaseElapsedMillis: Long,
    val ready: Boolean,
    val completed: Boolean,
) {
  val phaseId: String
    get() = phase?.name ?: "COMPLETE"

  fun statusText(): String {
    val current = phase ?: return "TRACKING CAPTURE COMPLETE · saving data"
    val remaining =
        ceil((current.durationMillis - phaseElapsedMillis).coerceAtLeast(0L) / 1_000.0)
            .toInt()
    val prefix = "CAPTURE ${phaseIndex + 1}/${TrackingCapturePhase.entries.size}"
    return if (ready) {
      "$prefix · ${current.prompt} · ${remaining}s"
    } else {
      "$prefix · ${current.waitingMessage()} · timer paused"
    }
  }
}

/** Pure phase timer. Missing joints pause progress instead of silently consuming the prompt. */
internal class TrackingCaptureTimeline {
  private var phaseIndex = 0
  private var phaseElapsedNanos = 0L
  private var lastUpdateNanos = 0L

  fun update(nowNanos: Long, snapshot: InputSnapshot): TrackingCaptureProgress {
    if (phaseIndex >= TrackingCapturePhase.entries.size) return completedProgress()
    val delta =
        if (lastUpdateNanos == 0L) 0L
        else (nowNanos - lastUpdateNanos).coerceIn(0L, MAX_FRAME_GAP_NANOS)
    lastUpdateNanos = nowNanos

    val phase = TrackingCapturePhase.entries[phaseIndex]
    val ready = phase.isReady(snapshot)
    if (ready) phaseElapsedNanos += delta
    if (phaseElapsedNanos >= phase.durationMillis * NANOS_PER_MILLISECOND) {
      phaseIndex++
      phaseElapsedNanos = 0L
      if (phaseIndex >= TrackingCapturePhase.entries.size) return completedProgress()
    }

    val current = TrackingCapturePhase.entries[phaseIndex]
    return TrackingCaptureProgress(
        phase = current,
        phaseIndex = phaseIndex,
        phaseElapsedMillis = phaseElapsedNanos / NANOS_PER_MILLISECOND,
        ready = current.isReady(snapshot),
        completed = false,
    )
  }

  private fun completedProgress() =
      TrackingCaptureProgress(
          phase = null,
          phaseIndex = TrackingCapturePhase.entries.size,
          phaseElapsedMillis = 0L,
          ready = true,
          completed = true,
      )

  companion object {
    private const val NANOS_PER_MILLISECOND = 1_000_000L
    private const val MAX_FRAME_GAP_NANOS = 100_000_000L
  }
}

internal data class TrackingCaptureState(
    val active: Boolean = false,
    val status: String = "Tracking capture idle · numerical hand data only",
    val sampleCount: Int = 0,
    val savedFileName: String? = null,
)

/** Records labeled numerical hand/input snapshots. No camera, page, text-field, or browser data. */
internal class TrackingCaptureRecorder(
    context: Context,
    private val inputState: VirtualInputState,
    private val onStateChanged: (TrackingCaptureState) -> Unit,
    private val onProfileReady: (PersonalGestureProfile) -> String = { it.summary() },
) : AutoCloseable {
  private val appContext = context.applicationContext
  private val lock = Any()
  private var timeline: TrackingCaptureTimeline? = null
  private var writer: BufferedWriter? = null
  private var captureFile: File? = null
  private var captureStartedNanos = 0L
  private var lastSampleNanos = 0L
  private var sampleCount = 0
  private var lastStatus = ""
  private val profileSamples = mutableListOf<CapturedProfileSample>()

  @Volatile private var state = TrackingCaptureState()

  val isActive: Boolean
    get() = state.active

  fun start() {
    val next =
        synchronized(lock) {
          if (state.active) return
          val directory = appContext.getExternalFilesDir(null) ?: appContext.filesDir
          if (!directory.exists() && !directory.mkdirs()) {
            return@synchronized TrackingCaptureState(status = "Capture failed · cannot create data folder")
          }
          val timestamp = FILE_TIMESTAMP.format(Instant.now())
          val file = File(directory, "QuestInputLab-tracking-$timestamp.jsonl")
          val opened =
              runCatching {
                    BufferedWriter(OutputStreamWriter(FileOutputStream(file), Charsets.UTF_8))
                  }
                  .getOrElse { error ->
                    return@synchronized TrackingCaptureState(
                        status = "Capture failed · ${safeMessage(error)}",
                    )
                  }
          writer = opened
          captureFile = file
          timeline = TrackingCaptureTimeline()
          captureStartedNanos = System.nanoTime()
          lastSampleNanos = 0L
          sampleCount = 0
          lastStatus = ""
          profileSamples.clear()
          writeLineLocked(captureHeader())
          TrackingCaptureState(
              active = true,
              status = "CAPTURE starting · put down Touch controllers and show both hands",
          )
        }
    publish(next)
    if (next.active) captureFrame(inputState.snapshot())
  }

  fun stopAndSave(reason: String = "Capture stopped manually") {
    val next = synchronized(lock) { finishLocked(reason) }
    publish(next)
  }

  fun captureFrame(snapshot: InputSnapshot) {
    var published: TrackingCaptureState? = null
    synchronized(lock) {
      if (!state.active) return
      val now = System.nanoTime()
      val progress = requireNotNull(timeline).update(now, snapshot)
      val shouldSample =
          lastSampleNanos == 0L || now - lastSampleNanos >= SAMPLE_INTERVAL_NANOS
      if (shouldSample) {
        lastSampleNanos = now
        val encoded = encodeSnapshot(snapshot, progress, now)
        if (!writeLineLocked(encoded)) {
          published = finishLocked("Capture stopped after a file-write error")
          return@synchronized
        }
        sampleCount++
        progress.phase?.let { phase ->
          profileSamples += capturedProfileSample(snapshot, phase, progress.phaseElapsedMillis)
        }
        if (sampleCount % FLUSH_EVERY_SAMPLES == 0) writer?.flush()
      }
      if (progress.completed) {
        published = finishLocked("Capture complete")
      } else {
        val status = progress.statusText()
        if (status != lastStatus) {
          lastStatus = status
          published = TrackingCaptureState(active = true, status = status, sampleCount = sampleCount)
        }
      }
    }
    published?.let(::publish)
  }

  private fun finishLocked(reason: String): TrackingCaptureState {
    if (!state.active && writer == null) return state
    val file = captureFile
    runCatching {
      writeLineLocked(
          JSONObject()
              .put("type", "footer")
              .put("reason", reason)
              .put("sampleCount", sampleCount)
              .put("completedAtUtc", Instant.now().toString()),
      )
      writer?.flush()
      writer?.close()
    }
    writer = null
    timeline = null
    captureFile = null
    val profileStatus =
        if (reason == "Capture complete") applyProfile(profileSamples) else null
    profileSamples.clear()
    val latestSaved =
        file?.let { source ->
          runCatching {
                source.copyTo(File(source.parentFile, LATEST_FILE_NAME), overwrite = true)
                true
              }
              .getOrDefault(false)
        } == true
    return if (file == null) {
      TrackingCaptureState(status = "Capture stopped · no file was created")
    } else {
      TrackingCaptureState(
          active = false,
          status =
              if (latestSaved) {
                listOfNotNull(
                        reason,
                        "$sampleCount samples saved",
                        profileStatus,
                        LATEST_FILE_NAME,
                    )
                    .joinToString(" · ")
              } else {
                "$reason · $sampleCount samples saved · ${file.name}"
              },
          sampleCount = sampleCount,
          savedFileName = if (latestSaved) LATEST_FILE_NAME else file.name,
      )
    }
  }

  fun applyLatestProfile() {
    if (state.active) {
      publish(state.copy(status = "Stop the active capture before applying a profile"))
      return
    }
    val directory = appContext.getExternalFilesDir(null) ?: appContext.filesDir
    val file = File(directory, LATEST_FILE_NAME)
    if (!file.isFile) {
      publish(TrackingCaptureState(status = "No latest capture found · run Capture tracking first"))
      return
    }
    publish(TrackingCaptureState(status = "Analyzing latest capture…"))
    val result =
        runCatching {
              val samples = parseProfileSamples(file)
              val profile = TrackingProfileAnalyzer.evaluate(samples)
              if (!profile.usable) error("capture did not contain usable personal ranges")
              onProfileReady(profile)
            }
            .fold(
                onSuccess = { "$it · latest capture applied" },
                onFailure = { "Profile failed · ${safeMessage(it)}" },
            )
    publish(TrackingCaptureState(status = result, savedFileName = file.name))
  }

  private fun applyProfile(samples: List<CapturedProfileSample>): String =
      runCatching {
            val profile = TrackingProfileAnalyzer.evaluate(samples)
            if (!profile.usable) error("no usable personal ranges")
            onProfileReady(profile)
          }
          .getOrElse { "Profile not applied · ${safeMessage(it)}" }

  private fun capturedProfileSample(
      snapshot: InputSnapshot,
      phase: TrackingCapturePhase,
      phaseElapsedMillis: Long,
  ): CapturedProfileSample =
      CapturedProfileSample(
          phase = phase,
          phaseElapsedMillis = phaseElapsedMillis,
          left = capturedHand(snapshot.leftFingers),
          right = capturedHand(snapshot.rightFingers),
      )

  private fun capturedHand(input: FingerInput): CapturedHandMeasurement =
      CapturedHandMeasurement(
          tracked = input.tracked,
          fingers =
              Finger.entries.associateWith { finger ->
                val signal = input.signals[finger]
                CapturedFingerMeasurement(
                    bendDegrees = signal?.bendDegrees,
                    curlRatio = signal?.curlRatio ?: input.curlRatios[finger],
                    palmDistanceMm = signal?.palmDistanceMm,
                )
              },
          trackpad =
              CapturedTrackpadMeasurement(
                  available = input.thumbTrackpad.available,
                  surfaceOffsetMm = input.thumbTrackpad.surfaceOffsetMm,
                  alongPercent = input.thumbTrackpad.alongPercent,
                  palmSideMm = input.thumbTrackpad.palmSideMm,
                  contactDistanceMm = input.thumbTrackpad.contactDistanceMm,
              ),
      )

  private fun parseProfileSamples(file: File): List<CapturedProfileSample> = buildList {
    file.useLines { lines ->
      lines.forEach { line ->
        val value = runCatching { JSONObject(line) }.getOrNull() ?: return@forEach
        if (value.optString("type") != "sample") return@forEach
        val phase =
            value.optString("phase").let { name ->
              TrackingCapturePhase.entries.firstOrNull { it.name == name }
            } ?: return@forEach
        val left = value.optJSONObject("left") ?: return@forEach
        val right = value.optJSONObject("right") ?: return@forEach
        add(
            CapturedProfileSample(
                phase = phase,
                phaseElapsedMillis = value.optLong("phaseElapsedMillis", 0L),
                left = parseCapturedHand(left),
                right = parseCapturedHand(right),
            ),
        )
      }
    }
  }

  private fun parseCapturedHand(value: JSONObject): CapturedHandMeasurement {
    val fingers = value.optJSONObject("fingers")
    val trackpad = value.optJSONObject("trackpad")
    return CapturedHandMeasurement(
        tracked = value.optBoolean("tracked", false),
        fingers =
            Finger.entries.associateWith { finger ->
              val signal = fingers?.optJSONObject(finger.name)
              CapturedFingerMeasurement(
                  bendDegrees = signal.floatOrNull("bendDegrees"),
                  curlRatio = signal.floatOrNull("curlRatio"),
                  palmDistanceMm = signal.floatOrNull("palmDistanceMm"),
              )
            },
        trackpad =
            CapturedTrackpadMeasurement(
                available = trackpad?.optBoolean("available", false) == true,
                surfaceOffsetMm = trackpad.floatOrNull("surfaceOffsetMm"),
                alongPercent = trackpad.floatOrNull("alongPercent"),
                palmSideMm = trackpad.floatOrNull("palmSideMm"),
                contactDistanceMm = trackpad.floatOrNull("contactDistanceMm"),
            ),
    )
  }

  private fun JSONObject?.floatOrNull(key: String): Float? {
    if (this == null || isNull(key)) return null
    return optDouble(key, Double.NaN).takeIf(Double::isFinite)?.toFloat()
  }

  private fun captureHeader(): JSONObject =
      JSONObject()
          .put("type", "header")
          .put("schemaVersion", 1)
          .put("appVersion", BuildConfig.VERSION_NAME)
          .put("createdAtUtc", Instant.now().toString())
          .put("sampleRateTargetHz", 30)
          .put("privacy", "numerical hand and routed-input data only; no camera or browser data")
          .put(
              "phases",
              JSONArray().apply {
                TrackingCapturePhase.entries.forEach { phase ->
                  put(
                      JSONObject()
                          .put("id", phase.name)
                          .put("prompt", phase.prompt)
                          .put("durationMillis", phase.durationMillis),
                  )
                }
              },
          )

  private fun encodeSnapshot(
      snapshot: InputSnapshot,
      progress: TrackingCaptureProgress,
      nowNanos: Long,
  ): JSONObject =
      JSONObject()
          .put("type", "sample")
          .put("captureMillis", (nowNanos - captureStartedNanos) / 1_000_000L)
          .put("phase", progress.phaseId)
          .put("phaseIndex", progress.phaseIndex)
          .put("phaseElapsedMillis", progress.phaseElapsedMillis)
          .put("phaseReady", progress.ready)
          .put("sequence", snapshot.sequence)
          .put("mode", snapshot.mode.name)
          .put("gestureStatus", snapshot.gestureStatus)
          .put("left", encodeHand(snapshot.left, snapshot.leftFingers))
          .put("right", encodeHand(snapshot.right, snapshot.rightFingers))
          .put("output", encodeOutput(snapshot))

  private fun encodeHand(physical: PhysicalInput, fingers: FingerInput): JSONObject =
      JSONObject()
          .put("physicalSource", physical.source.name)
          .put("physicalActive", physical.active)
          .put("primaryHeld", physical.primaryHeld)
          .put("rawButtons", physical.rawButtons)
          .put("tracked", fingers.tracked)
          .put("activeFingers", names(fingers.active.map { it.name }))
          .put("fingers", encodeFingers(fingers))
          .put("trackpad", encodeTrackpad(fingers.thumbTrackpad))

  private fun encodeFingers(input: FingerInput): JSONObject =
      JSONObject().apply {
        Finger.entries.forEach { finger ->
          val signal = input.signals[finger]
          val calibration = input.calibration[finger]
          put(
              finger.name,
              JSONObject()
                  .put("active", input.isActive(finger))
                  .put("calibrated", input.isCalibrated(finger))
                  .put("usable", signal?.usable == true)
                  .put("held", signal?.held == true)
                  .put("source", signal?.source?.name ?: "NONE")
                  .put("sensitivity", signal?.sensitivity?.name ?: "UNKNOWN")
                  .putFinite("curlRatio", signal?.curlRatio ?: input.curlRatios[finger])
                  .putFinite("bendDegrees", signal?.bendDegrees)
                  .putFinite("thumbDistanceMm", signal?.thumbDistanceMm)
                  .putFinite("palmDistanceMm", signal?.palmDistanceMm)
                  .put("contactActive", signal?.contactActive == true)
                  .put("bendActive", signal?.bendActive == true)
                  .put("ratioActive", signal?.ratioActive == true)
                  .put("palmActive", signal?.palmActive == true)
                  .putFinite("relativeScore", signal?.relativeScore)
                  .put("conflictSuppressed", signal?.conflictSuppressed == true)
                  .put("calibrationStatus", calibration?.status?.name ?: "NONE")
                  .putFinite("calibrationOpen", calibration?.open)
                  .putFinite("calibrationClosed", calibration?.closed)
                  .putFinite("calibrationPress", calibration?.press)
                  .putFinite("calibrationRelease", calibration?.release),
          )
        }
      }

  private fun encodeTrackpad(trackpad: ThumbTrackpadSignal): JSONObject =
      JSONObject()
          .put("enabled", trackpad.enabled)
          .put("available", trackpad.available)
          .put("touching", trackpad.touching)
          .put("active", trackpad.active)
          .put("calibrated", trackpad.calibrated)
          .putFinite("stickX", trackpad.stickX)
          .putFinite("stickY", trackpad.stickY)
          .putFinite("deltaX", trackpad.deltaX)
          .putFinite("deltaY", trackpad.deltaY)
          .putFinite("alongPercent", trackpad.alongPercent)
          .putFinite("surfaceOffsetMm", trackpad.surfaceOffsetMm)
          .putFinite("palmSideMm", trackpad.palmSideMm)
          .putFinite("contactDistanceMm", trackpad.contactDistanceMm)
          .putFinite("indexLengthMm", trackpad.indexLengthMm)
          .putFinite("calibrationMinSurfaceMm", trackpad.calibrationMinSurfaceMm)
          .putFinite("calibrationMaxSurfaceMm", trackpad.calibrationMaxSurfaceMm)
          .putFinite("calibrationMinAlongPercent", trackpad.calibrationMinAlongPercent)
          .putFinite("calibrationMaxAlongPercent", trackpad.calibrationMaxAlongPercent)
          .put("liftPoseMatched", trackpad.liftPoseMatched)

  private fun encodeOutput(snapshot: InputSnapshot): JSONObject =
      JSONObject()
          .put("heldKeys", names(snapshot.heldKeys.map { it.name }))
          .put("mouseButtons", names(snapshot.mouse.buttons.map { it.name }))
          .putFinite("mouseDeltaX", snapshot.mouse.deltaX)
          .putFinite("mouseDeltaY", snapshot.mouse.deltaY)
          .put("gamepadButtons", names(snapshot.gamepad.buttons.map { it.name }))
          .putFinite("leftX", snapshot.gamepad.leftX)
          .putFinite("leftY", snapshot.gamepad.leftY)
          .putFinite("rightX", snapshot.gamepad.rightX)
          .putFinite("rightY", snapshot.gamepad.rightY)

  private fun names(values: Iterable<String>): JSONArray =
      JSONArray().apply { values.forEach { put(it) } }

  private fun JSONObject.putFinite(key: String, value: Float?): JSONObject =
      put(key, if (value != null && value.isFinite()) value.toDouble() else JSONObject.NULL)

  private fun writeLineLocked(value: JSONObject): Boolean =
      runCatching {
            writer?.apply {
              write(value.toString())
              newLine()
            } ?: error("Capture writer is closed")
          }
          .isSuccess

  private fun publish(next: TrackingCaptureState) {
    state = next
    onStateChanged(next)
  }

  override fun close() {
    if (state.active) stopAndSave("Activity closed")
  }

  companion object {
    const val LATEST_FILE_NAME = "QuestInputLab-tracking-latest.jsonl"
    private const val SAMPLE_INTERVAL_NANOS = 33_000_000L
    private const val FLUSH_EVERY_SAMPLES = 60
    private val FILE_TIMESTAMP =
        DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss").withZone(ZoneOffset.UTC)

    private fun safeMessage(error: Throwable): String =
        (error.message ?: error.javaClass.simpleName).replace('\n', ' ').take(72)
  }
}
