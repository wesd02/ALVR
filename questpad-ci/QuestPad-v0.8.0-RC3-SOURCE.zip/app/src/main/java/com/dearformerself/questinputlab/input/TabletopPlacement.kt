package com.dearformerself.questinputlab.input

import kotlin.math.atan2
import kotlin.math.sqrt

data class TablePlacementSample(
    val leftPalm: Point3,
    val rightPalm: Point3,
    val head: Point3?,
)

data class TabletopPose(
    val center: Point3,
    val yawDegrees: Float,
)

/** Turns two palms resting on a table into a keyboard center and heading. */
object TabletopPlacement {
  private const val MIN_HAND_SEPARATION_METERS = 0.18f
  private const val MAX_HAND_SEPARATION_METERS = 1.20f
  private const val KEYBOARD_FORWARD_OFFSET_METERS = 0.15f
  private const val PALM_TO_SURFACE_OFFSET_METERS = -0.012f
  private const val SCENE_SURFACE_LIFT_METERS = 0.006f

  fun from(sample: TablePlacementSample): TabletopPose? {
    val left = sample.leftPalm
    val right = sample.rightPalm
    val acrossX = right.x - left.x
    val acrossZ = right.z - left.z
    val separation = sqrt(acrossX * acrossX + acrossZ * acrossZ)
    if (separation !in MIN_HAND_SEPARATION_METERS..MAX_HAND_SEPARATION_METERS) return null

    val rightX = acrossX / separation
    val rightZ = acrossZ / separation
    var awayX = -rightZ
    var awayZ = rightX
    val midpointX = (left.x + right.x) * 0.5f
    val midpointZ = (left.z + right.z) * 0.5f

    sample.head?.let { head ->
      val headToHandsX = midpointX - head.x
      val headToHandsZ = midpointZ - head.z
      if (awayX * headToHandsX + awayZ * headToHandsZ < 0f) {
        awayX = -awayX
        awayZ = -awayZ
      }
    }

    val yaw = Math.toDegrees(atan2(-rightZ, rightX).toDouble()).toFloat()
    return TabletopPose(
        center =
            Point3(
                midpointX + awayX * KEYBOARD_FORWARD_OFFSET_METERS,
                (left.y + right.y) * 0.5f + PALM_TO_SURFACE_OFFSET_METERS,
                midpointZ + awayZ * KEYBOARD_FORWARD_OFFSET_METERS,
            ),
        yawDegrees = yaw,
    )
  }

  /** Places a keyboard on the top-center of a scanned table and turns it toward the viewer. */
  fun fromSceneSurface(surfaceCenter: Point3, head: Point3): TabletopPose? {
    val awayX = surfaceCenter.x - head.x
    val awayZ = surfaceCenter.z - head.z
    val distance = sqrt(awayX * awayX + awayZ * awayZ)
    if (distance < 0.15f) return null
    val normalizedAwayX = awayX / distance
    val normalizedAwayZ = awayZ / distance
    val rightX = normalizedAwayZ
    val rightZ = -normalizedAwayX
    val yaw = Math.toDegrees(atan2(-rightZ, rightX).toDouble()).toFloat()
    return TabletopPose(
        center = surfaceCenter.copy(y = surfaceCenter.y + SCENE_SURFACE_LIFT_METERS),
        yawDegrees = yaw,
    )
  }
}
