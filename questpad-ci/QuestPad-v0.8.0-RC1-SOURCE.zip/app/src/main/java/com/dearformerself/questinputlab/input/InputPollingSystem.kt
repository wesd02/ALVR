package com.dearformerself.questinputlab.input

import android.content.SharedPreferences
import com.meta.spatial.core.Query
import com.meta.spatial.core.SpatialSDKExperimentalAPI
import com.meta.spatial.core.SystemBase
import com.meta.spatial.runtime.ButtonBits
import com.meta.spatial.runtime.Scene
import com.meta.spatial.toolkit.AvatarBody
import com.meta.spatial.toolkit.Controller
import com.meta.spatial.toolkit.ControllerType
import com.meta.spatial.toolkit.Transform

internal enum class HandSide {
  LEFT,
  RIGHT,
}

internal fun primaryButtonMask(isHand: Boolean, side: HandSide): Int =
    when {
      // Meta maps hand select to the corresponding face-button slot. Quest 3 testing confirmed
      // left pinch as raw bit 0x00000004.
      isHand && side == HandSide.RIGHT -> ButtonBits.ButtonA
      isHand -> ButtonBits.ButtonX
      side == HandSide.RIGHT -> ButtonBits.ButtonA or ButtonBits.ButtonTriggerR
      else -> ButtonBits.ButtonX or ButtonBits.ButtonTriggerL
    }

/** Polls physical inputs, tracked joints, and the selected mode once per spatial frame. */
@OptIn(SpatialSDKExperimentalAPI::class)
class InputPollingSystem(
    private val state: VirtualInputState,
    private val scene: Scene,
    preferences: SharedPreferences,
    private val inputEnabled: () -> Boolean = { true },
    private val touchXboxRoutingEnabled: () -> Boolean = { true },
    private val onTouchXboxToggleRequested: () -> Unit = {},
    private val tablePlacementArmed: () -> Boolean = { false },
    private val sceneLookupActive: () -> Boolean = { false },
    private val onTablePlacement: (TablePlacementSample) -> Unit = {},
    private val trackingCaptureActive: () -> Boolean = { false },
    /** UI panels are inert during controller-free play until both thumbs point up. */
    private val onHandUiGateChanged: (Boolean) -> Unit = {},
    private val onFrameObserved: (InputSnapshot) -> Unit = {},
    private val onFrameMaintenance: () -> Unit = {},
) : SystemBase() {
  private val handTracker = HandGestureTracker(scene, preferences)
  private val router = InputRouter()
  private var placementHoldStartedNanos = 0L
  private var placementSent = false
  private var displayedLeftRatios: Map<Finger, Float> = emptyMap()
  private var displayedRightRatios: Map<Finger, Float> = emptyMap()
  private var nextRatioDisplayNanos = 0L
  private var lastHandUiUnlocked = false
  private var controllerToggleChordLatched = false

  fun recenterHands() {
    router.recenterHands()
    handTracker.reset()
  }

  internal fun applyPersonalProfile(profile: PersonalGestureProfile): String =
      handTracker.applyPersonalProfile(profile)

  fun startHandCalibration() {
    handTracker.startCalibration()
  }

  fun startThumbTrackpadCalibration() {
    handTracker.startThumbTrackpadCalibration()
  }

  fun cancelHandCalibration() {
    handTracker.cancelCalibration()
  }

  override fun execute() {
    // Run before every early-return path. QuestPad never uses Spatial SDK locomotion; controller
    // sticks must remain gameplay-only even when a panel/move surface temporarily pauses routing.
    onFrameMaintenance()
    if (sceneLookupActive()) runCatching { scene.tickMRScene() }
    val placingTable = tablePlacementArmed()
    val capturingTracking = trackingCaptureActive()
    if (!inputEnabled() && !placingTable && !capturingTracking) {
      handTracker.reset()
      router.recenterHands()
      state.updateFrame(
          right = PhysicalInput.NONE,
          left = PhysicalInput.NONE,
          rightFingers = FingerInput.NONE,
          leftFingers = FingerInput.NONE,
          heldKeys = emptySet(),
          mouse = MouseState.NEUTRAL,
          gamepad = GamepadState.NEUTRAL,
          gestureStatus = "Gameplay input paused while a spatial control surface is active",
      )
      observeFrame()
      return
    }

    val localAvatar =
        Query.where { has(AvatarBody.id) }
            .eval()
            .firstOrNull {
              it.isLocal() && it.getComponent<AvatarBody>().isPlayerControlled
            }

    if (localAvatar == null) {
      handTracker.reset()
      state.updateFrame(
          right = PhysicalInput.NONE,
          left = PhysicalInput.NONE,
          rightFingers = FingerInput.NONE,
          leftFingers = FingerInput.NONE,
          heldKeys = emptySet(),
          mouse = MouseState.NEUTRAL,
          gamepad = GamepadState.NEUTRAL,
          gestureStatus = "Waiting for local avatar input",
      )
      observeFrame()
      return
    }

    val body = localAvatar.getComponent<AvatarBody>()
    val right = observe(body.rightHand.tryGetComponent<Controller>(), HandSide.RIGHT)
    val left = observe(body.leftHand.tryGetComponent<Controller>(), HandSide.LEFT)
    val mode = state.snapshot().mode
    val controllerToggleChord = touchXboxToggleChordHeld(right, left)
    if (controllerToggleChord && !controllerToggleChordLatched) {
      controllerToggleChordLatched = true
      onTouchXboxToggleRequested()
    } else if (!controllerToggleChord) {
      controllerToggleChordLatched = false
    }
    val calibrating = handTracker.isCalibrating()
    val fingerCalibrating = handTracker.isFingerCalibrating()
    val thumbTrackpadCalibrating = handTracker.isThumbTrackpadCalibrating()
    val needsJoints =
        mode == InputMode.HAND_XBOX ||
            mode == InputMode.HAND_KEYBOARD_MOUSE ||
            placingTable ||
            calibrating ||
            capturingTracking
    val gestures =
        if (needsJoints) {
          handTracker.read(
              leftActive = left.active && left.source == PhysicalSource.HAND_TRACKING,
              rightActive = right.active && right.source == PhysicalSource.HAND_TRACKING,
              leftTrackpadEnabled =
                  !fingerCalibrating &&
                      (thumbTrackpadCalibrating ||
                          capturingTracking),
              rightTrackpadEnabled =
                  !fingerCalibrating &&
                      (mode == InputMode.HAND_KEYBOARD_MOUSE ||
                          thumbTrackpadCalibrating ||
                          thumbTrackpadCalibrating ||
                          capturingTracking),
          )
        } else {
          handTracker.reset()
          HandGestureFrame(status = "Joint tracking idle in ${mode.shortLabel}")
        }

    if (placingTable) {
      captureTablePlacement(body, left, right, gestures)
    } else {
      placementHoldStartedNanos = 0L
      placementSent = false
    }
    val output =
        when {
          placingTable || calibrating || capturingTracking -> RoutedOutput()
          controllerToggleChord -> RoutedOutput()
          mode == InputMode.TOUCH_XBOX && !touchXboxRoutingEnabled() -> RoutedOutput()
          else -> router.route(mode, right, left, gestures)
        }
    val handUiUnlocked =
        mode == InputMode.HAND_XBOX && gestures.left.thumbUp && gestures.right.thumbUp
    if (handUiUnlocked != lastHandUiUnlocked) {
      lastHandUiUnlocked = handUiUnlocked
      onHandUiGateChanged(handUiUnlocked)
    }
    updateDisplayedRatios(gestures)
    state.updateFrame(
        right = right,
        left = left,
        rightFingers =
            FingerInput(
                tracked = gestures.right.tracked,
                active = gestures.right.fingers,
                curlRatios = displayedRightRatios,
                calibrated = gestures.right.calibratedFingers,
                calibration = gestures.right.calibration,
                signals = gestures.right.signals,
                thumbTrackpad = gestures.right.thumbTrackpad,
            ),
        leftFingers =
            FingerInput(
                tracked = gestures.left.tracked,
                active = gestures.left.fingers,
                curlRatios = displayedLeftRatios,
                calibrated = gestures.left.calibratedFingers,
                calibration = gestures.left.calibration,
                signals = gestures.left.signals,
                thumbTrackpad = gestures.left.thumbTrackpad,
            ),
        heldKeys = output.heldKeys,
        mouse = output.mouse,
        gamepad = output.gamepad,
        gestureStatus =
            if (placingTable) {
              "TABLE PLACEMENT · rest palms apart on the table, then hold both index pinches"
            } else {
              gestures.status
            },
    )
    observeFrame()
  }

  private fun observeFrame() {
    onFrameObserved(state.snapshot())
  }

  private fun updateDisplayedRatios(gestures: HandGestureFrame) {
    if (!gestures.left.tracked && !gestures.right.tracked) {
      displayedLeftRatios = emptyMap()
      displayedRightRatios = emptyMap()
      nextRatioDisplayNanos = 0L
      return
    }
    val now = System.nanoTime()
    if (now < nextRatioDisplayNanos) return
    displayedLeftRatios = gestures.left.curlRatios
    displayedRightRatios = gestures.right.curlRatios
    nextRatioDisplayNanos = now + RATIO_DISPLAY_INTERVAL_NANOS
  }

  private fun captureTablePlacement(
      body: AvatarBody,
      left: PhysicalInput,
      right: PhysicalInput,
      gestures: HandGestureFrame,
  ) {
    if (placementSent) return
    val ready =
        left.active &&
            right.active &&
            left.source == PhysicalSource.HAND_TRACKING &&
            right.source == PhysicalSource.HAND_TRACKING &&
            left.primaryHeld &&
            right.primaryHeld &&
            gestures.left.palm != null &&
            gestures.right.palm != null
    if (!ready) {
      placementHoldStartedNanos = 0L
      return
    }
    val now = System.nanoTime()
    if (placementHoldStartedNanos == 0L) {
      placementHoldStartedNanos = now
      return
    }
    if (now - placementHoldStartedNanos < TABLE_CONFIRM_HOLD_NANOS) return

    placementSent = true
    val headPosition = body.head.tryGetComponent<Transform>()?.transform?.t
    onTablePlacement(
        TablePlacementSample(
            leftPalm = requireNotNull(gestures.left.palm),
            rightPalm = requireNotNull(gestures.right.palm),
            head = headPosition?.let { Point3(it.x, it.y, it.z) },
        ),
    )
  }

  private fun observe(controller: Controller?, side: HandSide): PhysicalInput {
    if (controller == null || !controller.isActive) return PhysicalInput.NONE

    val isHand = controller.type == ControllerType.HAND
    val primaryMask = primaryButtonMask(isHand, side)

    return PhysicalInput(
        source =
            if (isHand) PhysicalSource.HAND_TRACKING else PhysicalSource.TOUCH_CONTROLLER,
        active = true,
        primaryHeld = (controller.buttonState and primaryMask) != 0,
        rawButtons = controller.buttonState,
    )
  }

  private fun touchXboxToggleChordHeld(right: PhysicalInput, left: PhysicalInput): Boolean {
    if (!right.active || !left.active) return false
    if (right.source != PhysicalSource.TOUCH_CONTROLLER ||
        left.source != PhysicalSource.TOUCH_CONTROLLER) return false
    val leftRequired = ButtonBits.ButtonTriggerL or ButtonBits.ButtonSqueezeL
    val rightRequired = ButtonBits.ButtonTriggerR or ButtonBits.ButtonSqueezeR
    return (left.rawButtons and leftRequired) == leftRequired &&
        (right.rawButtons and rightRequired) == rightRequired
  }

  companion object {
    private const val TABLE_CONFIRM_HOLD_NANOS = 450_000_000L
    private const val RATIO_DISPLAY_INTERVAL_NANOS = 100_000_000L
  }
}
