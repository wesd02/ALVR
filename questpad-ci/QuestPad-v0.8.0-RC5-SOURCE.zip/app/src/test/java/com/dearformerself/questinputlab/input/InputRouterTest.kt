package com.dearformerself.questinputlab.input

import com.meta.spatial.runtime.ButtonBits
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class InputRouterTest {
  private val handInput =
      PhysicalInput(source = PhysicalSource.HAND_TRACKING, active = true)

  @Test
  fun gestureKeyboardCanHoldForwardLeftAndJumpTogether() {
    val router = InputRouter()
    val output =
        router.route(
            mode = InputMode.HAND_KEYBOARD_MOUSE,
            right = handInput,
            left = handInput,
            gestures =
                HandGestureFrame(
                    left =
                        TrackedHandPose(
                            tracked = true,
                            fingers = setOf(Finger.THUMB, Finger.MIDDLE, Finger.RING),
                            calibratedFingers =
                                setOf(Finger.THUMB, Finger.MIDDLE, Finger.RING),
                        ),
                    right = TrackedHandPose(tracked = true),
                ),
        )

    assertEquals(setOf(KeyboardKey.SPACE, KeyboardKey.W, KeyboardKey.A), output.heldKeys)
  }

  @Test
  fun provenPinchFallbackStillHoldsWWhenJointsAreMissing() {
    val router = InputRouter()
    val output =
        router.route(
            mode = InputMode.HAND_KEYBOARD_MOUSE,
            right = handInput,
            left = handInput.copy(primaryHeld = true),
            gestures = HandGestureFrame(),
        )

    assertTrue(KeyboardKey.W in output.heldKeys)
  }

  @Test
  fun uncalibratedJointCurlsCannotEmitGuessedKeys() {
    val router = InputRouter()
    val output =
        router.route(
            mode = InputMode.HAND_KEYBOARD_MOUSE,
            right = handInput,
            left = handInput,
            gestures =
                HandGestureFrame(
                    left =
                        TrackedHandPose(
                            tracked = true,
                            fingers = Finger.entries.toSet(),
                        ),
                ),
        )

    assertTrue(output.heldKeys.isEmpty())
  }

  @Test
  fun partialCalibrationEmitsOnlySuccessfulFingerBindings() {
    val router = InputRouter()
    val output =
        router.route(
            mode = InputMode.HAND_KEYBOARD_MOUSE,
            right = handInput,
            left = handInput,
            gestures =
                HandGestureFrame(
                    left =
                        TrackedHandPose(
                            tracked = true,
                            fingers = setOf(Finger.THUMB, Finger.MIDDLE, Finger.RING),
                            curlRatios =
                                mapOf(
                                    Finger.THUMB to 1.1f,
                                    Finger.MIDDLE to 1.1f,
                                    Finger.RING to 1.1f,
                                ),
                            calibratedFingers = setOf(Finger.MIDDLE, Finger.RING),
                        ),
                ),
        )

    assertEquals(setOf(KeyboardKey.W, KeyboardKey.A), output.heldKeys)
  }

  @Test
  fun calibrationFreeHybridStrokeRoutesItsBinding() {
    val router = InputRouter()
    val output =
        router.route(
            mode = InputMode.HAND_KEYBOARD_MOUSE,
            right = handInput,
            left = handInput,
            gestures =
                HandGestureFrame(
                    left =
                        TrackedHandPose(
                            tracked = true,
                            fingers = setOf(Finger.MIDDLE),
                            signals =
                                mapOf(
                                    Finger.MIDDLE to
                                        FingerGestureSignal(
                                            usable = true,
                                            held = true,
                                            source = FingerGestureSource.THUMB_CONTACT,
                                        ),
                                ),
                        ),
                ),
        )

    assertEquals(setOf(KeyboardKey.W), output.heldKeys)
  }

  @Test
  fun spatialXboxUsesThumbInwardAndPersonalFingerButtons() {
    val router = InputRouter()
    val output =
        router.route(
            mode = InputMode.HAND_XBOX,
            right = handInput,
            left = handInput,
            gestures =
                HandGestureFrame(
                    left =
                        TrackedHandPose(
                            tracked = true,
                            thumbInward = true,
                            fingers = setOf(Finger.INDEX, Finger.MIDDLE),
                            calibratedFingers = setOf(Finger.INDEX, Finger.MIDDLE),
                        ),
                    right =
                        TrackedHandPose(
                            tracked = true,
                            thumbInward = true,
                            fingers = setOf(Finger.INDEX),
                            calibratedFingers = setOf(Finger.INDEX),
                        ),
                ),
        )

    assertTrue(GamepadButton.A in output.gamepad.buttons)
    assertTrue(GamepadButton.X in output.gamepad.buttons)
    assertTrue(GamepadButton.LEFT_TRIGGER in output.gamepad.buttons)
    assertTrue(GamepadButton.RIGHT_TRIGGER in output.gamepad.buttons)
    assertTrue(GamepadButton.LEFT_BUMPER in output.gamepad.buttons)
  }

  @Test
  fun touchControllerMapsFaceTriggersGripsAndDigitalSticks() {
    val router = InputRouter()
    val output =
        router.route(
            mode = InputMode.TOUCH_XBOX,
            right =
                PhysicalInput(
                    source = PhysicalSource.TOUCH_CONTROLLER,
                    active = true,
                    rawButtons =
                        ButtonBits.ButtonA or
                            ButtonBits.ButtonY or
                            ButtonBits.ButtonTriggerR or
                            ButtonBits.ButtonThumbRU,
                ),
            left =
                PhysicalInput(
                    source = PhysicalSource.TOUCH_CONTROLLER,
                    active = true,
                    rawButtons = ButtonBits.ButtonSqueezeL or ButtonBits.ButtonThumbLR,
                ),
            gestures = HandGestureFrame(),
        )

    assertTrue(GamepadButton.A in output.gamepad.buttons)
    assertTrue(GamepadButton.Y in output.gamepad.buttons)
    assertTrue(GamepadButton.RIGHT_TRIGGER in output.gamepad.buttons)
    assertTrue(GamepadButton.LEFT_BUMPER in output.gamepad.buttons)
    assertEquals(1f, output.gamepad.leftX)
    assertEquals(-1f, output.gamepad.rightY)
  }

  @Test
  fun touchControllerRequiresBothGripsForDpadAndUsesMenuPlusGripsForView() {
    val router = InputRouter()

    val noDpad =
        router.route(
            mode = InputMode.TOUCH_XBOX,
            right = PhysicalInput.NONE,
            left =
                PhysicalInput(
                    source = PhysicalSource.TOUCH_CONTROLLER,
                    active = true,
                    rawButtons = ButtonBits.ButtonSqueezeL or ButtonBits.ButtonThumbLU,
                ),
            gestures = HandGestureFrame(),
        )
    assertTrue(GamepadButton.DPAD_UP !in noDpad.gamepad.buttons)
    assertTrue(GamepadButton.LEFT_BUMPER in noDpad.gamepad.buttons)
    assertEquals(-1f, noDpad.gamepad.leftY)

    val dpadOutput =
        router.route(
            mode = InputMode.TOUCH_XBOX,
            right =
                PhysicalInput(
                    source = PhysicalSource.TOUCH_CONTROLLER,
                    active = true,
                    rawButtons = ButtonBits.ButtonSqueezeR,
                ),
            left =
                PhysicalInput(
                    source = PhysicalSource.TOUCH_CONTROLLER,
                    active = true,
                    rawButtons = ButtonBits.ButtonSqueezeL or ButtonBits.ButtonThumbLU,
                ),
            gestures = HandGestureFrame(),
        )
    assertTrue(GamepadButton.DPAD_UP in dpadOutput.gamepad.buttons)
    assertTrue(GamepadButton.LEFT_BUMPER !in dpadOutput.gamepad.buttons)
    assertTrue(GamepadButton.RIGHT_BUMPER !in dpadOutput.gamepad.buttons)
    assertEquals(0f, dpadOutput.gamepad.leftY)

    val stickClickOutput =
        router.route(
            mode = InputMode.TOUCH_XBOX,
            right =
                PhysicalInput(
                    source = PhysicalSource.TOUCH_CONTROLLER,
                    active = true,
                    rawButtons = ButtonBits.ButtonThumbRClick,
                ),
            left =
                PhysicalInput(
                    source = PhysicalSource.TOUCH_CONTROLLER,
                    active = true,
                    rawButtons = ButtonBits.ButtonThumbLClick,
                ),
            gestures = HandGestureFrame(),
        )
    assertTrue(GamepadButton.VIEW !in stickClickOutput.gamepad.buttons)
    assertTrue(GamepadButton.LEFT_STICK in stickClickOutput.gamepad.buttons)
    assertTrue(GamepadButton.RIGHT_STICK in stickClickOutput.gamepad.buttons)

    val viewOutput =
        router.route(
            mode = InputMode.TOUCH_XBOX,
            right =
                PhysicalInput(
                    source = PhysicalSource.TOUCH_CONTROLLER,
                    active = true,
                    rawButtons = ButtonBits.ButtonSqueezeR,
                ),
            left =
                PhysicalInput(
                    source = PhysicalSource.TOUCH_CONTROLLER,
                    active = true,
                    rawButtons = ButtonBits.ButtonMenu or ButtonBits.ButtonSqueezeL,
                ),
            gestures = HandGestureFrame(),
        )
    assertTrue(GamepadButton.VIEW in viewOutput.gamepad.buttons)
    assertTrue(GamepadButton.MENU !in viewOutput.gamepad.buttons)
    assertTrue(GamepadButton.LEFT_BUMPER !in viewOutput.gamepad.buttons)
    assertTrue(GamepadButton.RIGHT_BUMPER !in viewOutput.gamepad.buttons)
  }

  @Test
  fun rightStickMotionNeverLeaksAccidentalR3() {
    val router = InputRouter()
    val movingWithSpuriousClick =
        router.route(
            mode = InputMode.TOUCH_XBOX,
            right =
                PhysicalInput(
                    source = PhysicalSource.TOUCH_CONTROLLER,
                    active = true,
                    rawButtons = ButtonBits.ButtonThumbRR or ButtonBits.ButtonThumbRClick,
                ),
            left = PhysicalInput.NONE,
            gestures = HandGestureFrame(),
        )

    assertEquals(1f, movingWithSpuriousClick.gamepad.rightX)
    assertTrue(GamepadButton.RIGHT_STICK !in movingWithSpuriousClick.gamepad.buttons)

    val centeredClick =
        router.route(
            mode = InputMode.TOUCH_XBOX,
            right =
                PhysicalInput(
                    source = PhysicalSource.TOUCH_CONTROLLER,
                    active = true,
                    rawButtons = ButtonBits.ButtonThumbRClick,
                ),
            left = PhysicalInput.NONE,
            gestures = HandGestureFrame(),
        )
    assertTrue(GamepadButton.RIGHT_STICK in centeredClick.gamepad.buttons)
  }

  @Test
  fun tabletopModeNeverLeaksGameplayOutputs() {
    val router = InputRouter()
    val output =
        router.route(
            mode = InputMode.TABLETOP_KEYBOARD_MOUSE,
            right = handInput.copy(primaryHeld = true),
            left = handInput.copy(primaryHeld = true),
            gestures =
                HandGestureFrame(
                    left = TrackedHandPose(tracked = true, fingers = Finger.entries.toSet()),
                    right = TrackedHandPose(tracked = true, fingers = Finger.entries.toSet()),
                ),
        )

    assertTrue(output.heldKeys.isEmpty())
    assertTrue(output.mouse.buttons.isEmpty())
    assertTrue(output.gamepad.buttons.isEmpty())
  }

  @Test
  fun spatialSticksUseTheSameHorizontalPlaneForBothHands() {
    val router = InputRouter()
    // The first frame establishes each hand's comfortable neutral point.
    router.route(
        mode = InputMode.HAND_XBOX,
        right = handInput,
        left = handInput,
        gestures =
            HandGestureFrame(
                left = TrackedHandPose(tracked = true, palm = Point3(0f, 1f, 0f)),
                right = TrackedHandPose(tracked = true, palm = Point3(0f, 1f, 0f)),
            ),
    )
    val output =
        router.route(
            mode = InputMode.HAND_XBOX,
            right = handInput,
            left = handInput,
            gestures =
                HandGestureFrame(
                    left = TrackedHandPose(tracked = true, palm = Point3(-0.08f, 1f, 0.08f)),
                    right = TrackedHandPose(tracked = true, palm = Point3(0.08f, 1f, -0.08f)),
                ),
        )

    assertTrue(output.gamepad.leftX < 0f)
    assertTrue(output.gamepad.leftY < 0f)
    assertTrue(output.gamepad.rightX > 0f)
    assertTrue(output.gamepad.rightY > 0f)
  }

  @Test
  fun twoThumbsUpReserveTheGestureForUiInsteadOfOpeningGameMenus() {
    val router = InputRouter()
    val output =
        router.route(
            mode = InputMode.HAND_XBOX,
            right = handInput,
            left = handInput,
            gestures =
                HandGestureFrame(
                    left = TrackedHandPose(tracked = true, thumbUp = true),
                    right = TrackedHandPose(tracked = true, thumbUp = true),
                ),
        )

    assertTrue(GamepadButton.MENU !in output.gamepad.buttons)
    assertTrue(GamepadButton.VIEW !in output.gamepad.buttons)
  }

  @Test
  fun leftTrackpadStateCannotStealKeyboardModeSpaceOrD() {
    val router = InputRouter()
    val output =
        router.route(
            mode = InputMode.HAND_KEYBOARD_MOUSE,
            right = handInput,
            left = handInput,
            gestures =
                HandGestureFrame(
                    left =
                        TrackedHandPose(
                            tracked = true,
                            fingers = setOf(Finger.THUMB, Finger.INDEX),
                            signals =
                                mapOf(
                                    Finger.THUMB to FingerGestureSignal(usable = true, held = true),
                                    Finger.INDEX to FingerGestureSignal(usable = true, held = true),
                                ),
                            thumbTrackpad =
                                ThumbTrackpadSignal(
                                    enabled = true,
                                    available = true,
                                    touching = true,
                                    active = true,
                                ),
                        ),
                ),
        )

    assertEquals(setOf(KeyboardKey.SPACE, KeyboardKey.D), output.heldKeys)
  }

  @Test
  fun thumbTrackpadDrivesRelativeMouseAndSuppressesAllRightHandClicks() {
    val router = InputRouter()
    val output =
        router.route(
            mode = InputMode.HAND_KEYBOARD_MOUSE,
            right = handInput,
            left = handInput,
            gestures =
                HandGestureFrame(
                    right =
                        TrackedHandPose(
                            tracked = true,
                            fingers = setOf(Finger.INDEX, Finger.MIDDLE),
                            signals =
                                mapOf(
                                    Finger.INDEX to FingerGestureSignal(usable = true, held = true),
                                    Finger.MIDDLE to FingerGestureSignal(usable = true, held = true),
                                ),
                            thumbTrackpad =
                                ThumbTrackpadSignal(
                                    available = true,
                                    touching = true,
                                    active = true,
                                    deltaX = 0.30f,
                                    deltaY = 0.20f,
                                ),
                        ),
                ),
            nowNanos = 100_000_000L,
        )

    assertEquals(27f, output.mouse.deltaX, 0.001f)
    assertEquals(-18f, output.mouse.deltaY, 0.001f)
    assertTrue(output.mouse.buttons.isEmpty())
  }
  @Test
  fun bothDeepFistsAreReservedForControllerHandoff() {
    val router = InputRouter()
    val fist =
        TrackedHandPose(
            tracked = true,
            fingers = Finger.entries.toSet(),
            calibratedFingers = Finger.entries.toSet(),
            deepFist = true,
        )

    val output =
        router.route(
            mode = InputMode.HAND_XBOX,
            right = handInput,
            left = handInput,
            gestures = HandGestureFrame(left = fist, right = fist),
        )

    assertTrue(output.gamepad.buttons.isEmpty())
    assertEquals(0f, output.gamepad.leftX, 0f)
    assertEquals(0f, output.gamepad.rightX, 0f)
  }

}
