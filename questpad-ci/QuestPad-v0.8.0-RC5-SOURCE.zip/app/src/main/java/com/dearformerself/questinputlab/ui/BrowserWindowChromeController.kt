package com.dearformerself.questinputlab.ui

import android.content.res.ColorStateList
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.core.graphics.toColorInt
import com.dearformerself.questinputlab.R

/** Controls the visible frame surrounding the browser panel. */
class BrowserWindowChromeController(
    private val onBack: () -> Unit,
    private val onToggleKeyboard: () -> Unit,
    private val onPaste: () -> Unit,
    private val onToggleMove: () -> Unit,
    private val onToggleFocus: () -> Unit,
    private val onAdjustWindow: (BrowserWindowAdjustment) -> Unit,
) : AutoCloseable {
  private var rootView: View? = null
  private var moveUnlocked = false
  private var focusModeEnabled = false
  private var widthMeters = 1.60f
  private var heightMeters = 0.90f

  fun attach(root: View) {
    rootView = root
    root.findViewById<Button>(R.id.button_browser_frame_back).setOnClickListener { onBack() }
    root.findViewById<Button>(R.id.button_browser_frame_keyboard).setOnClickListener {
      onToggleKeyboard()
    }
    root.findViewById<Button>(R.id.button_browser_frame_paste).setOnClickListener {
      onPaste()
    }
    root.findViewById<Button>(R.id.button_browser_frame_move).setOnClickListener {
      onToggleMove()
    }
    root.findViewById<Button>(R.id.button_browser_frame_focus).setOnClickListener {
      onToggleFocus()
    }
    root.findViewById<Button>(R.id.button_browser_frame_smaller).setOnClickListener {
      onAdjustWindow(BrowserWindowAdjustment.SMALLER)
    }
    root.findViewById<Button>(R.id.button_browser_frame_larger).setOnClickListener {
      onAdjustWindow(BrowserWindowAdjustment.LARGER)
    }
    root.findViewById<Button>(R.id.button_browser_frame_reset).setOnClickListener {
      onAdjustWindow(BrowserWindowAdjustment.RESET)
    }
    render()
  }

  fun setMoveUnlocked(unlocked: Boolean) {
    moveUnlocked = unlocked
    render()
  }

  fun setWindowSize(width: Float, height: Float) {
    widthMeters = width
    heightMeters = height
    render()
  }

  fun setFocusModeEnabled(enabled: Boolean) {
    focusModeEnabled = enabled
    render()
  }

  private fun render() {
    val root = rootView ?: return
    root.post {
      root.findViewById<View>(R.id.browser_window_border).setBackgroundResource(
          if (moveUnlocked) R.drawable.browser_window_frame_active
          else R.drawable.browser_window_frame,
      )
      root.findViewById<Button>(R.id.button_browser_frame_move).apply {
        text =
            root.context.getString(
                if (moveUnlocked) R.string.browser_frame_lock else R.string.browser_frame_move,
            )
        backgroundTintList =
            ColorStateList.valueOf(
                (if (moveUnlocked) "#B86B22" else "#245460").toColorInt(),
            )
      }
      root.findViewById<Button>(R.id.button_browser_frame_focus).apply {
        text = root.context.getString(if (focusModeEnabled) R.string.focus_mode_on else R.string.focus_mode_off)
        backgroundTintList =
            ColorStateList.valueOf(
                (if (focusModeEnabled) "#167E9B" else "#243443").toColorInt(),
            )
      }
      root.findViewById<TextView>(R.id.text_browser_frame_hint).text =
          if (moveUnlocked) {
            root.context.getString(R.string.browser_frame_move_hint)
          } else {
            root.context.getString(
                R.string.browser_frame_resize_hint,
                widthMeters,
                heightMeters,
            )
          }
    }
  }

  override fun close() {
    rootView = null
  }

}
