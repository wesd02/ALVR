package com.dearformerself.questinputlab.browser

import android.content.Context
import android.util.AttributeSet
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.inputmethod.EditorInfo
import android.webkit.WebView

/** WebView with an explicit native-key entry point for the virtual keyboard backend. */
class InputWebView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.webViewStyle,
) : WebView(context, attrs, defStyleAttr) {
  @Volatile private var questUiInputEnabled = true
  var onControllerMotion: ((MotionEvent) -> Unit)? = null

  /**
   * When Touch → Xbox owns the Quest controllers, consume Horizon/Android pointer and gamepad
   * events before WebView can interpret a trigger as click or a stick as scroll.  BrowserInputBridge
   * still injects the virtual Xbox state through the Gamepad API while this gate is closed.
   */
  fun setQuestUiInputEnabled(enabled: Boolean) {
    questUiInputEnabled = enabled
    if (!enabled) clearFocus()
  }

  override fun dispatchTouchEvent(event: MotionEvent): Boolean =
      if (!questUiInputEnabled) true else super.dispatchTouchEvent(event)

  override fun onGenericMotionEvent(event: MotionEvent): Boolean {
    if (isControllerLike(event.source)) onControllerMotion?.invoke(event)
    return if (!questUiInputEnabled && isControllerLike(event.source)) true
    else super.onGenericMotionEvent(event)
  }

  override fun dispatchKeyEvent(event: KeyEvent): Boolean =
      if (!questUiInputEnabled && isControllerLike(event.source)) true
      else super.dispatchKeyEvent(event)

  private fun isControllerLike(source: Int): Boolean =
      (source and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
          (source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK ||
          (source and InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD

  fun commitVirtualText(text: String): NativeKeyDelivery {
    requestFocus()
    val inputConnection = onCreateInputConnection(EditorInfo())
    val handled = inputConnection?.commitText(text, 1) == true
    return NativeKeyDelivery(
        handled = handled,
        path = if (handled) NativeKeyPath.INPUT_CONNECTION else NativeKeyPath.UNHANDLED,
    )
  }

  fun deliverVirtualKey(event: KeyEvent): NativeKeyDelivery {
    // When an HTML editor is focused, use Chromium's IME connection. Unlike a JavaScript
    // KeyboardEvent, this path can perform the browser's default action and insert text.
    val inputConnection = onCreateInputConnection(EditorInfo())
    if (inputConnection?.sendKeyEvent(event) == true) {
      return NativeKeyDelivery(handled = true, path = NativeKeyPath.INPUT_CONNECTION)
    }

    // A game canvas normally has no input connection. Deliver directly to WebView so Chromium can
    // still receive key down/up as a held gameplay input.
    val directHandled =
        when (event.action) {
          KeyEvent.ACTION_DOWN -> super.onKeyDown(event.keyCode, event)
          KeyEvent.ACTION_UP -> super.onKeyUp(event.keyCode, event)
          else -> false
        }
    return NativeKeyDelivery(
        handled = directHandled,
        path = if (directHandled) NativeKeyPath.WEBVIEW_DIRECT else NativeKeyPath.UNHANDLED,
    )
  }
}

data class NativeKeyDelivery(
    val handled: Boolean,
    val path: NativeKeyPath,
)

enum class NativeKeyPath(val displayName: String) {
  INPUT_CONNECTION("input connection"),
  WEBVIEW_DIRECT("WebView direct"),
  ACTIVITY_WINDOW("activity window"),
  UNHANDLED("unhandled"),
}
