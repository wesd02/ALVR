package com.dearformerself.questinputlab.input

import com.meta.spatial.runtime.ButtonBits
import kotlin.math.abs

data class Point3(val x: Float, val y: Float, val z: Float) {
  operator fun minus(other: Point3): Point3 = Point3(x - other.x, y - other.y, z - other.z)
}

data class TrackedHandPose(
    val tracked: Boolean = false,
    val fingers: Set<Finger> = emptySet(),
    val palm: Point3? = null,
    val curlRatios: Map<Finger, Float> = emptyMap(),
    val calibratedFingers: Set<Finger> = emptySet(),
    val calibration: Map<Finger, FingerCalibrationDiagnostic> = emptyMap(),
    val signals: Map<Finger, FingerGestureSignal> = emptyMap(),
    val thumbTrackpad: ThumbTrackpadSignal = ThumbTrackpadSignal.NONE,
    /** Thumb tucked deliberately toward the palm: the virtual trigger. */
    val thumbInward: Boolean = false,
    /** Thumb deliberately pointing toward the sky. */
    val thumbUp: Boolean = false,
    /** All five fingers are deliberately curled into a deep fist. */
    val deepFist: Boolean = false,
) {
  fun isCalibrated(finger: Finger): Boolean = finger in calibratedFingers

  fun isUsable(finger: Finger): Boolean =
      isCalibrated(finger) || signals[finger]?.usable == true

  fun isActive(finger: Finger): Boolean = isUsable(finger) && finger in fingers

  fun canRead(finger: Finger): Boolean =
      signals[finger]?.usable == true || (isCalibrated(finger) && finger in curlRatios)

  companion object {
    val NONE = TrackedHandPose()
  }
}

data class HandGestureFrame(
    val left: TrackedHandPose = TrackedHandPose.NONE,
    val right: TrackedHandPose = TrackedHandPose.NONE,
    val status: String = "Joint tracking idle",
)

data class RoutedOutput(
    val heldKeys: Set<KeyboardKey> = emptySet(),
    val mouse: MouseState = MouseState.NEUTRAL,
    val gamepad: GamepadState = GamepadState.NEUTRAL,
)

/** Real analog Touch-controller axes captured from Android joystick MotionEvents when available. */
data class TouchAnalogAxes(
    val leftX: Float = 0f,
    val leftY: Float = 0f,
    val rightX: Float = 0f,
    val rightY: Float = 0f,
) {
  val active: Boolean
    get() = abs(leftX) > ANALOG_ACTIVE_EPSILON || abs(leftY) > ANALOG_ACTIVE_EPSILON ||
        abs(rightX) > ANALOG_ACTIVE_EPSILON || abs(rightY) > ANALOG_ACTIVE_EPSILON

  companion object {
    private const val ANALOG_ACTIVE_EPSILON = 0.01f
  }
}

private data class DigitalAxisRamp(
    var direction: Int = 0,
    var startedAtNanos: Long = 0L,
)

/** Converts raw controller/hand observations into one mode-specific virtual output frame. */
class InputRouter {
  private var previousMode: InputMode? = null
  private var leftStickCenter: Point3? = null
  private var rightStickCenter: Point3? = null
  private var previousMousePalm: Point3? = null
  private var pendingMouseX = 0f
  private var pendingMouseY = 0f
  private var lastMouseEmissionNanos = 0L
  private val leftXRamp = DigitalAxisRamp()
  private val leftYRamp = DigitalAxisRamp()
  private val rightXRamp = DigitalAxisRamp()
  private val rightYRamp = DigitalAxisRamp()

  fun recenterHands() {
    leftStickCenter = null
    rightStickCenter = null
    previousMousePalm = null
    pendingMouseX = 0f
    pendingMouseY = 0f
    resetTouchAxisRamps()
  }

  fun route(
      mode: InputMode,
      right: PhysicalInput,
      left: PhysicalInput,
      gestures: HandGestureFrame,
      touchAnalog: TouchAnalogAxes? = null,
      nowNanos: Long = System.nanoTime(),
  ): RoutedOutput {
    if (previousMode != mode) {
      recenterHands()
      previousMode = mode
    }

    return when (mode) {
      InputMode.TOUCH_XBOX -> routeTouchXbox(right, left, touchAnalog, nowNanos)
      InputMode.HAND_XBOX -> routeHandXbox(right, left, gestures)
      InputMode.HAND_KEYBOARD_MOUSE ->
          routeHandKeyboardMouse(right, left, gestures, nowNanos)
      InputMode.TABLETOP_KEYBOARD_MOUSE -> RoutedOutput()
    }
  }

  private fun routeTouchXbox(
      right: PhysicalInput,
      left: PhysicalInput,
      touchAnalog: TouchAnalogAxes?,
      nowNanos: Long,
  ): RoutedOutput {
    val rightBits =
        if (right.active && right.source == PhysicalSource.TOUCH_CONTROLLER) right.rawButtons else 0
    val leftBits =
        if (left.active && left.source == PhysicalSource.TOUCH_CONTROLLER) left.rawButtons else 0
    val bits = rightBits or leftBits

    // Both grips are an explicit modifier layer. D-pad is completely inaccessible unless BOTH
    // grips are held, so normal stick motion can never turn into D-pad accidentally. While this
    // modifier is active the grips do not leak through as Xbox bumpers.
    val bothGripsHeld =
        (leftBits and ButtonBits.ButtonSqueezeL) != 0 &&
            (rightBits and ButtonBits.ButtonSqueezeR) != 0
    val leftDirectionBits =
        leftBits and
            (ButtonBits.ButtonThumbLL or
                ButtonBits.ButtonThumbLR or
                ButtonBits.ButtonThumbLU or
                ButtonBits.ButtonThumbLD)
    val rightDirectionBits =
        rightBits and
            (ButtonBits.ButtonThumbRL or
                ButtonBits.ButtonThumbRR or
                ButtonBits.ButtonThumbRU or
                ButtonBits.ButtonThumbRD)
    val dpadModifier = bothGripsHeld && leftDirectionBits != 0

    // Prefer real Android joystick axes when Horizon exposes them. Spatial SDK's Controller
    // component only supplies direction bits on some runtimes, so the fallback below ramps from
    // a gentle initial deflection instead of converting every touch to an immediate +/-1.
    val analog = touchAnalog?.takeIf { it.active }
    val leftX =
        if (dpadModifier) 0f
        else analog?.leftX ?: fallbackDigitalAxis(
            leftBits, ButtonBits.ButtonThumbLL, ButtonBits.ButtonThumbLR, leftXRamp, nowNanos,
        )
    val leftY =
        if (dpadModifier) 0f
        else analog?.leftY ?: fallbackDigitalAxis(
            leftBits, ButtonBits.ButtonThumbLU, ButtonBits.ButtonThumbLD, leftYRamp, nowNanos,
        )
    val rightX =
        analog?.rightX ?: fallbackDigitalAxis(
            rightBits, ButtonBits.ButtonThumbRL, ButtonBits.ButtonThumbRR, rightXRamp, nowNanos,
        )
    val rightY =
        analog?.rightY ?: fallbackDigitalAxis(
            rightBits, ButtonBits.ButtonThumbRU, ButtonBits.ButtonThumbRD, rightYRamp, nowNanos,
        )

    val leftStickMoving = leftDirectionBits != 0 || abs(leftX) > STICK_CLICK_MOTION_GUARD
    val rightStickMoving = rightDirectionBits != 0 || abs(rightX) > STICK_CLICK_MOTION_GUARD ||
        abs(rightY) > STICK_CLICK_MOTION_GUARD
    val leftStickActuallyMoving = leftStickMoving || abs(leftY) > STICK_CLICK_MOTION_GUARD

    // Xbox View/Select is deliberate: Quest Menu (three-lines) + both grips. Menu by itself
    // remains Xbox Menu/Start. L3/R3 are accepted only when their respective stick is centered;
    // this blocks the Quest runtime's observed spurious click bit during ordinary stick motion.
    val viewChord = bothGripsHeld && (leftBits and ButtonBits.ButtonMenu) != 0

    val buttons = buildSet {
      addIf(bits, ButtonBits.ButtonA, GamepadButton.A)
      addIf(bits, ButtonBits.ButtonB, GamepadButton.B)
      addIf(bits, ButtonBits.ButtonX, GamepadButton.X)
      addIf(bits, ButtonBits.ButtonY, GamepadButton.Y)
      if (!bothGripsHeld) {
        addIf(leftBits, ButtonBits.ButtonSqueezeL, GamepadButton.LEFT_BUMPER)
        addIf(rightBits, ButtonBits.ButtonSqueezeR, GamepadButton.RIGHT_BUMPER)
      }
      addIf(leftBits, ButtonBits.ButtonTriggerL, GamepadButton.LEFT_TRIGGER)
      addIf(rightBits, ButtonBits.ButtonTriggerR, GamepadButton.RIGHT_TRIGGER)
      if ((leftBits and ButtonBits.ButtonMenu) != 0 && !viewChord) add(GamepadButton.MENU)
      if (viewChord) add(GamepadButton.VIEW)
      if (!leftStickActuallyMoving) {
        addIf(leftBits, ButtonBits.ButtonThumbLClick, GamepadButton.LEFT_STICK)
      }
      if (!rightStickMoving) {
        addIf(rightBits, ButtonBits.ButtonThumbRClick, GamepadButton.RIGHT_STICK)
      }
      if (dpadModifier) {
        addIf(leftBits, ButtonBits.ButtonThumbLU, GamepadButton.DPAD_UP)
        addIf(leftBits, ButtonBits.ButtonThumbLD, GamepadButton.DPAD_DOWN)
        addIf(leftBits, ButtonBits.ButtonThumbLL, GamepadButton.DPAD_LEFT)
        addIf(leftBits, ButtonBits.ButtonThumbLR, GamepadButton.DPAD_RIGHT)
      }
    }

    if (bits == 0 && analog == null && leftX == 0f && leftY == 0f && rightX == 0f && rightY == 0f) {
      return RoutedOutput()
    }

    return RoutedOutput(
        gamepad =
            GamepadState(
                buttons = buttons,
                leftX = leftX,
                leftY = leftY,
                rightX = rightX,
                rightY = rightY,
            ),
    )
  }

  private fun routeHandXbox(
      right: PhysicalInput,
      left: PhysicalInput,
      gestures: HandGestureFrame,
  ): RoutedOutput {
    // A two-hand deep-fist chord is reserved for handing control back to the Touch controllers.
    // Never leak the chord as a pile of Xbox buttons while InputPollingSystem times the hold.
    if (gestures.left.deepFist && gestures.right.deepFist) return RoutedOutput()

    // Hands → Xbox deliberately does not use the thumb-on-index surface.  The capture proved
    // that surface cannot reliably distinguish an idle thumb from contact.  Whole-palm motion
    // is the stick; this leaves every thumb pose available for an unambiguous action.
    val uiUnlock = gestures.left.thumbUp && gestures.right.thumbUp
    // The same two-thumb pose unlocks panel interaction.  Do not leak stick/button input into
    // the game while the player is intentionally operating the app UI.
    if (uiUnlock) return RoutedOutput()
    val buttons = buildSet {
      if (gestures.right.tracked) {
        if (gestures.right.thumbInward) add(GamepadButton.RIGHT_TRIGGER)
        if (gestures.right.isActive(Finger.INDEX)) add(GamepadButton.A)
        if (gestures.right.isActive(Finger.MIDDLE)) add(GamepadButton.RIGHT_BUMPER)
        if (gestures.right.isActive(Finger.RING)) add(GamepadButton.B)
        if (gestures.right.isActive(Finger.LITTLE)) add(GamepadButton.Y)
        // One raised thumb is a game control; both raised thumbs is the UI safety gate.
        if (gestures.right.thumbUp && !uiUnlock) add(GamepadButton.MENU)
      }
      if (gestures.left.tracked) {
        if (gestures.left.thumbInward) add(GamepadButton.LEFT_TRIGGER)
        if (gestures.left.isActive(Finger.INDEX)) add(GamepadButton.X)
        if (gestures.left.isActive(Finger.MIDDLE)) add(GamepadButton.LEFT_BUMPER)
        if (gestures.left.isActive(Finger.RING)) add(GamepadButton.LEFT_STICK)
        if (gestures.left.isActive(Finger.LITTLE)) add(GamepadButton.VIEW)
        if (gestures.left.thumbUp && !uiUnlock) add(GamepadButton.VIEW)
      }
    }
    val leftAxes = handStick(gestures.left.palm, left = true)
    val rightAxes = handStick(gestures.right.palm, left = false)
    return RoutedOutput(
        gamepad =
            GamepadState(
                buttons = buttons,
                leftX = leftAxes.first,
                leftY = leftAxes.second,
                rightX = rightAxes.first,
                rightY = rightAxes.second,
            ),
    )
  }

  private fun routeHandKeyboardMouse(
      right: PhysicalInput,
      left: PhysicalInput,
      gestures: HandGestureFrame,
      nowNanos: Long,
  ): RoutedOutput {
    val keys = buildSet {
      if (gestures.left.tracked) {
        if (!left.primaryHeld) addIfActive(gestures.left, Finger.THUMB, KeyboardKey.SPACE)
        if (!left.primaryHeld) addIfActive(gestures.left, Finger.INDEX, KeyboardKey.D)
        addIfActive(gestures.left, Finger.MIDDLE, KeyboardKey.W)
        addIfActive(gestures.left, Finger.RING, KeyboardKey.A)
        addIfActive(gestures.left, Finger.LITTLE, KeyboardKey.S)
      }
      if (
          !gestures.left.canRead(Finger.MIDDLE) &&
              left.active &&
              left.source == PhysicalSource.HAND_TRACKING &&
              left.primaryHeld
      ) {
        // Preserve the already headset-verified pinch path whenever experimental joints are absent.
        add(KeyboardKey.W)
      }

      if (gestures.right.tracked && !gestures.right.thumbTrackpad.touching) {
        if (!right.primaryHeld) {
          addIfActive(gestures.right, Finger.THUMB, KeyboardKey.SHIFT)
        }
        addIfActive(gestures.right, Finger.RING, KeyboardKey.E)
        addIfActive(gestures.right, Finger.LITTLE, KeyboardKey.R)
      }
    }
    val mouseButtons = buildSet {
      if (gestures.right.tracked && !gestures.right.thumbTrackpad.touching) {
        addIfActive(gestures.right, Finger.INDEX, MouseButton.LEFT)
        addIfActive(gestures.right, Finger.MIDDLE, MouseButton.RIGHT)
      }
      if (
          !gestures.right.thumbTrackpad.touching &&
          !gestures.right.canRead(Finger.INDEX) &&
          right.active && right.source == PhysicalSource.HAND_TRACKING && right.primaryHeld
      ) {
        add(MouseButton.LEFT)
      }
    }
    val motion =
        if (gestures.right.thumbTrackpad.touching) {
          previousMousePalm = null
          if (gestures.right.thumbTrackpad.active) {
            emitMouseMotion(
                gestures.right.thumbTrackpad.deltaX * THUMB_TRACKPAD_MOUSE_PIXELS,
                -gestures.right.thumbTrackpad.deltaY * THUMB_TRACKPAD_MOUSE_PIXELS,
                nowNanos,
            )
          } else {
            pendingMouseX = 0f
            pendingMouseY = 0f
            0f to 0f
          }
        } else {
          handMouseMotion(gestures.right.palm, nowNanos)
        }
    return RoutedOutput(
        heldKeys = keys,
        mouse = MouseState(mouseButtons, motion.first, motion.second),
    )
  }

  private fun handStick(palm: Point3?, left: Boolean): Pair<Float, Float> {
    if (palm == null) {
      if (left) leftStickCenter = null else rightStickCenter = null
      return 0f to 0f
    }
    val center = if (left) leftStickCenter else rightStickCenter
    if (center == null) {
      if (left) leftStickCenter = palm else rightStickCenter = palm
      return 0f to 0f
    }
    val delta = palm - center
    val x = applyDeadzone(delta.x / HAND_STICK_RANGE_METERS)
    // The scene uses LOCAL_FLOOR coordinates: x is horizontal and z is forward/back.  The old
    // implementation accidentally used vertical y for the right hand, giving the two sticks
    // incompatible movement planes.
    val y = applyDeadzone(-delta.z / HAND_STICK_RANGE_METERS)
    return x to y
  }

  private fun handMouseMotion(palm: Point3?, nowNanos: Long): Pair<Float, Float> {
    if (palm == null) {
      previousMousePalm = null
      pendingMouseX = 0f
      pendingMouseY = 0f
      return 0f to 0f
    }
    val previous = previousMousePalm
    previousMousePalm = palm
    if (previous == null) return 0f to 0f

    val delta = palm - previous
    if (abs(delta.x) > TRACKING_JUMP_METERS || abs(delta.y) > TRACKING_JUMP_METERS) {
      pendingMouseX = 0f
      pendingMouseY = 0f
      return 0f to 0f
    }
    return emitMouseMotion(
        delta.x * MOUSE_PIXELS_PER_METER,
        -delta.y * MOUSE_PIXELS_PER_METER,
        nowNanos,
    )
  }

  private fun emitMouseMotion(
      deltaX: Float,
      deltaY: Float,
      nowNanos: Long,
  ): Pair<Float, Float> {
    pendingMouseX += deltaX
    pendingMouseY += deltaY
    if (nowNanos - lastMouseEmissionNanos < MOUSE_EMISSION_INTERVAL_NANOS) return 0f to 0f

    lastMouseEmissionNanos = nowNanos
    val outputX = pendingMouseX.coerceIn(-MAX_MOUSE_DELTA, MAX_MOUSE_DELTA)
    val outputY = pendingMouseY.coerceIn(-MAX_MOUSE_DELTA, MAX_MOUSE_DELTA)
    pendingMouseX = 0f
    pendingMouseY = 0f
    return outputX to outputY
  }

  private fun applyDeadzone(value: Float): Float {
    val clamped = value.coerceIn(-1f, 1f)
    if (abs(clamped) <= STICK_DEADZONE) return 0f
    val scaled = (abs(clamped) - STICK_DEADZONE) / (1f - STICK_DEADZONE)
    return if (clamped < 0f) -scaled else scaled
  }

  private fun fallbackDigitalAxis(
      bits: Int,
      negativeMask: Int,
      positiveMask: Int,
      ramp: DigitalAxisRamp,
      nowNanos: Long,
  ): Float {
    val negative = (bits and negativeMask) != 0
    val positive = (bits and positiveMask) != 0
    val direction = when {
      negative == positive -> 0
      negative -> -1
      else -> 1
    }
    if (direction == 0) {
      ramp.direction = 0
      ramp.startedAtNanos = 0L
      return 0f
    }
    if (ramp.direction != direction || ramp.startedAtNanos == 0L) {
      ramp.direction = direction
      ramp.startedAtNanos = nowNanos
    }
    val elapsed = (nowNanos - ramp.startedAtNanos).coerceAtLeast(0L)
    val progress = (elapsed.toFloat() / DIGITAL_AXIS_RAMP_NANOS.toFloat()).coerceIn(0f, 1f)
    val magnitude = DIGITAL_AXIS_INITIAL + (1f - DIGITAL_AXIS_INITIAL) * progress
    return direction * magnitude
  }

  private fun resetTouchAxisRamps() {
    listOf(leftXRamp, leftYRamp, rightXRamp, rightYRamp).forEach { ramp ->
      ramp.direction = 0
      ramp.startedAtNanos = 0L
    }
  }

  private fun MutableSet<GamepadButton>.addIf(
      bits: Int,
      mask: Int,
      button: GamepadButton,
  ) {
    if ((bits and mask) != 0) add(button)
  }

  private fun MutableSet<KeyboardKey>.addIfActive(
      hand: TrackedHandPose,
      finger: Finger,
      key: KeyboardKey,
  ) {
    if (hand.isActive(finger)) add(key)
  }

  private fun MutableSet<MouseButton>.addIfActive(
      hand: TrackedHandPose,
      finger: Finger,
      button: MouseButton,
  ) {
    if (hand.isActive(finger)) add(button)
  }

  companion object {
    private const val HAND_STICK_RANGE_METERS = 0.075f
    private const val STICK_DEADZONE = 0.16f
    private const val STICK_CLICK_MOTION_GUARD = 0.12f
    private const val DIGITAL_AXIS_INITIAL = 0.28f
    private const val DIGITAL_AXIS_RAMP_NANOS = 320_000_000L
    private const val MOUSE_PIXELS_PER_METER = 1_600f
    private const val THUMB_TRACKPAD_MOUSE_PIXELS = 90f
    private const val MAX_MOUSE_DELTA = 90f
    private const val TRACKING_JUMP_METERS = 0.10f
    private const val MOUSE_EMISSION_INTERVAL_NANOS = 33_000_000L
  }
}
