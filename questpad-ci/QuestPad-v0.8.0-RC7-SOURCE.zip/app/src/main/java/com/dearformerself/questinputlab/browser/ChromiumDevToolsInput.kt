package com.dearformerself.questinputlab.browser

import android.net.LocalSocket
import android.net.LocalSocketAddress
import android.os.Process
import android.util.Base64
import androidx.core.net.toUri
import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.io.EOFException
import java.io.InputStream
import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import java.util.concurrent.Executors
import com.dearformerself.questinputlab.input.MouseButton
import org.json.JSONArray
import org.json.JSONObject

/**
 * Sends input through the debug-enabled WebView's Chromium DevTools Protocol endpoint.
 *
 * This is an Input Lab backend, not a production transport. It stays inside this application's
 * abstract Unix socket and is available only while WebView debugging is enabled.
 */
class ChromiumDevToolsInput(
    private val onStatusChanged: (ChromiumInputStatus) -> Unit,
) : Closeable {
  private val executor = Executors.newSingleThreadExecutor()
  private val random = SecureRandom()
  private var targetPath: String? = null
  private var nextCommandId = 1
  private var mouseButtonsMask = 0
  private val mouseMoveLock = Any()
  private var pendingMouseX = 0f
  private var pendingMouseY = 0f
  private var mouseMoveWorkerScheduled = false

  @Volatile private var closed = false

  fun probe() {
    if (closed) return
    executor.execute {
      try {
        targetPath = discoverTargetPath()
        publish(available = true, message = "Chromium socket ready")
      } catch (error: Exception) {
        targetPath = null
        publish(available = false, message = "Chromium socket: ${shortError(error)}")
      }
    }
  }

  /** Queues one key transition and returns false only when this client has already closed. */
  fun dispatchKey(key: ChromiumKey, held: Boolean, modifiers: Int = key.modifiers): Boolean {
    if (closed) return false
    executor.execute {
      try {
        val path = targetPath ?: discoverTargetPath().also { targetPath = it }
        val commandId = nextCommandId++
        val accepted = dispatchKeyCommand(path, commandId, key, held, modifiers)
        if (!accepted) throw IllegalStateException("CDP rejected command")
        publish(
            available = true,
            message =
                "${key.displayLabel} ${if (held) "keyDown" else "keyUp"} accepted",
        )
      } catch (error: Exception) {
        targetPath = null
        publish(available = false, message = "Chromium key: ${shortError(error)}")
      }
    }
    return true
  }

  /** Queues a complete press for a spatial keyboard key. */
  fun tapKey(key: ChromiumKey): Boolean {
    if (closed) return false
    executor.execute {
      try {
        val path = targetPath ?: discoverTargetPath().also { targetPath = it }
        val downAccepted =
            dispatchKeyCommand(path, nextCommandId++, key, held = true, key.modifiers)
        val upAccepted = dispatchKeyCommand(path, nextCommandId++, key, held = false, 0)
        if (!downAccepted || !upAccepted) throw IllegalStateException("CDP rejected key tap")
        publish(available = true, message = "${key.displayLabel} typed")
      } catch (error: Exception) {
        targetPath = null
        publish(available = false, message = "Chromium key: ${shortError(error)}")
      }
    }
    return true
  }

  /** Inserts text into Chromium's currently focused editable element without synthesizing keys. */
  fun insertText(text: String): Boolean {
    if (closed || text.isEmpty()) return !closed
    executor.execute {
      try {
        val path = targetPath ?: discoverTargetPath().also { targetPath = it }
        val commandId = nextCommandId++
        val accepted = dispatchInsertTextCommand(path, commandId, text)
        if (!accepted) throw IllegalStateException("CDP rejected text insertion")
        publish(available = true, message = "Inserted ${text.length} clipboard characters")
      } catch (error: Exception) {
        targetPath = null
        publish(available = false, message = "Chromium paste: ${shortError(error)}")
      }
    }
    return true
  }

  /** Coalesces high-frequency relative pointer updates so Chromium commands cannot queue forever. */
  fun dispatchMouseMove(deltaX: Float, deltaY: Float): Boolean {
    if (closed || (deltaX == 0f && deltaY == 0f)) return !closed
    val scheduleWorker =
        synchronized(mouseMoveLock) {
          pendingMouseX += deltaX
          pendingMouseY += deltaY
          if (mouseMoveWorkerScheduled) {
            false
          } else {
            mouseMoveWorkerScheduled = true
            true
          }
        }
    if (scheduleWorker) executor.execute(::drainMouseMoves)
    return true
  }

  fun dispatchMouseButton(button: MouseButton, held: Boolean): Boolean {
    if (closed) return false
    executor.execute {
      try {
        mouseButtonsMask =
            if (held) {
              mouseButtonsMask or button.cdpMask
            } else {
              mouseButtonsMask and button.cdpMask.inv()
            }
        val path = targetPath ?: discoverTargetPath().also { targetPath = it }
        val accepted =
            dispatchMouseCommand(
                path = path,
                commandId = nextCommandId++,
                type = if (held) "mousePressed" else "mouseReleased",
                button = button.cdpName,
                buttons = mouseButtonsMask,
                deltaX = 0f,
                deltaY = 0f,
                clickCount = 1,
            )
        if (!accepted) throw IllegalStateException("CDP rejected mouse button")
        publish(
            available = true,
            message = "${button.displayName} ${if (held) "down" else "up"} accepted",
        )
      } catch (error: Exception) {
        targetPath = null
        publish(available = false, message = "Chromium mouse: ${shortError(error)}")
      }
    }
    return true
  }

  private fun drainMouseMoves() {
    while (!closed) {
      val movement =
          synchronized(mouseMoveLock) {
            val value = pendingMouseX to pendingMouseY
            pendingMouseX = 0f
            pendingMouseY = 0f
            value
          }
      if (movement.first == 0f && movement.second == 0f) {
        synchronized(mouseMoveLock) {
          if (pendingMouseX == 0f && pendingMouseY == 0f) {
            mouseMoveWorkerScheduled = false
            return
          }
        }
        continue
      }

      try {
        val path = targetPath ?: discoverTargetPath().also { targetPath = it }
        val accepted =
            dispatchMouseCommand(
                path = path,
                commandId = nextCommandId++,
                type = "mouseMoved",
                button = "none",
                buttons = mouseButtonsMask,
                deltaX = movement.first,
                deltaY = movement.second,
                clickCount = 0,
            )
        if (!accepted) throw IllegalStateException("CDP rejected mouse move")
        publish(available = true, message = "Mouse move accepted")
      } catch (error: Exception) {
        targetPath = null
        publish(available = false, message = "Chromium mouse: ${shortError(error)}")
      }
    }
    synchronized(mouseMoveLock) { mouseMoveWorkerScheduled = false }
  }

  private fun discoverTargetPath(): String {
    val socket = connectSocket()
    try {
      val request =
          "GET /json/list HTTP/1.1\r\n" +
              "Host: localhost\r\n" +
              "Connection: close\r\n\r\n"
      socket.outputStream.write(request.toByteArray(StandardCharsets.US_ASCII))
      socket.outputStream.flush()
      val response = readHttpResponse(socket.inputStream)
      if (response.statusCode != 200) {
        throw IllegalStateException("target list HTTP ${response.statusCode}")
      }

      val targets = JSONArray(response.body)
      for (index in 0 until targets.length()) {
        val target = targets.optJSONObject(index) ?: continue
        val debuggerUrl = target.optString("webSocketDebuggerUrl")
        if (debuggerUrl.isBlank()) continue
        val uri = debuggerUrl.toUri()
        val encodedPath = uri.encodedPath ?: continue
        return if (uri.encodedQuery.isNullOrBlank()) {
          encodedPath
        } else {
          "$encodedPath?${uri.encodedQuery}"
        }
      }
      throw IllegalStateException("no page target")
    } finally {
      socket.close()
    }
  }

  private fun dispatchKeyCommand(
      path: String,
      commandId: Int,
      key: ChromiumKey,
      held: Boolean,
      modifiers: Int,
  ): Boolean {
    val socket = connectSocket()
    try {
      performWebSocketHandshake(socket, path)
      val params =
          JSONObject()
              .put("type", if (held) "keyDown" else "keyUp")
              .put("modifiers", modifiers)
              .put("timestamp", System.currentTimeMillis() / 1000.0)
              .put("keyIdentifier", key.keyIdentifier)
              .put("code", key.code)
              .put("key", key.key)
              .put("windowsVirtualKeyCode", key.virtualKeyCode)
              .put("nativeVirtualKeyCode", key.virtualKeyCode)
              .put("autoRepeat", false)
              .put("isKeypad", false)
              .put("isSystemKey", false)
              .put("location", 0)
      if (held && key.text != null) {
        params.put("text", key.text).put("unmodifiedText", key.unmodifiedText ?: key.text)
      }
      val command =
          JSONObject()
              .put("id", commandId)
              .put("method", "Input.dispatchKeyEvent")
              .put("params", params)
              .toString()
      writeMaskedTextFrame(socket, command)

      val response = JSONObject(readTextFrame(socket.inputStream))
      return response.optInt("id", -1) == commandId && !response.has("error")
    } finally {
      socket.close()
    }
  }

  private fun dispatchInsertTextCommand(path: String, commandId: Int, text: String): Boolean {
    val socket = connectSocket()
    try {
      performWebSocketHandshake(socket, path)
      val command =
          JSONObject()
              .put("id", commandId)
              .put("method", "Input.insertText")
              .put("params", JSONObject().put("text", text))
              .toString()
      writeMaskedTextFrame(socket, command)
      val response = JSONObject(readTextFrame(socket.inputStream))
      return response.optInt("id", -1) == commandId && !response.has("error")
    } finally {
      socket.close()
    }
  }

  private fun dispatchMouseCommand(
      path: String,
      commandId: Int,
      type: String,
      button: String,
      buttons: Int,
      deltaX: Float,
      deltaY: Float,
      clickCount: Int,
  ): Boolean {
    val socket = connectSocket()
    try {
      performWebSocketHandshake(socket, path)
      val params =
          JSONObject()
              .put("type", type)
              .put("x", POINTER_CENTER_X)
              .put("y", POINTER_CENTER_Y)
              .put("modifiers", 0)
              .put("timestamp", System.currentTimeMillis() / 1000.0)
              .put("button", button)
              .put("buttons", buttons)
              .put("clickCount", clickCount)
              .put("deltaX", deltaX)
              .put("deltaY", deltaY)
              .put("pointerType", "mouse")
      val command =
          JSONObject()
              .put("id", commandId)
              .put("method", "Input.dispatchMouseEvent")
              .put("params", params)
              .toString()
      writeMaskedTextFrame(socket, command)
      val response = JSONObject(readTextFrame(socket.inputStream))
      return response.optInt("id", -1) == commandId && !response.has("error")
    } finally {
      socket.close()
    }
  }

  private fun connectSocket(): LocalSocket {
    val socket = LocalSocket()
    socket.connect(
        LocalSocketAddress(
            "webview_devtools_remote_${Process.myPid()}",
            LocalSocketAddress.Namespace.ABSTRACT,
        ),
    )
    // LocalSocket does not create its underlying file descriptor until connect(). Setting a socket
    // option before this point fails on Quest with "socket not created".
    socket.soTimeout = SOCKET_TIMEOUT_MS
    return socket
  }

  private fun performWebSocketHandshake(socket: LocalSocket, path: String) {
    val keyBytes = ByteArray(16).also(random::nextBytes)
    val key = Base64.encodeToString(keyBytes, Base64.NO_WRAP)
    val request =
        "GET $path HTTP/1.1\r\n" +
            "Host: localhost\r\n" +
            "Upgrade: websocket\r\n" +
            "Connection: Upgrade\r\n" +
            "Sec-WebSocket-Key: $key\r\n" +
            "Sec-WebSocket-Version: 13\r\n\r\n"
    socket.outputStream.write(request.toByteArray(StandardCharsets.US_ASCII))
    socket.outputStream.flush()
    val headers = String(readUntilHeaderEnd(socket.inputStream), StandardCharsets.US_ASCII)
    if (!headers.startsWith("HTTP/1.1 101") && !headers.startsWith("HTTP/1.0 101")) {
      throw IllegalStateException("WebSocket upgrade failed")
    }
  }

  private fun writeMaskedTextFrame(socket: LocalSocket, text: String) {
    val payload = text.toByteArray(StandardCharsets.UTF_8)
    require(payload.size <= 0xffff) { "CDP command is too large" }
    val frame = ByteArrayOutputStream(payload.size + 16)
    frame.write(0x81)
    when {
      payload.size <= 125 -> frame.write(0x80 or payload.size)
      else -> {
        frame.write(0x80 or 126)
        frame.write((payload.size ushr 8) and 0xff)
        frame.write(payload.size and 0xff)
      }
    }
    val mask = ByteArray(4).also(random::nextBytes)
    frame.write(mask)
    payload.forEachIndexed { index, byte ->
      frame.write((byte.toInt() and 0xff) xor (mask[index % mask.size].toInt() and 0xff))
    }
    socket.outputStream.write(frame.toByteArray())
    socket.outputStream.flush()
  }

  private fun readTextFrame(input: InputStream): String {
    val first = readByte(input)
    val opcode = first and 0x0f
    if (opcode != 0x01) throw IllegalStateException("unexpected WebSocket opcode $opcode")
    val second = readByte(input)
    val masked = (second and 0x80) != 0
    var length = second and 0x7f
    if (length == 126) length = (readByte(input) shl 8) or readByte(input)
    if (length == 127) throw IllegalStateException("oversized WebSocket response")
    val mask = if (masked) readExactly(input, 4) else null
    val payload = readExactly(input, length)
    if (mask != null) {
      payload.indices.forEach { index ->
        payload[index] =
            (payload[index].toInt() xor mask[index % mask.size].toInt()).toByte()
      }
    }
    return String(payload, StandardCharsets.UTF_8)
  }

  private fun readHttpResponse(input: InputStream): HttpResponse {
    val headerText = String(readUntilHeaderEnd(input), StandardCharsets.US_ASCII)
    val statusCode = headerText.lineSequence().first().split(' ').getOrNull(1)?.toIntOrNull() ?: -1
    val contentLength =
        headerText
            .lineSequence()
            .firstOrNull { it.startsWith("Content-Length:", ignoreCase = true) }
            ?.substringAfter(':')
            ?.trim()
            ?.toIntOrNull()
            ?: throw IllegalStateException("missing Content-Length")
    return HttpResponse(
        statusCode = statusCode,
        body = String(readExactly(input, contentLength), StandardCharsets.UTF_8),
    )
  }

  private fun readUntilHeaderEnd(input: InputStream): ByteArray {
    val output = ByteArrayOutputStream()
    var matched = 0
    while (output.size() < MAX_HEADER_BYTES) {
      val byte = readByte(input)
      output.write(byte)
      matched =
          when {
            matched == 0 && byte == '\r'.code -> 1
            matched == 1 && byte == '\n'.code -> 2
            matched == 2 && byte == '\r'.code -> 3
            matched == 3 && byte == '\n'.code -> return output.toByteArray()
            byte == '\r'.code -> 1
            else -> 0
          }
    }
    throw IllegalStateException("HTTP headers too large")
  }

  private fun readExactly(input: InputStream, size: Int): ByteArray {
    val bytes = ByteArray(size)
    var offset = 0
    while (offset < size) {
      val read = input.read(bytes, offset, size - offset)
      if (read < 0) throw EOFException("unexpected end of stream")
      offset += read
    }
    return bytes
  }

  private fun readByte(input: InputStream): Int {
    val byte = input.read()
    if (byte < 0) throw EOFException("unexpected end of stream")
    return byte
  }

  private fun publish(available: Boolean, message: String) {
    if (!closed) onStatusChanged(ChromiumInputStatus(available, message))
  }

  private fun shortError(error: Exception): String =
      (error.message ?: error.javaClass.simpleName).replace('\n', ' ').take(68)

  override fun close() {
    closed = true
    executor.shutdownNow()
  }

  private data class HttpResponse(val statusCode: Int, val body: String)

  companion object {
    private const val SOCKET_TIMEOUT_MS = 2_000
    private const val MAX_HEADER_BYTES = 32 * 1024
    private const val POINTER_CENTER_X = 640
    private const val POINTER_CENTER_Y = 360
  }
}

data class ChromiumInputStatus(
    val available: Boolean,
    val message: String,
) {
  companion object {
    val STARTING = ChromiumInputStatus(available = false, message = "Chromium socket starting")
  }
}

/** A platform-neutral key description for Chromium's Input.dispatchKeyEvent command. */
data class ChromiumKey(
    val displayLabel: String,
    val key: String,
    val code: String,
    val virtualKeyCode: Int,
    val text: String? = null,
    val unmodifiedText: String? = text,
    val modifiers: Int = 0,
    val keyIdentifier: String = "",
) {
  companion object {
    const val ALT_MODIFIER = 1
    const val CONTROL_MODIFIER = 2
    const val SHIFT_MODIFIER = 8

    val BACKSPACE =
        ChromiumKey(
            displayLabel = "Backspace",
            key = "Backspace",
            code = "Backspace",
            virtualKeyCode = 8,
        )
    val TAB =
        ChromiumKey(
            displayLabel = "Tab",
            key = "Tab",
            code = "Tab",
            virtualKeyCode = 9,
        )
    val ENTER =
        ChromiumKey(
            displayLabel = "Enter",
            key = "Enter",
            code = "Enter",
            virtualKeyCode = 13,
            text = "\r",
        )
    val SPACE =
        ChromiumKey(
            displayLabel = "Space",
            key = " ",
            code = "Space",
            virtualKeyCode = 32,
            text = " ",
        )
    val SHIFT =
        ChromiumKey(
            displayLabel = "Shift",
            key = "Shift",
            code = "ShiftLeft",
            virtualKeyCode = 16,
            modifiers = SHIFT_MODIFIER,
        )
    val CONTROL =
        ChromiumKey(
            displayLabel = "Control",
            key = "Control",
            code = "ControlLeft",
            virtualKeyCode = 17,
            modifiers = CONTROL_MODIFIER,
        )
    val ALT =
        ChromiumKey(
            displayLabel = "Alt",
            key = "Alt",
            code = "AltLeft",
            virtualKeyCode = 18,
            modifiers = ALT_MODIFIER,
        )
    val ESCAPE =
        ChromiumKey(
            displayLabel = "Escape",
            key = "Escape",
            code = "Escape",
            virtualKeyCode = 27,
        )

    fun character(character: Char): ChromiumKey {
      if (character.isLetter()) {
        val upper = character.uppercaseChar()
        val shifted = character.isUpperCase()
        return ChromiumKey(
            displayLabel = character.toString(),
            key = character.toString(),
            code = "Key$upper",
            virtualKeyCode = upper.code,
            text = character.toString(),
            unmodifiedText = character.lowercaseChar().toString(),
            modifiers = if (shifted) SHIFT_MODIFIER else 0,
            keyIdentifier = "U+%04X".format(upper.code),
        )
      }
      if (character.isDigit()) {
        return ChromiumKey(
            displayLabel = character.toString(),
            key = character.toString(),
            code = "Digit$character",
            virtualKeyCode = character.code,
            text = character.toString(),
            keyIdentifier = "U+%04X".format(character.code),
        )
      }

      val description = CHARACTER_KEYS[character]
          ?: throw IllegalArgumentException("Unsupported keyboard character: $character")
      return ChromiumKey(
          displayLabel = character.toString(),
          key = character.toString(),
          code = description.code,
          virtualKeyCode = description.virtualKeyCode,
          text = character.toString(),
          unmodifiedText = description.unmodified.toString(),
          modifiers = if (description.shifted) SHIFT_MODIFIER else 0,
          keyIdentifier = "U+%04X".format(character.code),
      )
    }

    private val CHARACTER_KEYS =
        mapOf(
            ' ' to CharacterKey("Space", 32, ' ', false),
            '!' to CharacterKey("Digit1", 49, '1', true),
            '@' to CharacterKey("Digit2", 50, '2', true),
            '#' to CharacterKey("Digit3", 51, '3', true),
            '$' to CharacterKey("Digit4", 52, '4', true),
            '%' to CharacterKey("Digit5", 53, '5', true),
            '^' to CharacterKey("Digit6", 54, '6', true),
            '&' to CharacterKey("Digit7", 55, '7', true),
            '*' to CharacterKey("Digit8", 56, '8', true),
            '(' to CharacterKey("Digit9", 57, '9', true),
            ')' to CharacterKey("Digit0", 48, '0', true),
            '-' to CharacterKey("Minus", 189, '-', false),
            '_' to CharacterKey("Minus", 189, '-', true),
            '=' to CharacterKey("Equal", 187, '=', false),
            '+' to CharacterKey("Equal", 187, '=', true),
            '[' to CharacterKey("BracketLeft", 219, '[', false),
            '{' to CharacterKey("BracketLeft", 219, '[', true),
            ']' to CharacterKey("BracketRight", 221, ']', false),
            '}' to CharacterKey("BracketRight", 221, ']', true),
            '\\' to CharacterKey("Backslash", 220, '\\', false),
            '|' to CharacterKey("Backslash", 220, '\\', true),
            ';' to CharacterKey("Semicolon", 186, ';', false),
            ':' to CharacterKey("Semicolon", 186, ';', true),
            '\'' to CharacterKey("Quote", 222, '\'', false),
            '"' to CharacterKey("Quote", 222, '\'', true),
            ',' to CharacterKey("Comma", 188, ',', false),
            '<' to CharacterKey("Comma", 188, ',', true),
            '.' to CharacterKey("Period", 190, '.', false),
            '>' to CharacterKey("Period", 190, '.', true),
            '/' to CharacterKey("Slash", 191, '/', false),
            '?' to CharacterKey("Slash", 191, '/', true),
            '`' to CharacterKey("Backquote", 192, '`', false),
            '~' to CharacterKey("Backquote", 192, '`', true),
        )
  }

  private data class CharacterKey(
      val code: String,
      val virtualKeyCode: Int,
      val unmodified: Char,
      val shifted: Boolean,
  )
}
