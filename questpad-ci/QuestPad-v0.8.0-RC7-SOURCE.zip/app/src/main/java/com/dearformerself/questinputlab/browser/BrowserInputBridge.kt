package com.dearformerself.questinputlab.browser

import android.app.Activity
import android.graphics.Color
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.dearformerself.questinputlab.BuildConfig
import com.dearformerself.questinputlab.input.Finger
import com.dearformerself.questinputlab.input.FingerInput
import com.dearformerself.questinputlab.input.GamepadButton
import com.dearformerself.questinputlab.input.InputMode
import com.dearformerself.questinputlab.input.InputSnapshot
import com.dearformerself.questinputlab.input.KeyboardKey
import com.dearformerself.questinputlab.input.MouseButton
import com.dearformerself.questinputlab.input.MouseState
import com.dearformerself.questinputlab.input.PhysicalSource
import com.dearformerself.questinputlab.input.VirtualInputState
import org.json.JSONArray
import org.json.JSONObject

/** Routes shared virtual state into this application's foreground Chromium WebView. */
class BrowserInputBridge(
    private val activity: Activity,
    private val inputState: VirtualInputState,
) : AutoCloseable {
  private var webView: InputWebView? = null
  private var lastHeldKeys: Set<KeyboardKey> = emptySet()
  private var wDownTime = 0L
  private var lastNativeKeyHandled: Boolean? = null
  private var lastNativeKeyPath: NativeKeyPath? = null
  private var lastWebViewFocused: Boolean? = null
  private var stateMouseButtons: Set<MouseButton> = emptySet()
  private var panelMouseButtons: Set<MouseButton> = emptySet()
  private var dispatchedMouseButtons: Set<MouseButton> = emptySet()
  @Volatile private var chromiumStatus = ChromiumInputStatus.STARTING
  @Volatile private var nativeXboxActive = false
  @Volatile private var lastChromiumCommandQueued = false
  private var lastSnapshot = inputState.snapshot()
  private val stateSubscription = inputState.addListener(::onInputSnapshot)
  private val chromiumInput = ChromiumDevToolsInput(::onChromiumStatusChanged)

  var onStatusChanged: ((String) -> Unit)? = null

  fun setQuestUiInputEnabled(enabled: Boolean) {
    activity.runOnUiThread { webView?.setQuestUiInputEnabled(enabled) }
  }

  fun attach(view: InputWebView) {
    webView = view
    WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)

    view.setBackgroundColor(Color.BLACK)
    view.isFocusable = true
    view.isFocusableInTouchMode = true
    view.settings.apply {
      javaScriptEnabled = true
      domStorageEnabled = true
      databaseEnabled = true
      mediaPlaybackRequiresUserGesture = false
      allowFileAccess = true
      allowContentAccess = true
      mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
      useWideViewPort = true
      loadWithOverviewMode = false
      builtInZoomControls = false
      displayZoomControls = false
      userAgentString = "$userAgentString QuestPad/${BuildConfig.VERSION_NAME}"
    }

    CookieManager.getInstance().apply {
      setAcceptCookie(true)
      setAcceptThirdPartyCookies(view, true)
    }

    view.webChromeClient = WebChromeClient()
    view.webViewClient =
        object : WebViewClient() {
          override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
            onStatusChanged?.invoke("Loading ${shortUrl(url)}")
          }

          override fun onPageFinished(view: WebView, url: String) {
            val inputView = view as? InputWebView ?: return
            onStatusChanged?.invoke("Loaded ${shortUrl(url)} · injecting input bridge")
            view.evaluateJavascript(GAMEPAD_BOOTSTRAP) {
              resendHeldKeyboardState(inputView, lastSnapshot)
              pushBrowserState(view, lastSnapshot)
              chromiumInput.probe()
              onStatusChanged?.invoke("Ready ${shortUrl(url)}")
            }
          }
        }

    loadGeForceNow()
  }

  fun loadLocalTester() {
    navigate(LOCAL_TESTER_URL, "local tester")
  }

  fun loadGeForceNow() {
    navigate(GEFORCE_NOW_URL, "GeForce NOW")
  }

  /**
   * When the shell-level uinput Xbox device is active, let Chromium see the real Android gamepad
   * instead of this app's JavaScript Touch-controller shim.  This prevents double input.
   */
  fun setNativeXboxActive(active: Boolean) {
    if (nativeXboxActive == active) return
    nativeXboxActive = active
    val view = webView ?: return
    view.post {
      if (webView === view) pushBrowserState(view, lastSnapshot)
    }
  }

  fun tapKey(key: ChromiumKey) {
    if (chromiumStatus.available) {
      lastChromiumCommandQueued = chromiumInput.tapKey(key)
      return
    }
    val view = webView ?: return
    view.post { dispatchPanelKeyFallback(view, key) }
  }

  fun rememberFocusedTextTarget() {
    val view = webView ?: return
    view.post {
      if (webView !== view) return@post
      view.evaluateJavascript(REMEMBER_FOCUSED_TEXT_TARGET, null)
    }
  }

  fun insertText(text: String): Boolean {
    if (text.isEmpty()) return false
    val view = webView ?: return false
    view.post {
      if (webView !== view) return@post
      view.evaluateJavascript(RESTORE_FOCUSED_TEXT_TARGET) {
        if (chromiumStatus.available) {
          lastChromiumCommandQueued = chromiumInput.insertText(text)
          onStatusChanged?.invoke(
              if (lastChromiumCommandQueued) "Queued ${text.length} characters for focused Chromium field"
              else "Chromium text insertion unavailable",
          )
          return@evaluateJavascript
        }

        view.requestFocus()
        val delivery = view.commitVirtualText(text)
        lastNativeKeyHandled = delivery.handled
        lastNativeKeyPath = delivery.path
        lastWebViewFocused = view.hasFocus()
        if (delivery.handled) {
          onStatusChanged?.invoke("Inserted ${text.length} characters via WebView input connection")
        } else {
          val quoted = JSONObject.quote(text)
          view.evaluateJavascript(DOM_INSERT_TEXT_PREFIX + quoted + DOM_INSERT_TEXT_SUFFIX) { result ->
            val handled = result == "true"
            lastNativeKeyHandled = handled
            lastNativeKeyPath = if (handled) NativeKeyPath.WEBVIEW_DIRECT else NativeKeyPath.UNHANDLED
            onStatusChanged?.invoke(
                if (handled) "Inserted ${text.length} characters via focused web field"
                else "Text insert failed · focus a GeForce NOW field first",
            )
          }
        }
      }
    }
    return true
  }

  fun movePanelMouse(deltaX: Float, deltaY: Float) {
    lastChromiumCommandQueued = chromiumInput.dispatchMouseMove(deltaX, deltaY)
  }

  fun setPanelMouseButton(button: MouseButton, held: Boolean) {
    panelMouseButtons =
        if (held) panelMouseButtons + button else panelMouseButtons - button
    syncEffectiveMouseButtons()
  }

  fun releasePanelMouseButtons() {
    if (panelMouseButtons.isEmpty()) return
    panelMouseButtons = emptySet()
    syncEffectiveMouseButtons()
  }

  fun canGoBack(): Boolean = webView?.canGoBack() == true

  fun goBack() {
    webView?.post { webView?.goBack() }
  }

  private fun navigate(url: String, label: String) {
    inputState.releaseAll("Navigating to $label")
    releasePanelMouseButtons()
    webView?.post {
      lastHeldKeys = emptySet()
      wDownTime = 0L
      lastNativeKeyHandled = null
      lastNativeKeyPath = null
      lastWebViewFocused = null
      lastChromiumCommandQueued = false
      webView?.loadUrl(url)
    }
  }

  private fun onInputSnapshot(snapshot: InputSnapshot) {
    lastSnapshot = snapshot
    val view = webView ?: return
    view.post {
      if (webView !== view) return@post
      dispatchKeyboardState(view, snapshot.heldKeys)
      dispatchMouseState(snapshot.mouse)
      pushBrowserState(view, snapshot)
    }
  }

  private fun pushBrowserState(view: WebView, snapshot: InputSnapshot) {
    val buttonValues = JSONArray()
    repeat(17) { index ->
      buttonValues.put(snapshot.gamepad.buttons.any { it.standardIndex == index })
    }
    val axes =
        JSONArray()
            .put(snapshot.gamepad.leftX)
            .put(snapshot.gamepad.leftY)
            .put(snapshot.gamepad.rightX)
            .put(snapshot.gamepad.rightY)
    val payload =
        JSONObject()
            .put("sequence", snapshot.sequence)
            .put("version", BuildConfig.VERSION_NAME)
            .put("mode", snapshot.mode.displayName)
            .put("nativeXboxActive", nativeXboxActive && snapshot.mode == InputMode.TOUCH_XBOX)
            .put("xboxA", snapshot.xboxA)
            .put("keyW", snapshot.keyW)
            .put("gamepadButtons", buttonValues)
            .put("gamepadAxes", axes)
            .put("heldKeys", JSONArray(snapshot.heldKeys.map { it.displayName }))
            .put("mouseButtons", JSONArray(snapshot.mouse.buttons.map { it.displayName }))
            .put("mouseDelta", JSONArray().put(snapshot.mouse.deltaX).put(snapshot.mouse.deltaY))
            .put("rightSource", snapshot.right.source.displayName)
            .put("leftSource", snapshot.left.source.displayName)
            .put("rightRawButtons", snapshot.right.rawButtons)
            .put("leftRawButtons", snapshot.left.rawButtons)
            .put(
                "rightHand",
                fingerInputPayload(
                    snapshot.rightFingers,
                    snapshot.right.source == PhysicalSource.HAND_TRACKING &&
                        snapshot.right.primaryHeld,
                ),
            )
            .put(
                "leftHand",
                fingerInputPayload(
                    snapshot.leftFingers,
                    snapshot.left.source == PhysicalSource.HAND_TRACKING &&
                        snapshot.left.primaryHeld,
                ),
            )
            .put("gestureStatus", snapshot.gestureStatus)
            .put("lastReleaseReason", snapshot.lastReleaseReason ?: JSONObject.NULL)
            .put("nativeKeyHandled", lastNativeKeyHandled ?: JSONObject.NULL)
            .put("nativeKeyPath", lastNativeKeyPath?.displayName ?: JSONObject.NULL)
            .put("webViewFocused", lastWebViewFocused ?: JSONObject.NULL)
            .put("chromiumAvailable", chromiumStatus.available)
            .put("chromiumStatus", chromiumStatus.message)
            .put("chromiumCommandQueued", lastChromiumCommandQueued)
    view.evaluateJavascript(
        "window.__questInputLabNativeUpdate && window.__questInputLabNativeUpdate(${payload});",
        null,
    )
  }

  private fun fingerInputPayload(input: FingerInput, nativePinch: Boolean): JSONObject =
      JSONObject()
          .put("tracked", input.tracked)
          .put("nativePinch", nativePinch)
          .put(
              "fingers",
              JSONObject().apply {
                Finger.entries.forEach { finger ->
                  val diagnostic = input.calibration[finger]
                  val signal = input.signals[finger]
                  put(
                      finger.name.lowercase(),
                      JSONObject()
                          .put("active", input.isActive(finger))
                          .put("calibrated", input.isCalibrated(finger))
                          .put("ratio", input.curlRatios[finger] ?: JSONObject.NULL)
                          .put("status", diagnostic?.status?.name ?: JSONObject.NULL)
                          .put("open", diagnostic?.open ?: JSONObject.NULL)
                          .put("closed", diagnostic?.closed ?: JSONObject.NULL)
                          .put("span", diagnostic?.span ?: JSONObject.NULL)
                          .put("press", diagnostic?.press ?: JSONObject.NULL)
                          .put("release", diagnostic?.release ?: JSONObject.NULL)
                          .put("openSamples", diagnostic?.openSamples ?: 0)
                          .put("closedSamples", diagnostic?.closedSamples ?: 0)
                          .put("hybridUsable", signal?.usable == true)
                          .put("hybridHeld", signal?.held == true)
                          .put("hybridSource", signal?.source?.name ?: JSONObject.NULL)
                          .put("sensitivity", signal?.sensitivity?.name ?: JSONObject.NULL)
                          .put("bendDegrees", signal?.bendDegrees ?: JSONObject.NULL)
                          .put("thumbDistanceMm", signal?.thumbDistanceMm ?: JSONObject.NULL)
                          .put("palmDistanceMm", signal?.palmDistanceMm ?: JSONObject.NULL)
                          .put("contactActive", signal?.contactActive == true)
                          .put("bendActive", signal?.bendActive == true)
                          .put("ratioActive", signal?.ratioActive == true)
                          .put("palmActive", signal?.palmActive == true)
                          .put("relativeScore", signal?.relativeScore ?: JSONObject.NULL)
                          .put("conflictSuppressed", signal?.conflictSuppressed == true),
                  )
                }
              },
          )
          .put(
              "thumbTrackpad",
              JSONObject()
                  .put("enabled", input.thumbTrackpad.enabled)
                  .put("available", input.thumbTrackpad.available)
                  .put("touching", input.thumbTrackpad.touching)
                  .put("active", input.thumbTrackpad.active)
                  .put("liftPoseMatched", input.thumbTrackpad.liftPoseMatched)
                  .put("calibrated", input.thumbTrackpad.calibrated)
                  .put("stickX", input.thumbTrackpad.stickX)
                  .put("stickY", input.thumbTrackpad.stickY)
                  .put("deltaX", input.thumbTrackpad.deltaX)
                  .put("deltaY", input.thumbTrackpad.deltaY)
                  .put("alongPercent", input.thumbTrackpad.alongPercent ?: JSONObject.NULL)
                  .put(
                      "surfaceOffsetMm",
                      input.thumbTrackpad.surfaceOffsetMm ?: JSONObject.NULL,
                  )
                  .put("palmSideMm", input.thumbTrackpad.palmSideMm ?: JSONObject.NULL)
                  .put(
                      "contactDistanceMm",
                      input.thumbTrackpad.contactDistanceMm ?: JSONObject.NULL,
                  )
                  .put(
                      "indexLengthMm",
                      input.thumbTrackpad.indexLengthMm ?: JSONObject.NULL,
                  )
                  .put(
                      "calibrationMinSurfaceMm",
                      input.thumbTrackpad.calibrationMinSurfaceMm ?: JSONObject.NULL,
                  )
                  .put(
                      "calibrationMaxSurfaceMm",
                      input.thumbTrackpad.calibrationMaxSurfaceMm ?: JSONObject.NULL,
                  )
                  .put(
                      "calibrationMinAlongPercent",
                      input.thumbTrackpad.calibrationMinAlongPercent ?: JSONObject.NULL,
                  )
                  .put(
                      "calibrationMaxAlongPercent",
                      input.thumbTrackpad.calibrationMaxAlongPercent ?: JSONObject.NULL,
                  ),
          )

  private fun resendHeldKeyboardState(view: InputWebView, snapshot: InputSnapshot) {
    lastHeldKeys = emptySet()
    wDownTime = 0L
    dispatchKeyboardState(view, snapshot.heldKeys)
  }

  private fun dispatchPanelKeyFallback(view: InputWebView, key: ChromiumKey) {
    view.requestFocus()
    val events =
        key.text
            ?.takeIf { it.length == 1 }
            ?.let { KeyCharacterMap.load(KeyCharacterMap.VIRTUAL_KEYBOARD).getEvents(it.toCharArray()) }
    if (!events.isNullOrEmpty()) {
      events.forEach { event -> view.deliverVirtualKey(event) }
      lastNativeKeyHandled = true
      lastNativeKeyPath = NativeKeyPath.WEBVIEW_DIRECT
      return
    }
    val androidKeyCode =
        when (key.code) {
          "Backspace" -> KeyEvent.KEYCODE_DEL
          "Tab" -> KeyEvent.KEYCODE_TAB
          "Enter" -> KeyEvent.KEYCODE_ENTER
          "Space" -> KeyEvent.KEYCODE_SPACE
          "Escape" -> KeyEvent.KEYCODE_ESCAPE
          else -> KeyEvent.KEYCODE_UNKNOWN
        }
    if (androidKeyCode == KeyEvent.KEYCODE_UNKNOWN) return
    val now = SystemClock.uptimeMillis()
    val down = KeyEvent(now, now, KeyEvent.ACTION_DOWN, androidKeyCode, 0)
    val up = KeyEvent(now, now, KeyEvent.ACTION_UP, androidKeyCode, 0)
    val downDelivery = view.deliverVirtualKey(down)
    val upDelivery = view.deliverVirtualKey(up)
    lastNativeKeyHandled = downDelivery.handled || upDelivery.handled
    lastNativeKeyPath = if (downDelivery.handled) downDelivery.path else upDelivery.path
  }

  private fun dispatchKeyboardState(view: InputWebView, desired: Set<KeyboardKey>) {
    if (desired == lastHeldKeys) return

    val active = lastHeldKeys.toMutableSet()
    (lastHeldKeys - desired).sortedBy { if (it.isModifier()) 1 else 0 }.forEach { key ->
      active.remove(key)
      lastChromiumCommandQueued =
          chromiumInput.dispatchKey(key.toChromiumKey(), held = false, modifiersFor(active))
      if (key == KeyboardKey.W) dispatchNativeW(view, held = false)
    }
    (desired - lastHeldKeys).sortedBy { if (it.isModifier()) 0 else 1 }.forEach { key ->
      active.add(key)
      lastChromiumCommandQueued =
          chromiumInput.dispatchKey(key.toChromiumKey(), held = true, modifiersFor(active))
      if (key == KeyboardKey.W) dispatchNativeW(view, held = true)
    }
    lastHeldKeys = desired.toSet()
  }

  private fun dispatchNativeW(view: InputWebView, held: Boolean) {
    val now = SystemClock.uptimeMillis()
    val action = if (held) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP
    if (held) wDownTime = now
    val downTime = if (wDownTime == 0L) now else wDownTime

    lastWebViewFocused = view.requestFocus()
    val event =
        KeyEvent(
            downTime,
            now,
            action,
            KeyEvent.KEYCODE_W,
            0,
            W_SCAN_CODE,
            KeyCharacterMap.VIRTUAL_KEYBOARD,
            0,
            0,
            InputDevice.SOURCE_KEYBOARD,
        )
    var delivery = view.deliverVirtualKey(event)
    if (!delivery.handled && activity.dispatchKeyEvent(event)) {
      delivery = NativeKeyDelivery(handled = true, path = NativeKeyPath.ACTIVITY_WINDOW)
    }
    lastNativeKeyHandled = delivery.handled
    lastNativeKeyPath = delivery.path
    if (!held) wDownTime = 0L
  }

  private fun dispatchMouseState(mouse: MouseState) {
    stateMouseButtons = mouse.buttons
    syncEffectiveMouseButtons()
    if (mouse.deltaX != 0f || mouse.deltaY != 0f) {
      lastChromiumCommandQueued =
          chromiumInput.dispatchMouseMove(mouse.deltaX, mouse.deltaY)
    }
  }

  private fun syncEffectiveMouseButtons() {
    val desired = stateMouseButtons + panelMouseButtons
    (dispatchedMouseButtons - desired).forEach { button ->
      lastChromiumCommandQueued = chromiumInput.dispatchMouseButton(button, held = false)
    }
    (desired - dispatchedMouseButtons).forEach { button ->
      lastChromiumCommandQueued = chromiumInput.dispatchMouseButton(button, held = true)
    }
    dispatchedMouseButtons = desired
  }

  private fun modifiersFor(keys: Set<KeyboardKey>): Int {
    var modifiers = 0
    if (KeyboardKey.ALT in keys) modifiers = modifiers or ChromiumKey.ALT_MODIFIER
    if (KeyboardKey.CONTROL in keys) modifiers = modifiers or ChromiumKey.CONTROL_MODIFIER
    if (KeyboardKey.SHIFT in keys) modifiers = modifiers or ChromiumKey.SHIFT_MODIFIER
    return modifiers
  }

  private fun KeyboardKey.isModifier(): Boolean =
      this == KeyboardKey.SHIFT || this == KeyboardKey.CONTROL || this == KeyboardKey.ALT

  private fun KeyboardKey.toChromiumKey(): ChromiumKey =
      when (this) {
        KeyboardKey.SPACE -> ChromiumKey.SPACE
        KeyboardKey.SHIFT -> ChromiumKey.SHIFT
        KeyboardKey.CONTROL -> ChromiumKey.CONTROL
        KeyboardKey.ALT -> ChromiumKey.ALT
        KeyboardKey.TAB -> ChromiumKey.TAB
        KeyboardKey.ESCAPE -> ChromiumKey.ESCAPE
        else -> ChromiumKey.character(displayName.single().lowercaseChar())
      }

  private fun onChromiumStatusChanged(status: ChromiumInputStatus) {
    chromiumStatus = status
    val view = webView ?: return
    view.post {
      if (webView !== view) return@post
      pushBrowserState(view, lastSnapshot)
    }
  }

  private fun shortUrl(url: String): String {
    return url.removePrefix("https://").removePrefix("file:///android_asset/").take(58)
  }

  override fun close() {
    stateSubscription.close()
    releasePanelMouseButtons()
    val view = webView
    webView = null
    chromiumInput.close()
    activity.runOnUiThread { view?.stopLoading() }
  }

  companion object {
    private const val W_SCAN_CODE = 17
    private const val LOCAL_TESTER_URL = "file:///android_asset/input_tester/index.html"
    private const val GEFORCE_NOW_URL = "https://play.geforcenow.com/"

    private val REMEMBER_FOCUSED_TEXT_TARGET =
        """
        (() => {
          const active = document.activeElement;
          const editable = active && (
            active instanceof HTMLInputElement ||
            active instanceof HTMLTextAreaElement ||
            active.isContentEditable
          );
          if (editable) {
            window.__questpadFocusedTextTarget = active;
            return true;
          }
          return false;
        })();
        """.trimIndent()

    private val RESTORE_FOCUSED_TEXT_TARGET =
        """
        (() => {
          const saved = window.__questpadFocusedTextTarget;
          if (saved && saved.isConnected) {
            saved.focus();
            return true;
          }
          const active = document.activeElement;
          return !!(active && (
            active instanceof HTMLInputElement ||
            active instanceof HTMLTextAreaElement ||
            active.isContentEditable
          ));
        })();
        """.trimIndent()

    private const val DOM_INSERT_TEXT_PREFIX =
        """(() => { const text = """
    private const val DOM_INSERT_TEXT_SUFFIX =
        """; const e = window.__questpadFocusedTextTarget || document.activeElement; if (!e || !e.isConnected) return false; e.focus(); if (e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement) { const proto = e instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set; if (!setter) return false; const old = e.value || ''; const start = Number.isInteger(e.selectionStart) ? e.selectionStart : old.length; const end = Number.isInteger(e.selectionEnd) ? e.selectionEnd : start; const next = old.slice(0, start) + text + old.slice(end); setter.call(e, next); const cursor = start + text.length; try { e.setSelectionRange(cursor, cursor); } catch (_) {} e.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text })); return true; } if (e.isContentEditable) { document.execCommand('insertText', false, text); e.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text })); return true; } return false; })()"""

    private val GAMEPAD_BOOTSTRAP =
        """
        (() => {
          if (window.__questInputLabShim) return;

          const nativeGetGamepads = typeof navigator.getGamepads === 'function'
            ? navigator.getGamepads.bind(navigator)
            : () => [];
          let nativeXboxActive = false;

          const buttons = Array.from({ length: 17 }, () => ({
            pressed: false,
            touched: false,
            value: 0
          }));
          const gamepad = {
            id: 'Quest Input Lab Virtual Xbox Controller',
            index: 0,
            connected: true,
            mapping: 'standard',
            timestamp: performance.now(),
            axes: [0, 0, 0, 0],
            buttons,
            vibrationActuator: null,
            hapticActuators: []
          };

          let keyboardW = false;
          let lastKeyboardTransport = 'waiting';
          let keyboardFallbackTimer = null;

          const announceKeyboardTransport = () => {
            window.dispatchEvent(new CustomEvent('questkeyboardtransport', {
              detail: { keyboardTransport: lastKeyboardTransport, keyW: keyboardW }
            }));
          };

          const isW = (event) =>
            event.code === 'KeyW' || String(event.key || '').toLowerCase() === 'w';

          addEventListener('keydown', (event) => {
            if (event.isTrusted && isW(event)) {
              keyboardW = true;
              lastKeyboardTransport = 'native / trusted';
              if (keyboardFallbackTimer) clearTimeout(keyboardFallbackTimer);
              keyboardFallbackTimer = null;
              announceKeyboardTransport();
            }
          }, true);
          addEventListener('keyup', (event) => {
            if (event.isTrusted && isW(event)) {
              keyboardW = false;
              lastKeyboardTransport = 'native / trusted';
              if (keyboardFallbackTimer) clearTimeout(keyboardFallbackTimer);
              keyboardFallbackTimer = null;
              announceKeyboardTransport();
            }
          }, true);
          addEventListener('blur', () => { keyboardW = false; }, true);

          const emitKeyboardFallback = (held) => {
            const event = new KeyboardEvent(held ? 'keydown' : 'keyup', {
              key: 'w', code: 'KeyW', location: 0, repeat: false,
              bubbles: true, cancelable: true
            });
            try {
              Object.defineProperties(event, {
                keyCode: { get: () => 87 }, which: { get: () => 87 }
              });
            } catch (_) {}
            keyboardW = held;
            lastKeyboardTransport = 'page fallback / untrusted';
            const target = document.activeElement || document.body || document.documentElement || document;
            target.dispatchEvent(event);
            announceKeyboardTransport();
          };

          const update = (state) => {
            nativeXboxActive = !!state.nativeXboxActive;
            const values = Array.isArray(state.gamepadButtons) ? state.gamepadButtons : [];
            for (let index = 0; index < buttons.length; index += 1) {
              const held = !!values[index];
              gamepad.buttons[index] = { pressed: held, touched: held, value: held ? 1 : 0 };
            }
            const axes = Array.isArray(state.gamepadAxes) ? state.gamepadAxes : [0, 0, 0, 0];
            gamepad.axes = [0, 1, 2, 3].map((index) => Number(axes[index]) || 0);
            gamepad.timestamp = performance.now();

            const desiredW = !!state.keyW;
            if (keyboardFallbackTimer) clearTimeout(keyboardFallbackTimer);
            keyboardFallbackTimer = null;
            if (keyboardW !== desiredW) {
              if (state.chromiumCommandQueued || state.chromiumAvailable) {
                keyboardFallbackTimer = setTimeout(() => {
                  keyboardFallbackTimer = null;
                  if (keyboardW !== desiredW) emitKeyboardFallback(desiredW);
                }, 500);
              } else {
                emitKeyboardFallback(desiredW);
              }
            }

            window.dispatchEvent(new CustomEvent('questinputstate', {
              detail: { ...state, keyboardTransport: lastKeyboardTransport }
            }));
          };

          try {
            Object.defineProperty(navigator, 'getGamepads', {
              configurable: true,
              value: () => nativeXboxActive ? nativeGetGamepads() : [gamepad, null, null, null]
            });
          } catch (error) {
            console.error('Quest Input Lab could not override navigator.getGamepads', error);
          }

          window.__questInputLabShim = { gamepad, update, emitKeyboardFallback };
          window.__questInputLabNativeUpdate = update;
          try {
            window.dispatchEvent(new GamepadEvent('gamepadconnected', { gamepad }));
          } catch (_) {
            window.dispatchEvent(new Event('gamepadconnected'));
          }
        })();
        """
            .trimIndent()
  }
}
