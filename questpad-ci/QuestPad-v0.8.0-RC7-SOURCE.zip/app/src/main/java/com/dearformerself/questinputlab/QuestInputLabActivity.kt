package com.dearformerself.questinputlab

import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import androidx.core.content.edit
import com.dearformerself.questinputlab.browser.BrowserInputBridge
import com.dearformerself.questinputlab.browser.InputWebView
import com.dearformerself.questinputlab.input.InputPollingSystem
import com.dearformerself.questinputlab.input.HandSide
import com.dearformerself.questinputlab.input.InputMode
import com.dearformerself.questinputlab.input.Point3
import com.dearformerself.questinputlab.input.TablePlacementSample
import com.dearformerself.questinputlab.input.TabletopPose
import com.dearformerself.questinputlab.input.TabletopPlacement
import com.dearformerself.questinputlab.input.TouchAnalogAxes
import com.dearformerself.questinputlab.input.TrackingCaptureRecorder
import com.dearformerself.questinputlab.input.VirtualInputState
import com.dearformerself.questinputlab.ui.DebugPanelController
import com.dearformerself.questinputlab.ui.BrowserWindowAdjustment
import com.dearformerself.questinputlab.ui.BrowserWindowChromeController
import com.dearformerself.questinputlab.ui.KeyboardPanelController
import com.meta.spatial.core.Color4
import com.meta.spatial.core.Entity
import com.meta.spatial.core.Pose
import com.meta.spatial.core.Quaternion
import com.meta.spatial.core.SpatialFeature
import com.meta.spatial.core.SpatialSDKExperimentalAPI
import com.meta.spatial.core.Vector2
import com.meta.spatial.core.Vector3
import com.meta.spatial.runtime.ReferenceSpace
import com.meta.spatial.isdk.IsdkDefaultCursorSystem
import com.meta.spatial.isdk.IsdkPanelResize
import com.meta.spatial.isdk.ResizeMode
import com.meta.spatial.runtime.JointSet
import com.meta.spatial.runtime.Anchor
import com.meta.spatial.toolkit.AppSystemActivity
import com.meta.spatial.toolkit.DpDisplayOptions
import com.meta.spatial.toolkit.Grabbable
import com.meta.spatial.toolkit.LayoutXMLPanelRegistration
import com.meta.spatial.toolkit.Panel
import com.meta.spatial.toolkit.PanelDimensions
import com.meta.spatial.toolkit.PanelRegistration
import com.meta.spatial.toolkit.PanelStyleOptions
import com.meta.spatial.toolkit.QuadShapeOptions
import com.meta.spatial.toolkit.Transform
import com.meta.spatial.toolkit.UIPanelSettings
import com.meta.spatial.toolkit.Visible
import com.meta.spatial.vr.VRFeature
import com.meta.spatial.vr.LocomotionSystem

class QuestInputLabActivity : AppSystemActivity() {
  private var keyboardVisible = false
  private var systemKeyboardVisible = false
  private var tablePlaced = false
  @Volatile private var tablePlacementArmed = false
  @Volatile private var tablePlacementRequestId = 0L
  @Volatile private var tableSceneLookupActive = false
  private var keyboardEntity: Entity? = null
  private var browserEntity: Entity? = null
  private var browserGrabUnlocked = false
  @Volatile private var handUiUnlocked = false
  private val interactivePanelRoots = mutableListOf<View>()
  @Volatile private var trackingCaptureActive = false
  private val inputState = VirtualInputState()
  private val browserBridge = BrowserInputBridge(this, inputState)
  @Volatile private var controllerRoutingEnabled = false
  @Volatile private var focusModeEnabled = false
  @Volatile private var lastTouchAnalogAxes: TouchAnalogAxes = TouchAnalogAxes()
  @Volatile private var lastLeftAnalogNanos: Long = 0L
  @Volatile private var lastRightAnalogNanos: Long = 0L
  private val controllerSideByDeviceId = mutableMapOf<Int, HandSide>()
  @Volatile private var rawChordLeftBumper = false
  @Volatile private var rawChordRightBumper = false
  @Volatile private var rawChordLeftTrigger = false
  @Volatile private var rawChordRightTrigger = false
  @Volatile private var rawChordLatched = false
  @Volatile private var lastControllerToggleNanos = 0L
  private lateinit var inputPollingSystem: InputPollingSystem
  private lateinit var trackingCaptureRecorder: TrackingCaptureRecorder
  private val keyboardPanelController =
      KeyboardPanelController(
          onKeyTap = browserBridge::tapKey,
          onMouseMove = browserBridge::movePanelMouse,
          onMouseButton = browserBridge::setPanelMouseButton,
          onPaste = ::pasteQuestClipboard,
          onClose = { setKeyboardVisible(false) },
      )
  private val embeddedKeyboardController =
      KeyboardPanelController(
          onKeyTap = browserBridge::tapKey,
          onMouseMove = browserBridge::movePanelMouse,
          onMouseButton = browserBridge::setPanelMouseButton,
          onPaste = ::pasteQuestClipboard,
          onClose = { setKeyboardVisible(false) },
      )
  private val browserWindowChromeController =
      BrowserWindowChromeController(
          onBack = ::navigateBackOrLibrary,
          onToggleKeyboard = { setKeyboardVisible(!keyboardVisible) },
          onSubmitText = ::submitSystemTextEntry,
          onCloseTextEntry = { setSystemTextEntryVisible(false) },
          onPaste = ::pasteQuestClipboard,
          onToggleMove = ::toggleBrowserWindowMove,
          onToggleFocus = ::toggleFocusMode,
          onAdjustWindow = ::adjustBrowserWindow,
      )
  private val debugPanelController =
      DebugPanelController(
          inputState = inputState,
          onOpenLocal = { browserBridge.loadLocalTester() },
          onOpenGeForceNow = { browserBridge.loadGeForceNow() },
          onToggleKeyboard = { setKeyboardVisible(!keyboardVisible) },
          onSelectMode = ::selectMode,
          onPlaceTable = ::beginTablePlacement,
          onCalibrateFingers = ::startFingerCalibration,
          onCalibrateThumbSticks = ::startThumbTrackpadCalibration,
          onToggleTrackingCapture = ::toggleTrackingCapture,
          onApplyLatestCapture = ::applyLatestTrackingCapture,
          onRecenterHands = {
            if (::inputPollingSystem.isInitialized) inputPollingSystem.recenterHands()
          },
          onReleaseAll = { inputState.releaseAll("Manual release") },
          onControllerOn = { setControllerRouting(true) },
          onControllerOff = { setControllerRouting(false) },
          onToggleFocus = ::toggleFocusMode,
          onToggleWindowMove = ::toggleBrowserWindowMove,
          onAdjustWindow = ::adjustBrowserWindow,
      )

  override fun registerFeatures(): List<SpatialFeature> = listOf(VRFeature(this))

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    val preferences = getSharedPreferences(PREFERENCES_NAME, MODE_PRIVATE)
    val savedMode =
        preferences
            .getString(PREFERENCE_INPUT_MODE, null)
            ?.let { value -> InputMode.entries.firstOrNull { it.name == value } }
            ?: InputMode.TOUCH_XBOX
    inputState.setMode(savedMode, "Restored input mode")
    handUiUnlocked = savedMode != InputMode.HAND_XBOX
    trackingCaptureRecorder =
        TrackingCaptureRecorder(
            context = this,
            inputState = inputState,
            onStateChanged = { capture ->
              trackingCaptureActive = capture.active
              debugPanelController.setTrackingCaptureState(capture.active, capture.status)
            },
            onProfileReady = { profile ->
              inputPollingSystem.applyPersonalProfile(profile)
            },
        )
    inputPollingSystem =
        InputPollingSystem(
            state = inputState,
            scene = scene,
            preferences = preferences,
            inputEnabled = { !keyboardVisible && !systemKeyboardVisible && !browserGrabUnlocked },
            touchXboxRoutingEnabled = { controllerRoutingEnabled },
            touchAnalogAxes = ::currentTouchAnalogAxes,
            onTouchXboxToggleRequested = {
              requestControllerToggle("LT + LB + RT + RB")
            },
            onHandControllerHandoffRequested = {
              runOnUiThread {
                selectMode(InputMode.TOUCH_XBOX)
                setControllerRouting(true, "both-hand full fist")
              }
            },
            tablePlacementArmed = { tablePlacementArmed },
            sceneLookupActive = { tableSceneLookupActive },
            onTablePlacement = ::completeTablePlacement,
            trackingCaptureActive = { trackingCaptureActive },
            onHandUiGateChanged = ::setHandUiUnlocked,
            onFrameObserved = { snapshot -> trackingCaptureRecorder.captureFrame(snapshot) },
            onFrameMaintenance = ::enforceSpatialInputPolicy,
        )
    systemManager.registerSystem(inputPollingSystem)
    browserBridge.onStatusChanged = debugPanelController::setBrowserStatus
    renderControllerStatus()
    applyPanelInteractionGate()
  }

  override fun dispatchKeyEvent(event: KeyEvent): Boolean {
    captureRawControllerKey(event)
    return super.dispatchKeyEvent(event)
  }

  private fun captureRawControllerKey(event: KeyEvent) {
    val pressed = event.action == KeyEvent.ACTION_DOWN
    if (event.action != KeyEvent.ACTION_DOWN && event.action != KeyEvent.ACTION_UP) return
    when (event.keyCode) {
      KeyEvent.KEYCODE_BUTTON_X,
      KeyEvent.KEYCODE_BUTTON_Y,
      KeyEvent.KEYCODE_BUTTON_L1,
      KeyEvent.KEYCODE_BUTTON_L2,
      KeyEvent.KEYCODE_BUTTON_THUMBL -> controllerSideByDeviceId[event.deviceId] = HandSide.LEFT
      KeyEvent.KEYCODE_BUTTON_A,
      KeyEvent.KEYCODE_BUTTON_B,
      KeyEvent.KEYCODE_BUTTON_R1,
      KeyEvent.KEYCODE_BUTTON_R2,
      KeyEvent.KEYCODE_BUTTON_THUMBR -> controllerSideByDeviceId[event.deviceId] = HandSide.RIGHT
    }
    when (event.keyCode) {
      KeyEvent.KEYCODE_BUTTON_L1 -> rawChordLeftBumper = pressed
      KeyEvent.KEYCODE_BUTTON_R1 -> rawChordRightBumper = pressed
      KeyEvent.KEYCODE_BUTTON_L2 -> rawChordLeftTrigger = pressed
      KeyEvent.KEYCODE_BUTTON_R2 -> rawChordRightTrigger = pressed
    }
    val held = rawChordLeftBumper && rawChordRightBumper && rawChordLeftTrigger && rawChordRightTrigger
    if (held && !rawChordLatched) {
      rawChordLatched = true
      requestControllerToggle("LT + LB + RT + RB raw")
    } else if (!held) {
      rawChordLatched = false
    }
  }

  private fun requestControllerToggle(reason: String) {
    val now = System.nanoTime()
    if (now - lastControllerToggleNanos < CONTROLLER_TOGGLE_DEBOUNCE_NANOS) return
    lastControllerToggleNanos = now
    runOnUiThread { setControllerRouting(!controllerRoutingEnabled, reason) }
  }

  override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
    captureTouchAnalogMotion(event)
    return super.dispatchGenericMotionEvent(event)
  }

  private fun captureTouchAnalogMotion(event: MotionEvent) {
    if (!isJoystickLike(event.source)) return
    val xy = axisPair(event, MotionEvent.AXIS_X, MotionEvent.AXIS_Y)
    val hat = axisPair(event, MotionEvent.AXIS_HAT_X, MotionEvent.AXIS_HAT_Y)
    val rxRy = axisPair(event, MotionEvent.AXIS_RX, MotionEvent.AXIS_RY)
    val zRz = axisPair(event, MotionEvent.AXIS_Z, MotionEvent.AXIS_RZ)
    val primary = strongestPair(xy, hat)
    val secondary = strongestPair(rxRy, zRz)
    val identity =
        listOfNotNull(event.device?.name, event.device?.descriptor)
            .joinToString(" ")
            .lowercase()
    val rememberedSide = controllerSideByDeviceId[event.deviceId]
    val side =
        when {
          "left" in identity -> HandSide.LEFT
          "right" in identity -> HandSide.RIGHT
          rememberedSide != null -> rememberedSide
          else -> null
        }
    val now = System.nanoTime()
    val current = lastTouchAnalogAxes
    when (side) {
      HandSide.LEFT -> {
        lastTouchAnalogAxes = current.copy(leftX = primary.first, leftY = primary.second)
        lastLeftAnalogNanos = now
      }
      HandSide.RIGHT -> {
        // Quest Touch controllers are separate Android devices. Their thumbstick is the primary
        // X/Y (or HAT) pair; Z/RZ/RX/RY may be trigger-like axes and must not steer the stick.
        lastTouchAnalogAxes = current.copy(rightX = primary.first, rightY = primary.second)
        lastRightAnalogNanos = now
      }
      null -> {
        // Conventional combined gamepad fallback. Keep axis pairs intact instead of mixing Z with
        // RX or RZ with RY, which caused diagonal/wrong-direction steering on RC6.
        lastTouchAnalogAxes =
            TouchAnalogAxes(
                leftX = primary.first,
                leftY = primary.second,
                rightX = secondary.first,
                rightY = secondary.second,
            )
        lastLeftAnalogNanos = now
        lastRightAnalogNanos = now
      }
    }
  }

  private fun axisPair(event: MotionEvent, xAxis: Int, yAxis: Int): Pair<Float, Float> =
      normalizedJoystickAxis(event, xAxis) to normalizedJoystickAxis(event, yAxis)

  private fun strongestPair(first: Pair<Float, Float>, second: Pair<Float, Float>): Pair<Float, Float> {
    val firstMagnitude = first.first * first.first + first.second * first.second
    val secondMagnitude = second.first * second.first + second.second * second.second
    return if (firstMagnitude >= secondMagnitude) first else second
  }

  private fun currentTouchAnalogAxes(): TouchAnalogAxes? {
    val now = System.nanoTime()
    val axes = lastTouchAnalogAxes
    val leftFresh = now - lastLeftAnalogNanos <= TOUCH_ANALOG_MAX_AGE_NANOS
    val rightFresh = now - lastRightAnalogNanos <= TOUCH_ANALOG_MAX_AGE_NANOS
    if (!leftFresh && !rightFresh) return null
    return TouchAnalogAxes(
        leftX = if (leftFresh) axes.leftX else 0f,
        leftY = if (leftFresh) axes.leftY else 0f,
        rightX = if (rightFresh) axes.rightX else 0f,
        rightY = if (rightFresh) axes.rightY else 0f,
    )
  }

  private fun normalizedJoystickAxis(event: MotionEvent, axis: Int): Float {
    val raw = event.getAxisValue(axis).coerceIn(-1f, 1f)
    val flat =
        event.device?.getMotionRange(axis, event.source)?.flat
            ?.coerceIn(0.04f, 0.24f)
            ?: TOUCH_ANALOG_DEADZONE
    val deadzone = maxOf(TOUCH_ANALOG_DEADZONE, flat)
    val magnitude = kotlin.math.abs(raw)
    if (magnitude <= deadzone) return 0f
    val normalized = ((magnitude - deadzone) / (1f - deadzone)).coerceIn(0f, 1f)
    return if (raw < 0f) -normalized else normalized
  }

  private fun isJoystickLike(source: Int): Boolean =
      (source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK ||
          (source and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD

  @Deprecated("Android back callback retained for the minimum Quest API used by this prototype")
  override fun onBackPressed() {
    navigateBackOrLibrary()
  }

  private fun navigateBackOrLibrary() {
    inputState.releaseAll("Browser back")
    if (browserBridge.canGoBack()) browserBridge.goBack() else browserBridge.loadGeForceNow()
  }

  @OptIn(SpatialSDKExperimentalAPI::class)
  override fun onSceneReady() {
    super.onSceneReady()
    scene.setReferenceSpace(ReferenceSpace.LOCAL_FLOOR)
    // Create the visible QuestPad panels before touching passthrough. Passthrough can take
    // time to initialize (or fail on a particular runtime); it must never abort scene startup.
    scene.setViewOrigin(0f, 0f, 0f, 0f)
    // The default body set contains both hands and avoids requiring the optional lower-body
    // extension. If unavailable, HandGestureTracker keeps the proven pinch fallback alive.
    runCatching { scene.setBodyTrackingJointSet(JointSet.DEFAULT) }

    browserEntity =
        Entity.create(
            Panel(R.id.browser_panel),
            PanelDimensions(Vector2(BROWSER_WIDTH_METERS, BROWSER_HEIGHT_METERS)),
            Transform(Pose(Vector3(0f, 1.48f, 1.65f))),
            Grabbable(enabled = false),
            IsdkPanelResize(
                enabled = true,
                resizeMode = ResizeMode.Relayout,
                minDimensions = Vector2(MIN_BROWSER_WIDTH_METERS, MIN_BROWSER_WIDTH_METERS * BROWSER_ASPECT_HEIGHT_OVER_WIDTH),
                maxDimensions = Vector2(MAX_BROWSER_WIDTH_METERS, MAX_BROWSER_WIDTH_METERS * BROWSER_ASPECT_HEIGHT_OVER_WIDTH),
                preserveAspectRatio = true,
            ),
        )
    Entity.create(
        Panel(R.id.debug_panel),
        PanelDimensions(Vector2(DEBUG_WIDTH_METERS, DEBUG_HEIGHT_METERS)),
        Transform(Pose(Vector3(0f, 0.75f, 1.62f))),
    )
    applyFocusMode()
    enforceSpatialInputPolicy()
  }

  override fun registerPanels(): List<PanelRegistration> {
    return listOf(
        LayoutXMLPanelRegistration(
            R.id.browser_panel,
            layoutIdCreator = { R.layout.input_lab_panel },
            settingsCreator = {
              UIPanelSettings(
                  shape =
                      QuadShapeOptions(
                          width = BROWSER_WIDTH_METERS,
                          height = BROWSER_HEIGHT_METERS,
                      ),
                  style = PanelStyleOptions(themeResourceId = R.style.PanelTheme),
                  display = DpDisplayOptions(width = 1280f, height = 720f),
              )
            },
            panelSetupWithRootView = { rootView, _, _ ->
              registerInteractivePanel(rootView)
              rootView.findViewById<InputWebView>(R.id.input_web_view).also { webView ->
                webView.onControllerMotion = ::captureTouchAnalogMotion
                browserBridge.attach(webView)
              }
              browserWindowChromeController.attach(rootView)
              embeddedKeyboardController.attach(rootView)
              browserWindowChromeController.setEmbeddedKeyboardVisible(keyboardVisible)
            },
        ),
        LayoutXMLPanelRegistration(
            R.id.debug_panel,
            layoutIdCreator = { R.layout.debug_panel },
            settingsCreator = {
              UIPanelSettings(
                  shape =
                      QuadShapeOptions(
                          width = DEBUG_WIDTH_METERS,
                          height = DEBUG_HEIGHT_METERS,
                      ),
                  style = PanelStyleOptions(themeResourceId = R.style.PanelTheme),
                  display = DpDisplayOptions(width = 1280f, height = 470f),
              )
            },
            panelSetupWithRootView = { rootView, _, _ ->
              registerInteractivePanel(rootView)
              debugPanelController.attach(rootView)
            },
        ),
        LayoutXMLPanelRegistration(
            R.id.keyboard_panel,
            layoutIdCreator = { R.layout.keyboard_panel },
            settingsCreator = {
              UIPanelSettings(
                  shape =
                      QuadShapeOptions(
                          width = KEYBOARD_WIDTH_METERS,
                          height = KEYBOARD_HEIGHT_METERS,
                      ),
                  style = PanelStyleOptions(themeResourceId = R.style.PanelTheme),
                  display = DpDisplayOptions(width = 1280f, height = 430f),
              )
            },
            panelSetupWithRootView = { rootView, _, _ ->
              registerInteractivePanel(rootView)
              keyboardPanelController.attach(rootView)
            },
        ),
    )
  }

  /**
   * Hand rays only find enabled Android controls.  In Hands → Xbox we keep every panel control
   * disabled until both thumbs point skyward, so normal stick/button motion has no laser target
   * and cannot activate UI by accident.  Touch controllers are unaffected.
   */
  private fun setHandUiUnlocked(unlocked: Boolean) {
    runOnUiThread {
      if (handUiUnlocked == unlocked) return@runOnUiThread
      handUiUnlocked = unlocked
      applyPanelInteractionGate()
    }
  }

  private fun registerInteractivePanel(root: View) {
    interactivePanelRoots += root
    setEnabledRecursively(root, panelUiEnabled())
  }

  private fun panelUiEnabled(): Boolean = handUiUnlocked && !controllerRoutingEnabled

  private fun applyPanelInteractionGate() {
    val enabled = panelUiEnabled()
    interactivePanelRoots.forEach { setEnabledRecursively(it, enabled) }
    browserBridge.setQuestUiInputEnabled(!controllerRoutingEnabled)
  }

  private fun setEnabledRecursively(view: View, enabled: Boolean) {
    view.isEnabled = enabled
    if (view is ViewGroup) {
      for (index in 0 until view.childCount) setEnabledRecursively(view.getChildAt(index), enabled)
    }
  }

  /**
   * QuestPad is a fixed spatial window, not a locomotion app. Thumbsticks always belong to the
   * virtual gamepad and must never translate/rotate the whole Spatial SDK scene. While Touch →
   * Xbox routing is enabled, also hide the SDK ray/cursor visuals; raw Controller components keep
   * updating for InputPollingSystem.
   */
  private fun enforceSpatialInputPolicy() {
    runCatching { systemManager.findSystem<LocomotionSystem>().enableLocomotion(false) }
    runCatching {
      systemManager.findSystem<IsdkDefaultCursorSystem>().enableInput(!controllerRoutingEnabled)
    }
    browserEntity?.tryGetComponent<IsdkPanelResize>()?.let { resize ->
      if (resize.enabled != !controllerRoutingEnabled) {
        resize.enabled = !controllerRoutingEnabled
        browserEntity?.setComponent(resize)
      }
    }
  }

  private fun toggleFocusMode() {
    setFocusMode(!focusModeEnabled)
  }

  private fun setFocusMode(enabled: Boolean) {
    focusModeEnabled = enabled
    applyFocusMode()
    browserWindowChromeController.setFocusModeEnabled(enabled)
    debugPanelController.setFocusModeEnabled(enabled)
  }

  private fun applyFocusMode() {
    // Passthrough is deliberately non-fatal. A runtime passthrough failure must never prevent
    // QuestPad's panels from rendering; Focus Mode can be retried from the visible UI.
    runCatching {
      if (focusModeEnabled) {
        scene.setBackfillColor(Color4(red = 0f, green = 0f, blue = 0f, alpha = 1f))
        scene.enablePassthrough(false)
      } else {
        // Clear the opaque Focus backfill before restoring passthrough. Keeping the black
        // backfill alive can continue to occlude the real-world feed on Quest even after
        // passthrough has been re-enabled.
        scene.setBackfillColor(Color4(red = 0f, green = 0f, blue = 0f, alpha = 0f))
        scene.enablePassthrough(true)
      }
    }
  }

  private fun ensureKeyboardEntity(): Entity {
    keyboardEntity?.let { return it }
    return Entity.create(
            Panel(R.id.keyboard_panel),
            PanelDimensions(Vector2(KEYBOARD_WIDTH_METERS, KEYBOARD_HEIGHT_METERS)),
            Transform(
                Pose(
                    Vector3(0f, 0.72f, 0.85f),
                    Quaternion(90f, 0f, 0f),
                ),
            ),
            Visible(true),
        )
        .also { keyboardEntity = it }
  }

  private fun pasteQuestClipboard() {
    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = clipboard.primaryClip
    val text =
        if (clip != null && clip.itemCount > 0) {
          clip.getItemAt(0).coerceToText(this)?.toString()?.takeIf { it.isNotBlank() }?.take(MAX_CLIPBOARD_CHARS)
        } else {
          null
        }
    if (text == null) {
      debugPanelController.setBrowserStatus("Quest clipboard is empty or unavailable")
      return
    }
    val accepted = browserBridge.insertText(text)
    debugPanelController.setBrowserStatus(
        if (accepted) "Pasting ${text.length} clipboard characters into focused field"
        else "Paste unavailable · focus a GeForce NOW text field and try again",
    )
  }

  private fun toggleSystemTextEntry() {
    setSystemTextEntryVisible(!systemKeyboardVisible)
  }

  private fun setSystemTextEntryVisible(visible: Boolean) {
    if (systemKeyboardVisible == visible) {
      browserWindowChromeController.setTextEntryVisible(visible)
      return
    }
    if (visible && ::trackingCaptureRecorder.isInitialized && trackingCaptureRecorder.isActive) {
      trackingCaptureRecorder.stopAndSave("Capture stopped before system keyboard")
    }
    if (visible && keyboardVisible) setKeyboardVisible(false)
    if (visible) browserBridge.rememberFocusedTextTarget()
    systemKeyboardVisible = visible
    inputState.releaseAll(if (visible) "System keyboard opened" else "System keyboard closed")
    browserWindowChromeController.setTextEntryVisible(visible)
    debugPanelController.setBrowserStatus(
        if (visible) {
          "SYSTEM KEYBOARD · type securely, then Send to the focused GeForce NOW field"
        } else {
          "System keyboard closed"
        },
    )
  }

  private fun submitSystemTextEntry(text: String): Boolean {
    if (text.isBlank()) return false
    val accepted = browserBridge.insertText(text.take(MAX_CLIPBOARD_CHARS))
    debugPanelController.setBrowserStatus(
        if (accepted) "Sending ${text.length.coerceAtMost(MAX_CLIPBOARD_CHARS)} typed characters to focused field"
        else "Text send unavailable · focus a GeForce NOW text field and try again",
    )
    if (accepted) setSystemTextEntryVisible(false)
    return accepted
  }

  private fun placeKeyboardInFrontOfViewer() {
    ensureKeyboardEntity()
    val viewer = scene.getViewerPose().removePitchAndRoll()
    val forward = viewer.forward()
    keyboardEntity?.setComponent(
        Transform(
            Pose(
                Vector3(
                    viewer.t.x + forward.x * DEFAULT_KEYBOARD_DISTANCE_METERS,
                    viewer.t.y - DEFAULT_KEYBOARD_VERTICAL_OFFSET_METERS,
                    viewer.t.z + forward.z * DEFAULT_KEYBOARD_DISTANCE_METERS,
                ),
                viewer.q,
            ),
        ),
    )
    tablePlaced = true
    debugPanelController.setTableStatus("FLOATING KEYBOARD · use Tabletop K/M to anchor it to a desk")
  }

  private fun setKeyboardVisible(visible: Boolean) {
    if (visible && systemKeyboardVisible) setSystemTextEntryVisible(false)
    if (visible && ::trackingCaptureRecorder.isInitialized && trackingCaptureRecorder.isActive) {
      trackingCaptureRecorder.stopAndSave("Capture stopped before opening the keyboard")
    }
    if (keyboardVisible == visible) {
      browserWindowChromeController.setEmbeddedKeyboardVisible(visible)
      return
    }
    if (visible && ::inputPollingSystem.isInitialized) inputPollingSystem.cancelHandCalibration()
    if (visible) browserBridge.rememberFocusedTextTarget()
    keyboardVisible = visible
    if (!visible) browserBridge.releasePanelMouseButtons()
    inputState.releaseAll(if (visible) "Embedded keyboard opened" else "Embedded keyboard closed")
    browserWindowChromeController.setEmbeddedKeyboardVisible(visible)
    debugPanelController.setKeyboardVisible(visible)
    debugPanelController.setBrowserStatus(
        if (visible) "CUSTOM KEYBOARD · type directly into the focused GeForce NOW field"
        else "Custom keyboard closed",
    )
  }

  private fun toggleBrowserWindowMove() {
    if (!browserGrabUnlocked &&
        ::trackingCaptureRecorder.isInitialized &&
        trackingCaptureRecorder.isActive) {
      trackingCaptureRecorder.stopAndSave("Capture stopped before moving the browser")
    }
    browserGrabUnlocked = !browserGrabUnlocked
    browserEntity?.setComponent(Grabbable(enabled = browserGrabUnlocked))
    inputState.releaseAll(
        if (browserGrabUnlocked) "Browser window movement unlocked" else "Browser window locked",
    )
    debugPanelController.setWindowMoveUnlocked(browserGrabUnlocked)
    browserWindowChromeController.setMoveUnlocked(browserGrabUnlocked)
  }

  private fun adjustBrowserWindow(adjustment: BrowserWindowAdjustment) {
    val entity = browserEntity ?: return
    inputState.releaseAll("Browser window adjusted")
    if (adjustment == BrowserWindowAdjustment.RESET) {
      resetBrowserWindow(entity)
      return
    }
    if (adjustment == BrowserWindowAdjustment.SMALLER ||
        adjustment == BrowserWindowAdjustment.LARGER) {
      val factor = if (adjustment == BrowserWindowAdjustment.LARGER) 1.12f else 0.88f
      resizeBrowserWindowBy(factor)
      return
    }

    val currentPose =
        entity.tryGetComponent<Transform>()?.transform
            ?: Pose(Vector3(0f, 1.48f, 1.65f))
    val viewer = scene.getViewerPose().removePitchAndRoll()
    val right = viewer.right()
    val forward = viewer.forward()
    val delta =
        when (adjustment) {
          BrowserWindowAdjustment.LEFT -> scaled(right, -WINDOW_MOVE_STEP_METERS)
          BrowserWindowAdjustment.RIGHT -> scaled(right, WINDOW_MOVE_STEP_METERS)
          BrowserWindowAdjustment.UP -> Vector3(0f, WINDOW_MOVE_STEP_METERS, 0f)
          BrowserWindowAdjustment.DOWN -> Vector3(0f, -WINDOW_MOVE_STEP_METERS, 0f)
          BrowserWindowAdjustment.NEARER -> scaled(forward, -WINDOW_DEPTH_STEP_METERS)
          BrowserWindowAdjustment.FARTHER -> scaled(forward, WINDOW_DEPTH_STEP_METERS)
          else -> Vector3(0f)
        }
    val current = currentPose.t
    val moved =
        Vector3(
            (current.x + delta.x).coerceIn(-MAX_WINDOW_COORDINATE, MAX_WINDOW_COORDINATE),
            (current.y + delta.y).coerceIn(MIN_WINDOW_HEIGHT_METERS, MAX_WINDOW_HEIGHT_METERS),
            (current.z + delta.z).coerceIn(-MAX_WINDOW_COORDINATE, MAX_WINDOW_COORDINATE),
        )
    entity.setComponent(Transform(Pose(moved, currentPose.q)))
  }

  private fun resizeBrowserWindowBy(factor: Float) {
    val entity = browserEntity ?: return
    val currentWidth =
        entity.tryGetComponent<PanelDimensions>()?.dimensions?.x ?: BROWSER_WIDTH_METERS
    val width = (currentWidth * factor).coerceIn(MIN_BROWSER_WIDTH_METERS, MAX_BROWSER_WIDTH_METERS)
    val height = width * BROWSER_ASPECT_HEIGHT_OVER_WIDTH
    entity.setComponent(PanelDimensions(Vector2(width, height)))
    browserWindowChromeController.setWindowSize(width, height)
    debugPanelController.setWindowSize(width, height)
  }

  private fun resetBrowserWindow(entity: Entity) {
    val viewer = scene.getViewerPose().removePitchAndRoll()
    val forward = viewer.forward()
    val center =
        Vector3(
            viewer.t.x + forward.x * DEFAULT_BROWSER_DISTANCE_METERS,
            viewer.t.y - DEFAULT_BROWSER_VERTICAL_OFFSET_METERS,
            viewer.t.z + forward.z * DEFAULT_BROWSER_DISTANCE_METERS,
        )
    entity.setComponent(Transform(Pose(center, viewer.q)))
    entity.setComponent(
        PanelDimensions(Vector2(BROWSER_WIDTH_METERS, BROWSER_HEIGHT_METERS)),
    )
    browserWindowChromeController.setWindowSize(BROWSER_WIDTH_METERS, BROWSER_HEIGHT_METERS)
    debugPanelController.setWindowSize(BROWSER_WIDTH_METERS, BROWSER_HEIGHT_METERS)
  }

  private fun scaled(vector: Vector3, amount: Float): Vector3 =
      Vector3(vector.x * amount, vector.y * amount, vector.z * amount)

  private fun beginTablePlacement() {
    stopTrackingCaptureIfActive("Capture stopped before table placement")
    if (::inputPollingSystem.isInitialized) inputPollingSystem.cancelHandCalibration()
    if (keyboardVisible) setKeyboardVisible(false)
    inputState.releaseAll("Table placement started")
    val requestId = ++tablePlacementRequestId
    if (checkSelfPermission(PERMISSION_USE_SCENE) != PackageManager.PERMISSION_GRANTED) {
      tablePlacementArmed = false
      debugPanelController.setTableStatus(
          "Allow Spatial Data to find a table from Quest Space Setup",
      )
      requestPermissions(arrayOf(PERMISSION_USE_SCENE), REQUEST_CODE_PERMISSION_USE_SCENE)
      return
    }
    tryAutomaticTablePlacement(requestId)
  }

  private fun tryAutomaticTablePlacement(requestId: Long) {
    tablePlacementArmed = false
    tableSceneLookupActive = true
    debugPanelController.setTableStatus(
        "SEARCHING · looking for a table or desk in Quest Space Setup…",
    )
    val options =
        Anchor.FetchOptions(
            componentTypes =
                arrayOf(
                    Anchor.SpaceComponentType.Locatable,
                    Anchor.SpaceComponentType.Bounded3D,
                    Anchor.SpaceComponentType.SemanticLabels,
                ),
        )
    val future =
        runCatching { scene.discoverSpaces(options) }
            .getOrElse {
              tableSceneLookupActive = false
              armManualTablePlacement("Scene lookup could not start")
              return
            }
    future.whenComplete { anchors, error ->
      tableSceneLookupActive = false
      val placement =
          if (error == null && anchors != null) findNearestSceneTable(anchors) else null
      runOnUiThread {
        if (requestId != tablePlacementRequestId) return@runOnUiThread
        if (placement != null) {
          applyTablePlacement(
              placement,
              "AUTO-PLACED · aligned to the nearest table from Quest Space Setup",
          )
        } else {
          armManualTablePlacement(
              if (error == null) {
                "No scanned table found · use the two-palm fallback"
              } else {
                "Scene lookup failed · use the two-palm fallback"
              },
          )
        }
      }
    }
  }

  private fun findNearestSceneTable(anchors: Array<Anchor>) =
      runCatching {
            val head = scene.getViewerPose().t
            anchors
                .mapNotNull { anchor ->
                  runCatching {
                        val labels =
                            scene.getAnchorSemanticLabels(anchor.handle).map { it.trim().uppercase() }
                        if (labels.none { it == "TABLE" || it == "DESK" }) return@runCatching null
                        val bounds =
                            scene.getAnchorBoundingBox3D(anchor.handle)
                                ?: return@runCatching null
                        if (bounds.size().x < MIN_SCENE_TABLE_SIZE_METERS ||
                            bounds.size().z < MIN_SCENE_TABLE_SIZE_METERS) {
                          return@runCatching null
                        }
                        val anchorPose = scene.getAnchorPose(anchor.handle)
                        val localTop =
                            Vector3(
                                (bounds.min.x + bounds.max.x) * 0.5f,
                                bounds.max.y,
                                (bounds.min.z + bounds.max.z) * 0.5f,
                            )
                        val worldTop = anchorPose * localTop
                        val surface = Point3(worldTop.x, worldTop.y, worldTop.z)
                        val viewer = Point3(head.x, head.y, head.z)
                        val pose =
                            TabletopPlacement.fromSceneSurface(surface, viewer)
                                ?: return@runCatching null
                        val dx = worldTop.x - head.x
                        val dz = worldTop.z - head.z
                        pose to (dx * dx + dz * dz)
                      }
                      .getOrNull()
                }
                .minByOrNull { it.second }
                ?.first
          }
          .getOrNull()

  private fun armManualTablePlacement(reason: String) {
    tablePlacementArmed = true
    inputState.releaseAll("Manual table placement armed")
    debugPanelController.setTableStatus(
        "$reason · rest palms apart, then hold both index pinches",
    )
  }

  private fun completeTablePlacement(sample: TablePlacementSample) {
    val placement = TabletopPlacement.from(sample)
    if (placement == null) {
      tablePlacementArmed = false
      debugPanelController.setTableStatus(
          "Placement rejected · keep palms at least 18 cm apart and try again",
      )
      return
    }
    applyTablePlacement(
        placement,
        "MANUALLY PLACED · aligned from your palms for the current session",
    )
  }

  private fun applyTablePlacement(
      placement: TabletopPose,
      status: String,
  ) {
    ensureKeyboardEntity()
    val yaw = Quaternion(0f, placement.yawDegrees, 0f)
    val flat = Quaternion(90f, 0f, 0f)
    keyboardEntity?.setComponent(
        Transform(
            Pose(
                Vector3(
                    placement.center.x,
                    placement.center.y,
                    placement.center.z,
                ),
                yaw * flat,
            ),
        ),
    )
    tablePlacementArmed = false
    tablePlaced = true
    debugPanelController.setTableStatus(status)
    setKeyboardVisible(true)
  }

  private fun startFingerCalibration() {
    stopTrackingCaptureIfActive("Capture stopped before finger calibration")
    tablePlacementRequestId++
    tablePlacementArmed = false
    setKeyboardVisible(false)
    inputState.releaseAll("Finger calibration started")
    if (::inputPollingSystem.isInitialized) inputPollingSystem.startHandCalibration()
  }

  private fun startThumbTrackpadCalibration() {
    stopTrackingCaptureIfActive("Capture stopped before thumb-stick calibration")
    tablePlacementRequestId++
    tablePlacementArmed = false
    setKeyboardVisible(false)
    inputState.releaseAll("Thumb-stick calibration started")
    if (::inputPollingSystem.isInitialized) {
      inputPollingSystem.startThumbTrackpadCalibration()
    }
  }

  override fun onRequestPermissionsResult(
      requestCode: Int,
      permissions: Array<out String>,
      grantResults: IntArray,
  ) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    if (requestCode != REQUEST_CODE_PERMISSION_USE_SCENE) return
    val granted =
        permissions.firstOrNull() == PERMISSION_USE_SCENE &&
            grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
    val requestId = tablePlacementRequestId
    if (granted) {
      tryAutomaticTablePlacement(requestId)
    } else {
      armManualTablePlacement("Spatial Data denied")
    }
  }

  private fun setControllerRouting(enabled: Boolean, source: String = "UI") {
    if (enabled && inputState.snapshot().mode != InputMode.TOUCH_XBOX) {
      selectMode(InputMode.TOUCH_XBOX)
    }
    if (controllerRoutingEnabled == enabled) {
      renderControllerStatus()
      return
    }

    // Never leave the window grabbable while gameplay owns the Touch controllers.
    if (enabled && browserGrabUnlocked) {
      browserGrabUnlocked = false
      browserEntity?.setComponent(Grabbable(enabled = false))
      debugPanelController.setWindowMoveUnlocked(false)
      browserWindowChromeController.setMoveUnlocked(false)
    }

    controllerRoutingEnabled = enabled
    enforceSpatialInputPolicy()
    inputState.releaseAll(
        if (enabled) "Controller ON via $source" else "Controller OFF via $source",
    )
    // The embedded Gamepad API shim is the controller backend in this build. Never defer to a
    // shell/native service; that was the source of the old OFFLINE/reconnecting failure loop.
    browserBridge.setNativeXboxActive(false)
    applyPanelInteractionGate()
    renderControllerStatus()
  }

  private fun renderControllerStatus() {
    val enabled = controllerRoutingEnabled
    debugPanelController.setControllerStatus(
        if (enabled) {
          "Controller ON · Touch → Xbox · LT + LB + RT + RB toggles"
        } else {
          "Controller OFF · Quest UI controls · LT + LB + RT + RB toggles · both fists hand off from Hands"
        },
        xboxActive = enabled,
        suppressionActive = enabled,
    )
  }

  private fun selectMode(mode: InputMode) {
    if (systemKeyboardVisible) setSystemTextEntryVisible(false)
    getSharedPreferences(PREFERENCES_NAME, MODE_PRIVATE).edit {
      putString(PREFERENCE_INPUT_MODE, mode.name)
    }
    inputState.setMode(mode)
    if (mode != InputMode.TOUCH_XBOX && controllerRoutingEnabled) {
      setControllerRouting(false, "mode change")
    } else {
      browserBridge.setNativeXboxActive(false)
    }
    // Outside controller-free Xbox mode, UI remains normally available.  Entering controller
    // mode immediately removes hand-ray targets until the two-thumb safety gesture is held.
    setHandUiUnlocked(mode != InputMode.HAND_XBOX)
    if (::inputPollingSystem.isInitialized) inputPollingSystem.recenterHands()
    if (mode == InputMode.TABLETOP_KEYBOARD_MOUSE && !tablePlaced) {
      beginTablePlacement()
    } else {
      setKeyboardVisible(mode == InputMode.TABLETOP_KEYBOARD_MOUSE)
    }
  }

  private fun toggleTrackingCapture() {
    if (!::trackingCaptureRecorder.isInitialized) return
    if (trackingCaptureRecorder.isActive) {
      trackingCaptureRecorder.stopAndSave()
      inputState.releaseAll("Tracking capture stopped")
      return
    }

    tablePlacementRequestId++
    tablePlacementArmed = false
    tableSceneLookupActive = false
    if (keyboardVisible) setKeyboardVisible(false)
    if (browserGrabUnlocked) {
      browserGrabUnlocked = false
      browserEntity?.setComponent(Grabbable(enabled = false))
      debugPanelController.setWindowMoveUnlocked(false)
      browserWindowChromeController.setMoveUnlocked(false)
    }
    inputPollingSystem.cancelHandCalibration()
    inputState.releaseAll("Tracking capture started")
    trackingCaptureRecorder.start()
  }

  private fun applyLatestTrackingCapture() {
    if (!::trackingCaptureRecorder.isInitialized) return
    inputState.releaseAll("Applying latest personal profile")
    trackingCaptureRecorder.applyLatestProfile()
  }

  private fun stopTrackingCaptureIfActive(reason: String) {
    if (::trackingCaptureRecorder.isInitialized && trackingCaptureRecorder.isActive) {
      trackingCaptureRecorder.stopAndSave(reason)
    }
  }

  override fun onResume() {
    super.onResume()
    renderControllerStatus()
    applyPanelInteractionGate()
    applyFocusMode()
  }

  override fun onPause() {
    if (systemKeyboardVisible) setSystemTextEntryVisible(false)
    stopTrackingCaptureIfActive("Activity paused")
    inputState.releaseAll("Activity paused")
    super.onPause()
  }

  override fun onWindowFocusChanged(hasFocus: Boolean) {
    super.onWindowFocusChanged(hasFocus)
    if (!hasFocus) inputState.releaseAll("Window focus lost")
  }

  @OptIn(SpatialSDKExperimentalAPI::class)
  override fun onDestroy() {
    inputState.releaseAll("Activity destroyed")
    if (::trackingCaptureRecorder.isInitialized) trackingCaptureRecorder.close()
    keyboardPanelController.close()
    embeddedKeyboardController.close()
    browserWindowChromeController.close()
    debugPanelController.close()
    browserBridge.close()
    runCatching { scene.releaseBodyTrackingBuffers() }
    super.onDestroy()
  }

  companion object {
    private const val BROWSER_WIDTH_METERS = 1.60f
    private const val BROWSER_HEIGHT_METERS = 0.90f
    private const val BROWSER_ASPECT_HEIGHT_OVER_WIDTH = 9f / 16f
    private const val MIN_BROWSER_WIDTH_METERS = 0.80f
    private const val MAX_BROWSER_WIDTH_METERS = 2.40f
    private const val WINDOW_MOVE_STEP_METERS = 0.10f
    private const val WINDOW_DEPTH_STEP_METERS = 0.15f
    private const val MIN_WINDOW_HEIGHT_METERS = 0.45f
    private const val MAX_WINDOW_HEIGHT_METERS = 2.75f
    private const val MAX_WINDOW_COORDINATE = 4f
    private const val DEFAULT_BROWSER_DISTANCE_METERS = 1.65f
    private const val DEFAULT_KEYBOARD_DISTANCE_METERS = 0.75f
    private const val DEFAULT_KEYBOARD_VERTICAL_OFFSET_METERS = 0.55f
    private const val DEFAULT_BROWSER_VERTICAL_OFFSET_METERS = 0.12f
    private const val DEBUG_WIDTH_METERS = 1.60f
    private const val DEBUG_HEIGHT_METERS = 0.52f
    private const val KEYBOARD_WIDTH_METERS = 0.90f
    private const val KEYBOARD_HEIGHT_METERS = 0.32f
    private const val PREFERENCES_NAME = "quest_input_lab"
    private const val PREFERENCE_INPUT_MODE = "input_mode"
    private const val PERMISSION_USE_SCENE = "com.oculus.permission.USE_SCENE"
    private const val REQUEST_CODE_PERMISSION_USE_SCENE = 1
    private const val MIN_SCENE_TABLE_SIZE_METERS = 0.20f
    private const val MAX_CLIPBOARD_CHARS = 16_000
    private const val TOUCH_ANALOG_DEADZONE = 0.08f
    private const val TOUCH_ANALOG_MAX_AGE_NANOS = 250_000_000L
    private const val CONTROLLER_TOGGLE_DEBOUNCE_NANOS = 400_000_000L
  }
}
