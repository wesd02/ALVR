package com.dearformerself.questinputlab.ui

import android.content.Context
import android.content.res.ColorStateList
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.core.graphics.toColorInt
import com.dearformerself.questinputlab.R

/** Controls the visible frame surrounding the browser panel. */
class BrowserWindowChromeController(
    private val onBack: () -> Unit,
    private val onToggleKeyboard: () -> Unit,
    private val onSubmitText: (String) -> Boolean,
    private val onCloseTextEntry: () -> Unit,
    private val onPaste: () -> Unit,
    private val onToggleMove: () -> Unit,
    private val onToggleFocus: () -> Unit,
    private val onAdjustWindow: (BrowserWindowAdjustment) -> Unit,
) : AutoCloseable {
  private var rootView: View? = null
  private var moveUnlocked = false
  private var focusModeEnabled = false
  private var textEntryVisible = false
  private var embeddedKeyboardVisible = false
  private var textEntryRevealed = false
  private var widthMeters = 1.60f
  private var heightMeters = 0.90f

  fun attach(root: View) {
    rootView = root
    root.findViewById<Button>(R.id.button_browser_frame_back).setOnClickListener { onBack() }
    root.findViewById<Button>(R.id.button_browser_frame_keyboard).setOnClickListener {
      onToggleKeyboard()
    }
    root.findViewById<Button>(R.id.button_browser_frame_paste).setOnClickListener {
      onPaste()
    }
    root.findViewById<Button>(R.id.button_browser_frame_move).setOnClickListener {
      onToggleMove()
    }
    root.findViewById<Button>(R.id.button_browser_frame_focus).setOnClickListener {
      onToggleFocus()
    }
    root.findViewById<Button>(R.id.button_browser_frame_smaller).setOnClickListener {
      onAdjustWindow(BrowserWindowAdjustment.SMALLER)
    }
    root.findViewById<Button>(R.id.button_browser_frame_larger).setOnClickListener {
      onAdjustWindow(BrowserWindowAdjustment.LARGER)
    }
    root.findViewById<Button>(R.id.button_browser_frame_reset).setOnClickListener {
      onAdjustWindow(BrowserWindowAdjustment.RESET)
    }
    root.findViewById<Button>(R.id.button_browser_text_send).setOnClickListener {
      submitTextEntry()
    }
    root.findViewById<Button>(R.id.button_browser_text_close).setOnClickListener {
      onCloseTextEntry()
    }
    root.findViewById<Button>(R.id.button_browser_text_show).setOnClickListener {
      textEntryRevealed = !textEntryRevealed
      renderTextReveal()
    }
    root.findViewById<EditText>(R.id.edit_browser_text_entry).setOnEditorActionListener {
        _, actionId, _ ->
      if (actionId == EditorInfo.IME_ACTION_DONE) {
        submitTextEntry()
        true
      } else {
        false
      }
    }
    render()
    applyTextEntryVisibility(requestIme = textEntryVisible)
  }

  fun setMoveUnlocked(unlocked: Boolean) {
    moveUnlocked = unlocked
    render()
  }

  fun setWindowSize(width: Float, height: Float) {
    widthMeters = width
    heightMeters = height
    render()
  }

  fun setFocusModeEnabled(enabled: Boolean) {
    focusModeEnabled = enabled
    render()
  }

  fun setEmbeddedKeyboardVisible(visible: Boolean) {
    embeddedKeyboardVisible = visible
    rootView?.findViewById<View>(R.id.browser_embedded_keyboard)?.visibility =
        if (visible) View.VISIBLE else View.GONE
    render()
  }

  fun setTextEntryVisible(visible: Boolean) {
    if (textEntryVisible == visible) {
      if (visible) applyTextEntryVisibility(requestIme = true)
      return
    }
    textEntryVisible = visible
    if (visible) textEntryRevealed = false
    applyTextEntryVisibility(requestIme = visible)
    render()
  }

  private fun submitTextEntry() {
    val root = rootView ?: return
    val field = root.findViewById<EditText>(R.id.edit_browser_text_entry)
    val text = field.text?.toString().orEmpty()
    if (text.isEmpty()) return
    if (onSubmitText(text)) field.text?.clear()
  }

  private fun applyTextEntryVisibility(requestIme: Boolean) {
    val root = rootView ?: return
    root.post {
      val bar = root.findViewById<View>(R.id.browser_text_entry_bar)
      val field = root.findViewById<EditText>(R.id.edit_browser_text_entry)
      bar.visibility = if (textEntryVisible) View.VISIBLE else View.GONE
      if (textEntryVisible) {
        renderTextReveal()
        field.requestFocus()
        field.setSelection(field.text?.length ?: 0)
        if (requestIme) {
          field.post {
            val imm =
                field.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(field, InputMethodManager.SHOW_IMPLICIT)
          }
        }
      } else {
        val imm = field.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(field.windowToken, 0)
        field.clearFocus()
        field.text?.clear()
      }
    }
  }

  private fun renderTextReveal() {
    val root = rootView ?: return
    val field = root.findViewById<EditText>(R.id.edit_browser_text_entry)
    val selection = field.selectionStart.coerceAtLeast(0)
    field.transformationMethod =
        if (textEntryRevealed) HideReturnsTransformationMethod.getInstance()
        else PasswordTransformationMethod.getInstance()
    field.setSelection(selection.coerceAtMost(field.text?.length ?: 0))
    root.findViewById<Button>(R.id.button_browser_text_show).text =
        root.context.getString(
            if (textEntryRevealed) R.string.browser_text_hide else R.string.browser_text_show,
        )
  }

  private fun render() {
    val root = rootView ?: return
    root.post {
      root.findViewById<View>(R.id.browser_window_border).setBackgroundResource(
          if (moveUnlocked) R.drawable.browser_window_frame_active
          else R.drawable.browser_window_frame,
      )
      root.findViewById<Button>(R.id.button_browser_frame_keyboard).text =
          root.context.getString(
              if (embeddedKeyboardVisible) R.string.keyboard_toggle_hide else R.string.keyboard_toggle_show,
          )
      root.findViewById<Button>(R.id.button_browser_frame_move).apply {
        text =
            root.context.getString(
                if (moveUnlocked) R.string.browser_frame_lock else R.string.browser_frame_move,
            )
        backgroundTintList =
            ColorStateList.valueOf(
                (if (moveUnlocked) "#B86B22" else "#245460").toColorInt(),
            )
      }
      root.findViewById<Button>(R.id.button_browser_frame_focus).apply {
        text = root.context.getString(if (focusModeEnabled) R.string.focus_mode_on else R.string.focus_mode_off)
        backgroundTintList =
            ColorStateList.valueOf(
                (if (focusModeEnabled) "#167E9B" else "#243443").toColorInt(),
            )
      }
      root.findViewById<TextView>(R.id.text_browser_frame_hint).text =
          if (textEntryVisible) {
            root.context.getString(R.string.browser_text_entry_hint)
          } else if (moveUnlocked) {
            root.context.getString(R.string.browser_frame_move_hint)
          } else {
            root.context.getString(
                R.string.browser_frame_resize_hint,
                widthMeters,
                heightMeters,
            )
          }
    }
  }

  override fun close() {
    rootView = null
  }
}
